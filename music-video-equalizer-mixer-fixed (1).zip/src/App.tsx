import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import {
  AudioLines,
  FolderOpen,
  Sliders,
  Film,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  RotateCw,
  Save,
  X,
  Plus,
  Loader2,
} from "lucide-react";
import { engine, generateDemoBeat, uid, type Clip, type PlaybackIssue } from "./lib/engine";
import { timeStore } from "./lib/timeStore";
import { isNative } from "./lib/native";
import { STUDIO_NAME } from "./lib/brand";
import studioLogo from "./assets/studio-logo.svg?inline";
import { captureComposition } from "./lib/recording";
import { Renderer } from "./lib/renderer";
import { canvasSize, normalizeAspect } from "./lib/framing";
import { DEFAULT_VIZ, STYLE_LIST, sanitizeViz, type VizSettings } from "./lib/visualizers";
import { DEFAULT_PROJECT, EMPTY_MEDIA, type ExportState, type Media, type Project, type Tab } from "./lib/types";
import Preview, { type MonitorStatus } from "./components/Preview";
import Timeline from "./components/Timeline";
import Scrubber from "./components/Scrubber";
import { ClipEditor, SequenceTools } from "./components/Clips";
import FrameSettings from "./components/FrameSettings";
import { EqPanel, ExportPanel, MediaPanel, StudioControls } from "./components/Panels";
import { cn } from "./utils/cn";

const STORE_KEY = "soundframe.studio.v1";

const clampNum = (v: unknown, fallback: number, min: number, max: number) =>
  typeof v === "number" && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : fallback;
const oneOf = (v: unknown, allowed: number[], fallback: number) => (typeof v === "number" && allowed.includes(v) ? v : fallback);
const flag = (v: unknown, fallback: boolean) => (typeof v === "boolean" ? v : fallback);

/** Stored data may be old, partial or corrupt: validate every field instead of spreading it. */
function sanitizeProject(raw: unknown): Project {
  const j = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const d = DEFAULT_PROJECT;
  return {
    aspect: normalizeAspect(j.aspect),
    fit: j.fit === "fill" ? "fill" : "fit",
    musicVol: clampNum(j.musicVol, d.musicVol, 0, 1),
    videoVol: clampNum(j.videoVol, d.videoVol, 0, 1),
    videoMuted: flag(j.videoMuted, d.videoMuted),
    loop: flag(j.loop, d.loop),
    offset: 0,
    locked: flag(j.locked, d.locked),
    showBeats: flag(j.showBeats, d.showBeats),
    muteWhileExport: flag(j.muteWhileExport, d.muteWhileExport),
    bitrate: oneOf(j.bitrate, [3, 6, 10], d.bitrate),
    exportLong: oneOf(j.exportLong, [960, 1280, 1920], d.exportLong),
    transition: flag(j.transition, d.transition),
  };
}

function loadSaved(): { viz: VizSettings; project: Project } {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) {
      const j = JSON.parse(raw);
      return { viz: sanitizeViz(j?.viz), project: sanitizeProject(j?.project) };
    }
  } catch {
    /* ignore */
  }
  return { viz: DEFAULT_VIZ, project: DEFAULT_PROJECT };
}

// Weaker phones get a smaller preview canvas; the exported video size is set separately.
const PREVIEW_LONG = (navigator.hardwareConcurrency ?? 8) <= 4 ? 480 : 640;

interface ExportJob {
  capture: ReturnType<typeof captureComposition> | null;
  beforeRun: (time: number) => boolean;
  stop: (reason?: string | null) => void;
  stopping: boolean;
}

export default function App() {
  const saved = useMemo(loadSaved, []);
  const [viz, setVizState] = useState<VizSettings>(saved.viz);
  const [project, setProjectState] = useState<Project>(saved.project);
  const [media, setMedia] = useState<Media>(EMPTY_MEDIA);
  const [clips, setClips] = useState<Clip[]>([]);
  const [selId, setSelId] = useState<string>("");
  const [tab, setTab] = useState<Tab>("media");
  const [playing, setPlaying] = useState(false);
  const [buffering, setBuffering] = useState(false);
  const [recovering, setRecovering] = useState(false);
  const [issue, setIssue] = useState<PlaybackIssue | null>(null);
  const [canvasVersion, setCanvasVersion] = useState(0);
  const [monitorStatus, setMonitorStatus] = useState<MonitorStatus>("ready");
  const [exportRes, setExportRes] = useState<number | null>(null);
  const [exp, setExp] = useState<ExportState>({ status: "idle", progress: 0 });
  const [busy, setBusy] = useState("");
  const [notice, setNotice] = useState<{ message: string; undo?: () => void } | null>(null);
  const [savedFlag, setSavedFlag] = useState(false);
  const [flash, setFlash] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<Renderer | null>(null);
  const vizRef = useRef(viz);
  vizRef.current = viz;
  const fitRef = useRef(project.fit);
  fitRef.current = project.fit;
  const monitorRef = useRef<MonitorStatus>("ready");
  const focusClip = useRef<string | undefined>(undefined);
  const resumeImportedClip = useRef(false);
  const restartCanvas = useRef(false);
  const recRef = useRef<ExportJob | null>(null);
  const importing = useRef(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const setViz = useCallback((p: Partial<VizSettings>) => {
    if (!recRef.current) setVizState((v) => ({ ...v, ...p }));
  }, []);
  const setProject = useCallback((p: Partial<Project>) => {
    if (!recRef.current) setProjectState((v) => ({ ...v, ...p }));
  }, []);

  // Settings are saved automatically (debounced), so they survive restarts without pressing «ذخیره».
  useEffect(() => {
    const id = setTimeout(() => {
      try {
        localStorage.setItem(STORE_KEY, JSON.stringify({ viz, project }));
      } catch {
        /* storage full or unavailable */
      }
    }, 600);
    return () => clearTimeout(id);
  }, [viz, project]);

  const hasAudio = !!media.audioName;
  const hasVideo = clips.some((c) => c.kind === "video");
  const hasImage = clips.some((c) => c.kind === "image");
  const clipTotal = clips.reduce((a, c) => a + c.dur, 0);
  const duration = clips.length ? clipTotal : hasAudio ? media.audioDur : 0;
  const [cw, ch] = canvasSize(project.aspect, exportRes ?? PREVIEW_LONG);
  const [outWidth, outHeight] = canvasSize(project.aspect, project.exportLong);

  const toast = useCallback((message: string, undo?: () => void) => {
    clearTimeout(toastTimer.current);
    setNotice({ message, undo });
    toastTimer.current = setTimeout(() => setNotice(null), undo ? 7500 : 4900);
  }, []);
  const mountVideo = useCallback((host: HTMLElement) => engine.mountVideo(host), []);

  const previewReady = useCallback((time: number) => {
    try {
      return rendererRef.current?.frame(time, engine.duration, vizRef.current, performance.now(), fitRef.current) ?? false;
    } catch {
      // A single failed paint is handled by the engine's wait/recover cycle.
      return false;
    }
  }, []);

  const startPreview = useCallback((target?: PlaybackIssue["target"]) => {
    if (recRef.current || importing.current || restartCanvas.current || engine.duration <= 0 || engine.playing) return;
    setIssue(null);
    setRecovering(false);
    if (target === "preview") {
      restartCanvas.current = true;
      setCanvasVersion((v) => v + 1);
      return;
    }
    try {
      engine.play(previewReady, target);
      setPlaying(engine.playing);
      setBuffering(engine.waiting);
    } catch {
      engine.reportPreviewFailure();
    }
  }, [previewReady]);

  /* ---- engine params ---- */
  useEffect(() => {
    engine.offset = project.offset;
    engine.loop = project.loop;
    engine.musicVol = project.musicVol;
    engine.videoVol = project.videoMuted ? 0 : project.videoVol;
    engine.fade = project.transition ? 0.4 : 0;
    engine.applyVolumes();
  }, [project.offset, project.loop, project.musicVol, project.videoVol, project.videoMuted, project.transition]);

  useLayoutEffect(() => {
    engine.setClips(clips, focusClip.current);
    focusClip.current = undefined;
    setIssue(null);
    setPlaying(false);
    timeStore.set(engine.time, engine.duration);
    if (resumeImportedClip.current) {
      resumeImportedClip.current = false;
      startPreview();
    }
  }, [clips, startPreview]);

  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (rendererRef.current?.canvas !== canvas) rendererRef.current = new Renderer(canvas);
    if (rendererRef.current.resize(cw, ch)) previewReady(engine.time);
    if (restartCanvas.current) {
      restartCanvas.current = false;
      startPreview();
    }
  }, [canvasVersion, cw, ch, previewReady, startPreview]);

  useEffect(() => {
    engine.onPlaybackError = (failure) => {
      setIssue(failure);
      if (recRef.current) recRef.current.stop(failure.message);
      else {
        setPlaying(false);
        setBuffering(false);
        setRecovering(false);
      }
    };
    const onHidden = () => {
      if (!document.hidden) return;
      if (recRef.current) recRef.current.stop("رندر متوقف شد چون برنامه از صفحه خارج شد. هنگام خروجی گرفتن برنامه را باز نگه دارید.");
      else if (engine.playing) {
        engine.pause();
        setPlaying(false);
        setBuffering(false);
        setRecovering(false);
      }
    };
    document.addEventListener("visibilitychange", onHidden);
    document.fonts?.load("700 32px Vazirmatn").catch(() => {});
    return () => {
      document.removeEventListener("visibilitychange", onHidden);
      engine.onPlaybackError = null;
    };
  }, []);

  useEffect(() => {
    let raf = 0;
    let lastUi = 0;
    let lastRender = 0;
    let interval = 16.6;
    let costEma = 6;
    let lastAdapt = 0;
    let wasWaiting = false;
    let wasRecovering = false;
    let noFrameSince = 0;
    let pendingClip: string | undefined;
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const r = rendererRef.current;
      const job = recRef.current;
      if (!r || job?.stopping) return;
      engine.tick(job?.beforeRun ?? previewReady);
      if (job && (recRef.current !== job || job.stopping)) return;
      const t = engine.time;
      const dur = engine.duration;
      const capture = job?.capture;
      if (now - lastRender >= (job || !engine.started ? 31 : Math.max(0, interval - 3))) {
        lastRender = now;
        const t0 = performance.now();
        try {
          const painted = r.frame(t, dur, vizRef.current, now, fitRef.current);
          if (painted) noFrameSince = 0;
          else if (pendingClip !== engine.activeClipId || !noFrameSince) noFrameSince = now;
          pendingClip = engine.activeClipId;
          const unavailable = !engine.waiting && (engine.previewUnavailable || now - noFrameSince > 8500);
          const status = painted ? "ready" : unavailable ? "unavailable" : "pending";
          if (monitorRef.current !== status) {
            monitorRef.current = status;
            setMonitorStatus(status);
          }
          if (!painted && engine.started) engine.waitForFrame();
          if (painted && engine.started) capture?.frame();
        } catch {
          // During export, fail fast; during preview, let the engine wait for a real frame.
          if (job) engine.reportPreviewFailure();
        }
        costEma = costEma * 0.9 + (performance.now() - t0) * 0.1;
        if (!job && now - lastAdapt > 1500) {
          lastAdapt = now;
          interval = costEma > 24 ? 50 : costEma > 11 ? 33.3 : costEma < 6 ? 16.6 : costEma < 12 && interval > 33.3 ? 33.3 : interval;
        }
      }
      if (engine.waiting && capture?.recorder.state === "recording") {
        try {
          capture.recorder.pause();
          setExp((e) => ({ ...e, phase: "waiting" }));
        } catch { job?.stop("مکث ضبط ممکن نشد. دوباره خروجی بگیرید."); }
      }
      if (engine.waiting !== wasWaiting) {
        wasWaiting = engine.waiting;
        setBuffering(wasWaiting);
      }
      if (engine.recovering !== wasRecovering) {
        wasRecovering = engine.recovering;
        setRecovering(wasRecovering);
      }
      if (engine.started && dur > 0 && t >= dur) {
        if (job) job.stop();
        else {
          engine.pause();
          engine.seek(0);
          setPlaying(false);
        }
      }
      if (now - lastUi > 50) {
        lastUi = now;
        timeStore.set(engine.time, dur);
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [previewReady]);

  /* ---- transport ---- */
  const togglePlay = useCallback(() => {
    if (recRef.current || importing.current) return;
    if (engine.duration <= 0) {
      toast("ابتدا کلیپ (ویدئو/عکس) و موزیک اضافه کنید");
      setTab("media");
      return;
    }
    if (engine.playing) {
      engine.pause();
      setPlaying(false);
      setBuffering(false);
      setRecovering(false);
    } else {
      startPreview(issue?.target);
    }
  }, [issue, startPreview, toast]);

  const seek = useCallback((t: number) => {
    if (recRef.current || importing.current) return;
    engine.seek(t);
    setIssue(null);
    timeStore.set(Math.max(0, Math.min(engine.duration, t)), engine.duration);
  }, []);
  const onBox = useCallback((box: VizSettings["box"]) => setViz({ box }), [setViz]);
  const onOffset = useCallback((o: number) => setProject({ offset: o }), [setProject]);
  const selectClip = useCallback((id: string) => {
    if (recRef.current || importing.current) return;
    const index = engine.clips.findIndex((clip) => clip.id === id);
    if (index < 0) return;
    engine.pause();
    setPlaying(false);
    setSelId(id);
    seek(engine.starts[index]);
  }, [seek]);
  const openTools = useCallback((target: Tab) => {
    if (recRef.current && target !== "export") return;
    setTab(target);
    if (window.matchMedia("(max-width: 1023px)").matches) {
      requestAnimationFrame(() => document.getElementById("editor-tools")?.scrollIntoView({ block: "start" }));
    }
  }, []);

  /* ---- media loading ---- */
  const addFiles = async (files: File[], replace?: Clip, resume = false) => {
    if (!files.length || importing.current || recRef.current) return;
    importing.current = true;
    setBusy("clips");
    setPlaying(false);
    try {
      const { added, failed } = await engine.importClips(files, replace);
      const selected = added[added.length - 1];
      if (selected) {
        focusClip.current = selected.id;
        resumeImportedClip.current = resume;
        setSelId(selected.id);
        setClips((current) => replace ? current.map((clip) => clip.id === replace.id ? selected : clip) : [...current, ...added]);
      } else engine.seek(engine.time);
      if (failed.length) {
        const fileLabel = failed.length === 1 ? `«${failed[0]}»` : `${failed.length} فایل`;
        toast(replace ? `فایل جدید خوانده نشد؛ «${replace.name}» باقی ماند.`
          : `${fileLabel} خوانده نشد. برای ویدئو MP4 (H.264) و برای عکس JPG یا PNG را امتحان کنید.`);
      } else if (replace) {
        toast(`«${selected.name}» در همان جای تایم‌لاین جایگزین شد.`);
      }
    } catch {
      engine.seek(engine.time);
      toast("خواندن فایل کامل نشد. دوباره تلاش کنید.");
    } finally {
      importing.current = false;
      setBusy("");
    }
  };

  const onAudio = async (file: File, resume = false) => {
    if (importing.current || recRef.current) return;
    importing.current = true;
    setPlaying(false);
    setBusy("audio");
    let loaded = false;
    try {
      const a = await engine.loadAudio(file);
      setMedia((m) => ({ ...m, audioName: file.name, audioDur: a.duration, analysis: a }));
      setIssue((current) => current?.target === "audio" ? null : current);
      loaded = true;
      toast(a.bpm > 0 ? `موزیک بارگذاری شد — تمپو حدود ${Math.round(a.bpm)} BPM` : "موزیک بارگذاری شد");
    } catch {
      toast("خواندن فایل موزیک ممکن نشد. فرمت MP3 یا WAV را امتحان کنید.");
    } finally {
      importing.current = false;
      setBusy("");
    }
    if (loaded && resume) startPreview();
  };

  const onDemo = async () => {
    if (importing.current || recRef.current) return;
    importing.current = true;
    setBusy("demo");
    engine.pause();
    setPlaying(false);
    try {
      const { blob, buffer } = await generateDemoBeat();
      const a = await engine.loadAudio(blob, buffer);
      setMedia((m) => ({ ...m, audioName: "Synthwave Demo.wav", audioDur: a.duration, analysis: a }));
      setIssue((current) => current?.target === "audio" ? null : current);
      toast("موزیک دمو ساخته شد. دکمه پخش را بزنید!");
    } catch {
      toast("ساخت موزیک دمو ممکن نشد.");
    }
    importing.current = false;
    setBusy("");
  };

  const clipsInput = useRef<HTMLInputElement>(null);
  const replaceInput = useRef<HTMLInputElement>(null);
  const replacement = useRef<{ id: string; resume: boolean } | null>(null);
  const resumeAfterAudioPick = useRef(false);
  const audioInput = useRef<HTMLInputElement>(null);
  const pick = useCallback((k: "clips" | "audio") => {
    if (importing.current || recRef.current) return;
    if (k === "audio") resumeAfterAudioPick.current = false;
    (k === "clips" ? clipsInput : audioInput).current?.click();
  }, []);
  const pickReplacement = (id: string, resume = issue?.clipId === id && tab !== "export") => {
    if (importing.current || recRef.current || !id) return;
    replacement.current = { id, resume };
    replaceInput.current?.click();
  };
  const replaceProblemFile = () => {
    if (!issue || importing.current || recRef.current) return;
    if (issue.clipId) pickReplacement(issue.clipId, true);
    else if (issue.target === "audio") {
      resumeAfterAudioPick.current = true;
      audioInput.current?.click();
    }
  };

  // Stable wrappers so the memoised Preview is not re-rendered on every settings change.
  const latest = useRef({ retry: () => {}, replaceIssue: () => {}, demo: () => {} });
  latest.current = { retry: () => startPreview(issue?.target), replaceIssue: replaceProblemFile, demo: () => void onDemo() };
  const onRetry = useCallback(() => latest.current.retry(), []);
  const onReplaceIssue = useCallback(() => latest.current.replaceIssue(), []);
  const onDemoStable = useCallback(() => latest.current.demo(), []);
  const onOpenFrame = useCallback(() => openTools("studio"), [openTools]);

  const clearAudio = () => {
    if (importing.current || recRef.current) return;
    engine.clearAudio();
    setIssue((current) => current?.target === "audio" ? null : current);
    setPlaying(false);
    setMedia((m) => ({ ...m, audioName: "", audioDur: 0, analysis: null }));
    timeStore.set(engine.time, engine.duration);
  };

  /* ---- clip editing ---- */
  const updateClip = useCallback((id: string, patch: Partial<Clip>) => {
    if (importing.current || recRef.current) return;
    setClips((cs) => cs.map((c) => (c.id === id ? { ...c, ...patch } : c)));
  }, []);
  const removeClip = (id: string) => {
    if (importing.current || recRef.current) return;
    const current = engine.clips;
    const index = current.findIndex((clip) => clip.id === id);
    if (index < 0) return;
    const removed = current[index];
    const file = engine.sourceFile(removed.srcId);
    const nextId = current[index + 1]?.id;
    const remaining = current.filter((clip) => clip.id !== id);
    if (selId === id || engine.activeClipId === id) {
      const neighbor = remaining[Math.min(index, remaining.length - 1)];
      focusClip.current = neighbor?.id;
      setSelId(neighbor?.id ?? "");
    }
    setClips(remaining);
    toast(`«${removed.name}» از پروژه حذف شد.`, file ? () => {
      if (importing.current || recRef.current) return;
      const restoring = engine.clips.slice();
      if (restoring.some((clip) => clip.id === removed.id)) return;
      const neighbor = restoring.findIndex((clip) => clip.id === nextId);
      restoring.splice(neighbor < 0 ? Math.min(index, restoring.length) : neighbor, 0, removed);
      engine.addSource(removed.srcId, file);
      focusClip.current = removed.id;
      setSelId(removed.id);
      setClips(restoring);
      toast(`«${removed.name}» برگردانده شد.`);
    } : undefined);
  };
  const moveClip = (id: string, dir: -1 | 1) => {
    if (importing.current || recRef.current) return;
    setClips((cs) => {
      const i = cs.findIndex((c) => c.id === id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= cs.length) return cs;
      const n = cs.slice();
      [n[i], n[j]] = [n[j], n[i]];
      return n;
    });
  };
  const duplicateClip = (id: string) => {
    if (importing.current || recRef.current) return;
    setClips((cs) => {
      const i = cs.findIndex((c) => c.id === id);
      if (i < 0) return cs;
      const copy = { ...cs[i], id: uid() };
      const n = cs.slice();
      n.splice(i + 1, 0, copy);
      return n;
    });
  };
  const splitAtPlayhead = () => {
    if (importing.current || recRef.current) return;
    const t = engine.time;
    let acc = 0;
    for (const c of clips) {
      const off = t - acc;
      if (off > 0.3 && off < c.dur - 0.3) {
        const second: Clip = { ...c, id: uid(), dur: c.dur - off, trimStart: c.kind === "video" ? c.trimStart + off : 0 };
        setClips((cs) => {
          const i = cs.findIndex((x) => x.id === c.id);
          const n = cs.slice();
          n[i] = { ...c, dur: off };
          n.splice(i + 1, 0, second);
          return n;
        });
        toast("کلیپ در محل پلی‌هد برش خورد ✂");
        return;
      }
      acc += c.dur;
    }
    toast("پلی‌هد را داخل یک کلیپ (دور از لبه‌ها) قرار دهید");
  };
  const fitImagesToMusic = () => {
    if (importing.current || recRef.current) return;
    const imgs = clips.filter((c) => c.kind === "image");
    if (!hasAudio || !imgs.length) {
      toast("برای این کار موزیک و حداقل یک عکس لازم است");
      return;
    }
    const vTotal = clips.filter((c) => c.kind === "video").reduce((a, c) => a + c.dur, 0);
    const each = Math.min(30, Math.max(1, (media.audioDur - vTotal) / imgs.length));
    setClips((cs) => cs.map((c) => (c.kind === "image" ? { ...c, dur: Math.round(each * 100) / 100 } : c)));
    toast(`مدت هر عکس ${each.toFixed(1)} ثانیه شد تا کل ویدئو هم‌طول موزیک شود`);
  };
  const snapToBeats = (beats: number) => {
    if (importing.current || recRef.current) return;
    const bpm = media.analysis?.bpm ?? 0;
    if (bpm <= 0) {
      toast("برای این کار موزیک با تمپوی قابل تشخیص لازم است");
      return;
    }
    const d = Math.round(((60 / bpm) * beats) * 100) / 100;
    setClips((cs) => cs.map((c) => (c.kind === "image" ? { ...c, dur: d } : c)));
    toast(`مدت عکس‌ها = ${beats} ضرب (${d.toFixed(2)} ثانیه) — برش‌ها روی بیت می‌افتد`);
  };

  const alignBeat = () => {
    if (!media.analysis) return;
    setProject({ offset: -Math.round(media.analysis.firstBeat * 100) / 100 });
    setFlash(true);
    setTimeout(() => setFlash(false), 500);
    toast("اولین ضرب موزیک با شروع پروژه هماهنگ شد");
  };

  const save = () => {
    localStorage.setItem(STORE_KEY, JSON.stringify({ viz, project }));
    setSavedFlag(true);
    setTimeout(() => setSavedFlag(false), 1800);
  };
  const reset = () => {
    if (recRef.current) return;
    const settings = { ...DEFAULT_PROJECT, aspect: project.aspect };
    setVizState(DEFAULT_VIZ);
    setProjectState(settings);
    localStorage.setItem(STORE_KEY, JSON.stringify({ viz: DEFAULT_VIZ, project: settings }));
    toast("تنظیمات به حالت پیش‌فرض برگشت");
  };

  const startExport = () => {
    const canvas = canvasRef.current;
    const renderer = rendererRef.current;
    if (!canvas || !renderer || engine.duration <= 0 || recRef.current || importing.current) return;
    if (typeof MediaRecorder === "undefined" || !canvas.captureStream) {
      setExp({ status: "error", progress: 0, message: "این دستگاه از ضبط خروجی پشتیبانی نمی‌کند (نیاز به نسخه جدید Android System WebView / Chrome)." });
      return;
    }
    if (exp.url && !isNative) URL.revokeObjectURL(exp.url);
    const idle: ExportState = { status: "idle", progress: 0 };
    const setError = (message: string): ExportState => ({ status: "error", progress: 0, message });
    const settle = (result: ExportState) => {
      if (recRef.current !== job) return;
      recRef.current = null;
      const held = engine.degraded.slice();
      engine.tolerant = false;
      engine.pause();
      engine.speakerOn = true;
      engine.applyVolumes();
      if (result.status !== "error") engine.seek(0);
      timeStore.set(engine.time, engine.duration);
      renderer.recording = false;
      setPlaying(false);
      setBuffering(false);
      setExportRes(null);
      setExp(result.status === "done" && held.length
        ? { ...result, message: `ویدئوی «${held.join("»، «")}» در حین رندر پاسخ نداد؛ از آخرین فریم سالم آن استفاده شد. برای تصویر روان، نسخه MP4 (H.264) همان کلیپ را جایگزین کنید.` }
        : result);
    };
    const job: ExportJob = {
      capture: null,
      stopping: false,
      beforeRun(time) {
        if (job.stopping) return false;
        try {
          // The first frame is painted at output resolution before recording starts.
          if (!renderer.frame(time, engine.duration, viz, performance.now(), project.fit)) return false;
          if (!job.capture) {
            const audio = engine.recDest?.stream.getAudioTracks()[0];
            if (!audio) throw new Error("آماده‌سازی صدای خروجی انجام نشد.");
            job.capture = captureComposition(canvas, audio, project.bitrate);
            void job.capture.finished.then((result) => settle(result ?? idle), (error: Error) => settle(setError(error.message)));
          } else if (job.capture.recorder.state === "paused") {
            job.capture.recorder.resume();
          }
          if (job.capture.recorder.state !== "recording") return false;
          job.capture.frame();
          setExp((e) => ({ ...e, phase: "running" }));
          return true;
        } catch (error) {
          job.stop(error instanceof Error ? error.message : "شروع ضبط تصویر ممکن نشد.");
          return false;
        }
      },
      stop(reason) {
        if (job.stopping) return;
        job.stopping = true;
        engine.pause();
        setPlaying(false);
        setBuffering(false);
        if (job.capture) {
          setExp((e) => ({ ...e, phase: "saving" }));
          job.capture.stop(reason);
        } else settle(reason ? setError(reason) : idle);
      },
    };
    recRef.current = job;
    setExp({ status: "recording", progress: 0, phase: "preparing" });
    try {
      renderer.recording = true;
      renderer.resize(outWidth, outHeight);
      setExportRes(project.exportLong);
      engine.pause();
      engine.seek(0, issue?.target);
      setIssue(null);
      timeStore.set(0, engine.duration);
      engine.resetDegraded();
      engine.tolerant = true;
      engine.speakerOn = !project.muteWhileExport;
      engine.applyVolumes();
      engine.play(job.beforeRun);
      setPlaying(engine.playing);
    } catch {
      job.stop("شروع رندر ممکن نشد. بعد از بررسی فایل‌ها دوباره تلاش کنید.");
    }
  };

  const cancelExport = () => recRef.current?.stop(null);

  const recording = exp.status === "recording";
  const styleLabel = STYLE_LIST.find((s) => s.id === viz.style)?.label ?? "";

  const navItems: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "media", label: "رسانه‌ها", icon: <FolderOpen size={20} /> },
    { id: "studio", label: "استودیو", icon: <Sliders size={20} /> },
    { id: "eq", label: "اکولایزر", icon: <AudioLines size={20} /> },
    { id: "export", label: "خروجی", icon: <Film size={20} /> },
  ];

  const fileInput = (ref: React.RefObject<HTMLInputElement | null>, accept: string, fn: (f: File) => void) => (
    <input
      ref={ref}
      type="file"
      accept={accept}
      hidden
      onChange={(e) => {
        const f = e.target.files?.[0];
        if (f) fn(f);
        e.target.value = "";
      }}
    />
  );

  const circleBtn =
    "flex h-10 w-10 items-center justify-center rounded-xl bg-white/[0.05] text-ink ring-1 ring-white/[0.06] transition hover:text-cyan active:scale-90";
  const stepBtn = cn(circleBtn, "h-9 w-8 shrink-0 disabled:opacity-40 min-[380px]:h-10 min-[380px]:w-10");

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-surface pb-[calc(7.5rem+var(--sab))] pt-[calc(4rem+var(--sat))] text-ink" dir="rtl">
      <input
        ref={clipsInput}
        type="file"
        accept="video/*,image/*"
        multiple
        hidden
        onChange={(e) => {
          const fl = Array.from(e.target.files ?? []);
          e.target.value = "";
          void addFiles(fl);
        }}
      />
      {fileInput(replaceInput, "video/*,image/*", (file) => {
        const request = replacement.current;
        replacement.current = null;
        const existing = engine.clips.find((clip) => clip.id === request?.id);
        if (existing) void addFiles([file], existing, request?.resume);
      })}
      {fileInput(audioInput, "audio/*", (file) => {
        const resume = resumeAfterAudioPick.current;
        resumeAfterAudioPick.current = false;
        void onAudio(file, resume);
      })}

      <div aria-hidden="true" className="studio-ambient pointer-events-none fixed inset-0" />

      {/* header */}
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/[0.06] bg-surface/95 pt-[var(--sat)] lg:backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-2 px-4">
          <div className="flex min-w-0 items-center gap-3">
            <div className="relative size-11 shrink-0">
              <img src={studioLogo} alt="" className="block size-full" width={44} height={44} />
              {playing && <span className="absolute -end-0.5 -top-0.5 size-2.5 rounded-full bg-cyan ring-2 ring-surface motion-safe:animate-pulse" />}
            </div>
            <div className="min-w-0 leading-tight">
              <h1 className="truncate text-[17px] font-bold text-ink sm:text-[18px]">{STUDIO_NAME}</h1>
              <div className="truncate text-[10.5px] text-mute/80">میکس موزیک · ویدئو · عکس با اکولایزر زنده</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={cn(
                "hidden items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[10px] ring-1 sm:flex",
                recording ? "bg-crimson/30 text-rose ring-rose/30" : playing ? "bg-cyan/10 text-cyan ring-cyan/30" : "bg-white/[0.04] text-mute ring-white/10",
              )}
            >
              <span className={cn("h-1.5 w-1.5 rounded-full", recording ? "animate-pulse bg-rose" : playing ? "animate-pulse bg-cyan" : "bg-mute/60")} />
              {recording ? "REC" : playing ? "LIVE" : "READY"}
            </span>
            <button onClick={save} aria-label="ذخیره تنظیمات" className={circleBtn}>
              <Save size={17} />
            </button>
          </div>
        </div>
      </header>

      {notice && (
        <div className="pointer-events-none fixed inset-x-0 top-[calc(72px+var(--sat))] z-[60] flex justify-center px-4">
          <div role="status" className="fade-up pointer-events-auto flex max-w-md items-center gap-2 rounded-2xl bg-high/95 px-3.5 py-2.5 text-[12.5px] text-ink shadow-2xl ring-1 ring-cyan/30">
            <span className="min-w-0 grow break-words leading-5">{notice.message}</span>
            {notice.undo && <button type="button" onClick={notice.undo} disabled={!!busy || recording} className="shrink-0 rounded-md px-2 py-2 font-semibold text-cyan hover:bg-cyan/10 disabled:opacity-50">بازگردانی</button>}
            <button type="button" aria-label="بستن پیام" onClick={() => setNotice(null)} className="grid size-8 shrink-0 place-items-center text-mute hover:text-ink">
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      <main className="relative z-10 mx-auto grid max-w-[520px] grid-cols-1 gap-3.5 px-3 pt-3 lg:max-w-6xl lg:grid-cols-2 lg:gap-6 lg:px-4">
        {/* left: preview + transport */}
        <div className="flex flex-col gap-3 lg:sticky lg:top-[calc(76px+var(--sat))] lg:self-start">
          <Preview
            canvasRef={canvasRef}
            canvasVersion={canvasVersion}
            mountVideo={mountVideo}
            cw={cw}
            ch={ch}
            aspect={project.aspect}
            box={viz.box}
            onBox={onBox}
            playing={playing}
            buffering={buffering}
            recovering={recovering}
            issue={tab === "export" && exp.status === "error" ? null : issue}
            monitorStatus={monitorStatus}
            importing={busy === "clips"}
            hasVisual={clips.length > 0}
            hasAudio={hasAudio}
            hasVideo={hasVideo}
            videoMuted={project.videoMuted}
            recording={recording}
            styleLabel={styleLabel}
            onTogglePlay={togglePlay}
            onRetry={onRetry}
            onReplaceIssue={onReplaceIssue}
            onPick={pick}
            onDemo={onDemoStable}
            onOpenFrame={onOpenFrame}
          />

          <div className="rounded-2xl border border-white/[0.06] bg-low/80 p-2.5 shadow-lg">
            <Scrubber onSeek={seek} disabled={duration <= 0 || recording || !!busy} />
            <div className="mt-2 flex items-center justify-between gap-2">
              <div className="flex shrink-0 gap-1">
                <button disabled={recording || !!busy} aria-label="۵ ثانیه به عقب" onClick={() => seek(engine.time - 5)} className={stepBtn}>
                  <RotateCcw size={18} />
                </button>
                <button disabled={recording || !!busy} aria-label="ابتدا" onClick={() => seek(0)} className={stepBtn}>
                  <SkipForward size={18} />
                </button>
              </div>
              <button
                onClick={togglePlay}
                disabled={recording || !!busy}
                className={cn(
                  "flex h-12 min-w-0 max-w-[190px] flex-1 items-center justify-center gap-1.5 whitespace-nowrap rounded-2xl px-2 text-[13px] font-bold transition active:scale-95 disabled:opacity-60 sm:text-[14px]",
                  playing
                    ? "bg-gradient-to-l from-rose to-[#ff8fa0] text-[#680018] shadow-[0_0_22px_rgba(255,179,181,0.45)]"
                    : "bg-gradient-to-l from-cyan to-[#5af5ff] text-[#00464b] shadow-[0_0_22px_rgba(0,242,254,0.5)]",
                )}
              >
                {playing ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
                {playing ? "توقف" : "پخش زنده"}
              </button>
              <div className="flex shrink-0 gap-1">
                <button disabled={recording || !!busy} aria-label="پایان" onClick={() => seek(Math.max(0, duration - 0.1))} className={stepBtn}>
                  <SkipBack size={18} />
                </button>
                <button disabled={recording || !!busy} aria-label="۵ ثانیه به جلو" onClick={() => seek(engine.time + 5)} className={stepBtn}>
                  <RotateCw size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* right: panels */}
        <div id="editor-tools" className="min-w-0 scroll-mt-[calc(5rem+var(--sat))] pb-4">
          {tab === "media" && (
            <MediaPanel
              media={media}
              clips={clips}
              selId={selId}
              onSelect={selectClip}
              onReplace={pickReplacement}
              onDelete={removeClip}
              busy={busy}
              onPick={pick}
              onDemo={onDemo}
              onClearAudio={clearAudio}
              onSave={save}
              onReset={reset}
              saved={savedFlag}
            />
          )}
          {tab === "studio" && (
            <div className="fade-up flex flex-col gap-3">
              <FrameSettings aspect={project.aspect} fit={project.fit} disabled={!!busy}
                onAspect={(aspect) => setProject({ aspect })} onFit={(fit) => setProject({ fit })} />
              <Timeline
                clips={clips}
                selId={selId}
                onSelect={selectClip}
                duration={duration}
                onSeek={seek}
                hasAudio={hasAudio}
                analysis={media.analysis}
                audioName={media.audioName}
                audioDur={media.audioDur}
                offset={project.offset}
                loop={project.loop}
                locked={project.locked}
                showBeats={project.showBeats}
                onOffset={onOffset}
                rangeStart={viz.rangeStart}
                rangeEnd={viz.rangeEnd}
                videoMuted={project.videoMuted}
              />
              <button
                disabled={!!busy}
                onClick={() => pick("clips")}
                className="flex items-center justify-center gap-2 rounded-2xl border border-dashed border-cyan/40 bg-cyan/[0.06] py-3 text-[13px] font-semibold text-cyan transition active:scale-[0.98]"
              >
                {busy === "clips" ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
                افزودن ویدئو / عکس
              </button>
              <ClipEditor
                clip={clips.find((c) => c.id === selId)}
                index={clips.findIndex((c) => c.id === selId)}
                count={clips.length}
                onChange={(patch) => updateClip(selId, patch)}
                onMove={(d) => moveClip(selId, d)}
                onDelete={() => removeClip(selId)}
                onReplace={() => pickReplacement(selId)}
                onDuplicate={() => duplicateClip(selId)}
                onSplit={splitAtPlayhead}
              />
              <SequenceTools
                hasAudio={hasAudio}
                bpm={media.analysis?.bpm ?? 0}
                hasImages={hasImage}
                transition={project.transition}
                onTransition={(v) => setProject({ transition: v })}
                onFit={fitImagesToMusic}
                onBeats={snapToBeats}
              />
              <StudioControls
                media={media}
                project={project}
                setProject={setProject}
                hasVideo={clips.length > 0}
                onAlignBeat={alignBeat}
                flash={flash}
              />
            </div>
          )}
          {tab === "eq" && <EqPanel viz={viz} setViz={setViz} hasImage={hasImage} />}
          {tab === "export" && (
            <ExportPanel
              project={project}
              setProject={setProject}
              cw={outWidth}
              ch={outHeight}
              duration={duration}
              ready={duration > 0 && !busy}
              exp={exp}
              onStart={startExport}
              onCancel={cancelExport}
            />
          )}
        </div>
      </main>

      {/* floating bottom nav */}
      <nav className="pb-safe fixed inset-x-0 bottom-0 z-50 px-3 pb-[calc(0.75rem+var(--sab))]">
        <div className="mx-auto flex max-w-[500px] items-center justify-around rounded-3xl border border-white/10 bg-lowest/95 p-1.5 shadow-[0_8px_32px_rgba(0,0,0,0.65)]">
          {navItems.map((n) => {
            const active = tab === n.id;
            return (
              <button
                key={n.id}
                aria-current={active ? "page" : undefined}
                disabled={recording && n.id !== "export"}
                onClick={() => openTools(n.id)}
                className={cn(
                  "relative flex h-14 flex-1 flex-col items-center justify-center gap-1 rounded-2xl text-mute transition active:scale-95 disabled:opacity-45",
                  active && "bg-gradient-to-b from-cyan/15 to-transparent text-cyan",
                )}
              >
                {active && <span className="absolute inset-x-5 top-0 h-0.5 rounded-full bg-cyan shadow-[0_0_10px_rgba(0,242,254,0.9)]" />}
                {n.icon}
                <span className="text-[10.5px] font-medium">{n.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
