import { FRAME_MATTE } from "./framing";

export interface AudioAnalysis {
  peaks: number[];
  bpm: number;
  firstBeat: number;
  duration: number;
}

/* ---------- Audio analysis (waveform peaks + BPM) ---------- */
export function analyzeBuffer(buf: AudioBuffer): AudioAnalysis {
  const ch = buf.getChannelData(0);
  const ch2 = buf.numberOfChannels > 1 ? buf.getChannelData(1) : ch;
  const len = ch.length;

  // waveform peaks
  const N = 220;
  const peaks: number[] = [];
  const step = Math.max(1, Math.floor(len / N));
  let maxPeak = 0.0001;
  for (let i = 0; i < N; i++) {
    let m = 0;
    const s = i * step;
    const e = Math.min(len, s + step);
    const inc = Math.max(1, Math.floor((e - s) / 200));
    for (let j = s; j < e; j += inc) {
      const a = Math.abs((ch[j] + ch2[j]) / 2);
      if (a > m) m = a;
    }
    peaks.push(m);
    if (m > maxPeak) maxPeak = m;
  }
  const norm = peaks.map((p) => Math.pow(p / maxPeak, 0.8));

  // energy envelope
  const sr = buf.sampleRate;
  const hop = Math.max(64, Math.round(sr / 86));
  const maxFrames = Math.min(Math.floor(len / hop), Math.floor((sr * 90) / hop));
  const env = new Float32Array(maxFrames);
  for (let f = 0; f < maxFrames; f++) {
    let sum = 0;
    const s = f * hop;
    for (let j = 0; j < hop; j++) {
      const a = ch[s + j];
      sum += a * a;
    }
    env[f] = Math.sqrt(sum / hop);
  }
  const onset = new Float32Array(maxFrames);
  for (let i = 1; i < maxFrames; i++) onset[i] = Math.max(0, env[i] - env[i - 1]);
  const fr = sr / hop;

  let bestBpm = 120;
  let bestScore = -1;
  for (let bpm = 70; bpm <= 180; bpm += 0.5) {
    const lag = (60 / bpm) * fr;
    let score = 0;
    for (let i = 0; i + lag * 2 + 2 < maxFrames; i++) {
      const j = i + lag;
      const j0 = Math.floor(j);
      const fj = j - j0;
      const o2 = onset[j0] * (1 - fj) + onset[j0 + 1] * fj;
      const k = i + lag * 2;
      const k0 = Math.floor(k);
      const fk = k - k0;
      const o4 = onset[k0] * (1 - fk) + onset[k0 + 1] * fk;
      score += onset[i] * (o2 + o4 * 0.5);
    }
    if (score > bestScore) {
      bestScore = score;
      bestBpm = bpm;
    }
  }

  const period = (60 / bestBpm) * fr;
  let bestPhase = 0;
  let bestPS = -1;
  for (let ph = 0; ph < period; ph += 0.5) {
    let s = 0;
    for (let t = ph; t < maxFrames - 1; t += period) s += onset[Math.round(t)];
    if (s > bestPS) {
      bestPS = s;
      bestPhase = ph;
    }
  }

  return {
    peaks: norm,
    bpm: Math.round(bestBpm * 2) / 2,
    firstBeat: bestPhase / fr,
    duration: buf.duration,
  };
}

/* ---------- Demo synthwave beat ---------- */
export async function generateDemoBeat(): Promise<{ blob: Blob; buffer: AudioBuffer }> {
  const bpm = 124;
  const beat = 60 / bpm;
  const bars = 8;
  const dur = beat * 4 * bars + 0.5;
  const sr = 44100;
  const oc = new OfflineAudioContext(2, Math.ceil(dur * sr), sr);
  const master = oc.createGain();
  master.gain.value = 0.8;
  master.connect(oc.destination);

  const noiseBuf = oc.createBuffer(1, sr, sr);
  const nd = noiseBuf.getChannelData(0);
  for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;

  const kick = (t: number) => {
    const o = oc.createOscillator();
    const g = oc.createGain();
    o.frequency.setValueAtTime(150, t);
    o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
    g.gain.setValueAtTime(1, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.38);
    o.connect(g).connect(master);
    o.start(t);
    o.stop(t + 0.4);
  };
  const hat = (t: number, vol: number) => {
    const s = oc.createBufferSource();
    s.buffer = noiseBuf;
    const f = oc.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = 7500;
    const g = oc.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    s.connect(f).connect(g).connect(master);
    s.start(t);
    s.stop(t + 0.06);
  };
  const snare = (t: number) => {
    const s = oc.createBufferSource();
    s.buffer = noiseBuf;
    const f = oc.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 1800;
    const g = oc.createGain();
    g.gain.setValueAtTime(0.6, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    s.connect(f).connect(g).connect(master);
    s.start(t);
    s.stop(t + 0.22);
  };
  const bass = (t: number, freq: number, d: number) => {
    const o = oc.createOscillator();
    o.type = "sawtooth";
    o.frequency.value = freq;
    const f = oc.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(900, t);
    f.frequency.exponentialRampToValueAtTime(180, t + d);
    const g = oc.createGain();
    g.gain.setValueAtTime(0.32, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + d);
    o.connect(f).connect(g).connect(master);
    o.start(t);
    o.stop(t + d + 0.02);
  };
  const lead = (t: number, freq: number, d: number) => {
    for (const det of [-6, 6]) {
      const o = oc.createOscillator();
      o.type = "square";
      o.frequency.value = freq;
      o.detune.value = det;
      const f = oc.createBiquadFilter();
      f.type = "lowpass";
      f.frequency.value = 2600;
      const g = oc.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.06, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0005, t + d);
      o.connect(f).connect(g).connect(master);
      o.start(t);
      o.stop(t + d + 0.02);
    }
  };

  const roots = [55, 55, 43.65, 49]; // A1 A1 F1 G1
  const arp = [1, 1.5, 2, 3, 2, 1.5, 2, 3];
  for (let b = 0; b < bars; b++) {
    const root = roots[b % 4];
    for (let s = 0; s < 4; s++) {
      const t = (b * 4 + s) * beat;
      kick(t);
      if (s === 1 || s === 3) snare(t);
      hat(t + beat / 2, 0.35);
      if (s % 2 === 0) hat(t, 0.15);
    }
    for (let e = 0; e < 16; e++) {
      const t = (b * 16 + e) * (beat / 4);
      bass(t, root * (e % 4 === 3 ? 2 : 1), beat / 4.5);
    }
    if (b >= 2) {
      for (let e = 0; e < 8; e++) {
        const t = (b * 8 + e) * (beat / 2);
        lead(t, root * 4 * arp[e], beat / 2);
      }
    }
  }
  const buffer = await oc.startRendering();
  return { blob: bufferToWav(buffer), buffer };
}

function bufferToWav(buf: AudioBuffer): Blob {
  const nCh = buf.numberOfChannels;
  const len = buf.length * nCh * 2 + 44;
  const ab = new ArrayBuffer(len);
  const view = new DataView(ab);
  const ws = (o: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(o + i, s.charCodeAt(i));
  };
  ws(0, "RIFF");
  view.setUint32(4, len - 8, true);
  ws(8, "WAVE");
  ws(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, nCh, true);
  view.setUint32(24, buf.sampleRate, true);
  view.setUint32(28, buf.sampleRate * nCh * 2, true);
  view.setUint16(32, nCh * 2, true);
  view.setUint16(34, 16, true);
  ws(36, "data");
  view.setUint32(40, len - 44, true);
  const chans = Array.from({ length: nCh }, (_, c) => buf.getChannelData(c));
  let off = 44;
  for (let i = 0; i < buf.length; i++) {
    for (let c = 0; c < nCh; c++) {
      const s = Math.max(-1, Math.min(1, chans[c][i]));
      view.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      off += 2;
    }
  }
  return new Blob([ab], { type: "audio/wav" });
}

/* ---------- Clips ---------- */
export interface Clip {
  id: string;
  srcId: string; // clips cut from the same file share a srcId
  kind: "video" | "image";
  name: string;
  srcDur: number; // video: full source duration
  trimStart: number; // video: in-point inside the source
  dur: number; // length on the timeline (video: trimmed length, image: chosen length)
  w: number;
  h: number;
  thumb: string;
}

export const uid = () => Math.random().toString(36).slice(2, 10);

function waitForMedia(el: HTMLMediaElement, ready: () => boolean, ms: number) {
  if (ready()) return Promise.resolve();
  return new Promise<void>((resolve, reject) => {
    const events = ["loadedmetadata", "loadeddata", "canplay", "seeked", "error"];
    const finish = (error?: Error) => {
      clearTimeout(timer);
      clearInterval(poll);
      for (const event of events) el.removeEventListener(event, check);
      if (error) reject(error);
      else resolve();
    };
    const check = () => {
      if (el.error) finish(new Error("media decode"));
      else if (ready()) finish();
    };
    const timer = window.setTimeout(() => finish(new Error("media timeout")), ms);
    // Some mobile WebViews omit loadeddata when data saving is enabled.
    const poll = window.setInterval(check, 100);
    for (const event of events) el.addEventListener(event, check);
    check();
  });
}

const isPhoto = (file: File) => file.type.startsWith("image/") || /\.(avif|gif|jpe?g|png|webp|bmp|hei[cf])$/i.test(file.name);

function readPhoto<T>(file: File, render: (image: HTMLImageElement) => T): Promise<T> {
  const url = URL.createObjectURL(file);
  const image = new Image();
  image.decoding = "async";
  let watchdog = 0;
  return new Promise<T>((resolve, reject) => {
    watchdog = window.setTimeout(() => reject(new Error("photo timeout")), 12000);
    image.onerror = () => reject(new Error("photo decode"));
    image.onload = () => {
      try {
        if (!image.naturalWidth || !image.naturalHeight) throw new Error("photo dimensions");
        resolve(render(image));
      } catch (error) {
        reject(error);
      }
    };
    image.src = url;
  }).finally(() => {
    clearTimeout(watchdog);
    image.onload = image.onerror = null;
    image.removeAttribute("src");
    URL.revokeObjectURL(url);
  });
}

function snapshot(source: CanvasImageSource, width: number, height: number, maxEdge: number) {
  const scale = Math.min(1, maxEdge / Math.max(width, height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx || ctx.isContextLost?.()) throw new Error("canvas unavailable");
  ctx.fillStyle = FRAME_MATTE;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
  return canvas;
}

function thumbnail(source: CanvasImageSource, width: number, height: number) {
  const canvas = snapshot(source, width, height, 256);
  try {
    const url = canvas.toDataURL("image/jpeg", 0.76);
    if (!url.startsWith("data:image/")) throw new Error("thumbnail unavailable");
    return url;
  } finally {
    canvas.width = canvas.height = 0;
  }
}

export interface Source {
  el: HTMLVideoElement | HTMLCanvasElement;
  w: number;
  h: number;
}
export interface Visual {
  cur: Source | null;
  frameKey: string;
  poster: string;
  kind: "video" | "image" | "none";
  prog: number;
  next: Source | null;
  alpha: number;
  fadeFrom: string;
  fadeIn: number;
  /** export only: the video cannot be decoded, the last good frame is held */
  frozen: boolean;
}

type BeforeRun = (time: number) => boolean;
type Track = "video" | "audio";
type MediaTarget = Track | "image";
export interface PlaybackIssue {
  target: MediaTarget | "preview";
  clipId?: string;
  message: string;
}

const METADATA = HTMLMediaElement.HAVE_METADATA;
const CURRENT_DATA = HTMLMediaElement.HAVE_CURRENT_DATA;
const FUTURE_DATA = HTMLMediaElement.HAVE_FUTURE_DATA;
const PROBE_DELAY = 160;
const REOPEN_DELAY = 1800;
const WAIT_LIMIT = 6500;
const STALL_LIMIT = 1700;

function matchesMedia(el: HTMLMediaElement, url: string | null) {
  return !!url && el.src === url && (!el.currentSrc || el.currentSrc === url);
}

export class Engine {
  private video = this.makeVideo();
  private audio = this.makeAudio();
  private videoHost: HTMLElement | null = null;
  private videoNode: MediaElementAudioSourceNode | null = null;
  private audioNode: MediaElementAudioSourceNode | null = null;
  ctx: AudioContext | null = null;
  analyser: AnalyserNode | null = null;
  musicGain: GainNode | null = null;
  videoGain: GainNode | null = null;
  speaker: GainNode | null = null;
  recDest: MediaStreamAudioDestinationNode | null = null;

  clips: Clip[] = [];
  starts: number[] = [];
  total = 0;
  private files = new Map<string, File>();
  private imgCache = new Map<string, HTMLCanvasElement>();
  private imgErrors = new Set<string>();
  private photoRequest: Promise<void> | null = null;
  private stagedPhoto: { id: string; canvas: HTMLCanvasElement } | null = null;
  private importingClips = false;
  private curIdx = -1;
  private videoSrc = "";
  private videoUrl = "";
  private videoSeek: number | null = null;
  private audioSeek: number | null = null;
  private audioFile: Blob | null = null;
  private restarted: Partial<Record<MediaTarget, true>> = {};
  private probed: Partial<Record<Track, true>> = {};
  private requests: Partial<Record<Track, object>> = {};
  private lastIssue: PlaybackIssue | null = null;

  hasAudio = false;
  audioDur = 0;
  offset = 0;
  loop = true;
  fade = 0.4;
  playing = false;
  started = false;
  musicVol = 0.9;
  videoVol = 0;
  speakerOn = true;
  /**
   * Export mode. A video that stops delivering frames no longer aborts the render:
   * the last good frame is held, the project clock keeps running and the music continues.
   */
  tolerant = false;
  degraded: string[] = [];
  private frozenSrcs = new Set<string>();
  onPlaybackError: ((issue: PlaybackIssue) => void) | null = null;

  private T = 0;
  private t0 = 0;
  private waitSince = 0;
  private passSince = 0;
  private lastGoodTime = 0;
  private lastAudioTry = 0;
  private lastAudioSeek = -Infinity;
  private lastSync = 0;
  private videoPosition = 0;
  private videoProgressAt = 0;
  private videoProgressMark = 0;
  private audioPosition = 0;
  private audioProgressAt = 0;
  private audioProgressMark = 0;
  private audioUrl: string | null = null;

  constructor() {
    document.body.appendChild(this.audio);
  }

  private makeVideo() {
    const video = document.createElement("video");
    video.playsInline = true;
    video.disablePictureInPicture = true;
    video.disableRemotePlayback = true;
    video.preload = "auto";
    video.muted = true;
    video.className = "h-full w-full object-cover";
    video.addEventListener("loadedmetadata", () => {
      if (video === this.video) this.applyVideoSeek();
    });
    return video;
  }

  private makeAudio() {
    const audio = new Audio();
    audio.preload = "auto";
    audio.addEventListener("loadedmetadata", () => {
      if (audio === this.audio) this.applyAudioSeek();
    });
    return audio;
  }

  mountVideo(host: HTMLElement) {
    this.videoHost = host;
    host.replaceChildren(this.video);
    return () => {
      if (this.videoHost !== host) return;
      this.video.remove();
      this.videoHost = null;
    };
  }

  /* ----- audio graph ----- */
  ensureAudio() {
    if (!this.ctx || this.ctx.state === "closed") {
      if (this.ctx) {
        this.resetVideoElement();
        this.resetAudioElement();
        this.ctx = null;
      }
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AC();
      this.ctx = ctx;
      this.analyser = ctx.createAnalyser();
      this.analyser.fftSize = 2048;
      this.analyser.smoothingTimeConstant = 0.35;
      this.analyser.minDecibels = -85;
      this.analyser.maxDecibels = -25;
      this.musicGain = ctx.createGain();
      this.videoGain = ctx.createGain();
      this.speaker = ctx.createGain();
      this.recDest = ctx.createMediaStreamDestination();
      const mix = ctx.createGain();
      this.audioNode = ctx.createMediaElementSource(this.audio);
      this.videoNode = ctx.createMediaElementSource(this.video);
      this.audioNode.connect(this.musicGain);
      this.videoNode.connect(this.videoGain);
      this.musicGain.connect(mix);
      this.videoGain.connect(mix);
      mix.connect(this.analyser);
      mix.connect(this.speaker);
      mix.connect(this.recDest);
      this.speaker.connect(ctx.destination);
      this.applyVolumes();
    }
    if (this.ctx.state !== "running") void this.ctx.resume().catch(() => {});
  }

  applyVolumes() {
    this.video.muted = this.videoVol === 0;
    if (this.musicGain) this.musicGain.gain.value = this.started ? this.musicVol : 0;
    if (this.videoGain) this.videoGain.gain.value = this.started ? this.videoVol : 0;
    if (this.speaker) this.speaker.gain.value = this.speakerOn ? 1 : 0;
  }

  /* ----- timeline model ----- */
  get hasClips() {
    return this.clips.length > 0;
  }
  get duration() {
    return this.hasClips ? this.total : this.hasAudio ? this.audioDur : 0;
  }
  get effOffset() {
    return this.hasClips ? this.offset : 0;
  }
  private get waitLimit() {
    return this.tolerant ? 10000 : WAIT_LIMIT;
  }
  private get stallLimit() {
    return this.tolerant ? 4500 : STALL_LIMIT;
  }
  private get frozen() {
    const clip = this.clip;
    return this.tolerant && clip?.kind === "video" && this.frozenSrcs.has(clip.srcId);
  }
  resetDegraded() {
    this.frozenSrcs.clear();
    this.degraded = [];
  }
  /** switch the current video clip to the held-frame fallback; false when not applicable */
  private freeze() {
    const clip = this.clip;
    if (!this.tolerant || clip?.kind !== "video") return false;
    this.frozenSrcs.add(clip.srcId);
    if (!this.degraded.includes(clip.name)) this.degraded.push(clip.name);
    this.releaseVideo();
    this.resetGate(performance.now());
    return true;
  }
  private giveUp(target: PlaybackIssue["target"], message?: string) {
    if (target === "video" && this.freeze()) return;
    this.fail(target, message);
  }
  get waiting() {
    return this.playing && !this.started;
  }
  get recovering() {
    return this.waiting && !!(this.restarted.video || this.restarted.audio || this.restarted.image);
  }
  private get clip() {
    return this.clips[this.curIdx];
  }
  get activeClipId() {
    return this.clip?.id;
  }
  get previewUnavailable() {
    const clip = this.clip;
    if (!clip || this.importingClips || this.frozen || this.source(clip)) return false;
    const failed = clip.kind === "image" ? this.imgErrors.has(clip.srcId) : this.videoSrc === clip.srcId && !!this.video.error;
    return failed || performance.now() - this.waitSince > 8500;
  }
  private get clipEnd() {
    return this.clip ? this.starts[this.curIdx] + this.clip.dur : this.duration;
  }
  get time() {
    if (!this.started) return this.T;
    const clip = this.clip;
    // The active decoder, not a wall clock, advances a video clip.
    if (clip?.kind === "video" && !this.frozen) {
      const t = this.starts[this.curIdx] + this.video.currentTime - clip.trimStart;
      if (this.video.ended && this.clipEnd - t <= 0.08) return this.clipEnd;
      return Math.min(this.clipEnd, Math.max(this.T, this.lastGoodTime, t));
    }
    if (!clip && this.hasAudio) return Math.min(this.duration, Math.max(this.T, this.lastGoodTime, this.audio.currentTime));
    return Math.min(this.clipEnd, this.T + (performance.now() - this.t0) / 1000);
  }

  addSource(srcId: string, file: File) {
    this.files.set(srcId, file);
  }

  sourceFile(srcId: string) {
    return this.files.get(srcId);
  }

  async importClips(files: readonly File[], replace?: Clip) {
    const added: Clip[] = [];
    const failed: string[] = [];
    this.pause();
    this.importingClips = true;
    try {
      await this.photoRequest;
      for (const file of files) {
        const srcId = uid();
        const base = { id: replace?.id ?? uid(), srcId, name: file.name, trimStart: 0 };
        try {
          let clip: Clip;
          if (isPhoto(file)) {
            const photo = await readPhoto(file, (image) => {
              const { naturalWidth: w, naturalHeight: h } = image;
              const thumb = thumbnail(image, w, h);
              return { w, h, thumb, canvas: snapshot(image, w, h, 1920) };
            });
            this.clearStagedPhoto();
            this.stagedPhoto = { id: srcId, canvas: photo.canvas };
            clip = { ...base, kind: "image", srcDur: 0, dur: replace?.dur ?? 4, w: photo.w, h: photo.h, thumb: photo.thumb };
          } else {
            // Use the monitor's decoder for the probe. If this clip is selected, keep it open.
            this.openVideo(srcId, file, 0);
            const v = this.video;
            await waitForMedia(v, () => matchesMedia(v, this.videoUrl) && v.readyState >= METADATA, 10000);
            const { duration: srcDur, videoWidth: w, videoHeight: h } = v;
            if (!Number.isFinite(srcDur) || srcDur <= 0 || !w || !h) throw new Error("video metadata");
            let thumb = "";
            try {
              await waitForMedia(v, () => matchesMedia(v, this.videoUrl) && v.readyState >= CURRENT_DATA && !v.seeking, 750);
              thumb = thumbnail(v, w, h);
            } catch {
              if (v.error) throw new Error("video decode");
            }
            this.clearStagedPhoto();
            clip = { ...base, kind: "video", srcDur, dur: Math.min(replace?.dur ?? srcDur, srcDur), w, h, thumb };
          }
          this.addSource(srcId, file);
          added.push(clip);
        } catch {
          if (this.videoSrc === srcId) this.releaseVideo();
          failed.push(file.name);
        }
      }
    } finally {
      this.importingClips = false;
    }
    return { added, failed };
  }

  /**
   * True when only durations changed (same clips, same order, same sources) and the active
   * clip still starts at the same point of its source. Then no decoder has to be reopened.
   */
  private durationOnly(next: Clip[]) {
    const idx = this.curIdx;
    if (idx < 0 || next.length !== this.clips.length) return false;
    for (let i = 0; i < next.length; i++) {
      const a = this.clips[i];
      const b = next[i];
      if (a.id !== b.id || a.srcId !== b.srcId || a.kind !== b.kind) return false;
    }
    // the active clip and the one preloaded behind it must keep their source start
    for (const i of [idx, idx + 1]) {
      if (next[i] && next[i].trimStart !== this.clips[i].trimStart) return false;
    }
    return true;
  }

  setClips(clips: Clip[], focusId?: string) {
    const current = this.clip;
    const offset = current ? this.time - this.starts[this.curIdx] : 0;
    const soft = focusId === undefined && this.durationOnly(clips);
    this.pause();
    if (soft) {
      this.clips = clips;
      this.starts = [];
      let sum = 0;
      for (const c of clips) {
        this.starts.push(sum);
        sum += c.dur;
      }
      this.total = sum;
      const idx = this.curIdx;
      const t = Math.min(this.starts[idx] + Math.max(0, Math.min(offset, clips[idx].dur - 0.001)), this.duration);
      // keep the open decoder and photo cache; only re-arm the playback gate at the new position
      this.hold(t, performance.now(), true);
      return;
    }
    this.clips = clips;
    this.starts = [];
    let acc = 0;
    for (const c of clips) {
      this.starts.push(acc);
      acc += c.dur;
    }
    this.total = acc;
    const used = new Set(clips.map((c) => c.srcId));
    for (const id of this.files.keys()) {
      if (!used.has(id)) {
        this.files.delete(id);
        this.imgErrors.delete(id);
      }
    }
    const idx = clips.findIndex((clip) => clip.id === (focusId ?? current?.id));
    if (idx >= 0) {
      const position = focusId ? 0 : Math.max(0, Math.min(offset, clips[idx].dur - 0.001));
      this.seek(this.starts[idx] + position);
    } else this.seek(current && !clips.length ? 0 : this.T);
  }

  private indexAt(t: number): number {
    if (!this.clips.length) return -1;
    for (let i = 0; i < this.clips.length; i++) {
      if (t < this.starts[i] + this.clips[i].dur) return i;
    }
    return this.clips.length - 1;
  }

  private releaseVideo() {
    delete this.requests.video;
    this.videoSeek = null;
    if (!this.videoSrc) return;
    const url = this.videoUrl;
    this.videoUrl = this.videoSrc = "";
    this.video.pause();
    this.video.removeAttribute("src");
    this.video.load();
    URL.revokeObjectURL(url);
  }

  private resetVideoElement() {
    this.releaseVideo();
    this.videoNode?.disconnect();
    this.videoNode = null;
    const old = this.video;
    this.video = this.makeVideo();
    old.remove();
    this.videoHost?.appendChild(this.video);
    if (this.ctx && this.ctx.state !== "closed" && this.videoGain) {
      this.videoNode = this.ctx.createMediaElementSource(this.video);
      this.videoNode.connect(this.videoGain);
    }
    this.applyVolumes();
  }

  private applyVideoSeek() {
    if (this.videoSeek === null || !matchesMedia(this.video, this.videoUrl) || this.video.readyState < METADATA || this.video.error) return;
    const target = this.videoSeek;
    this.videoSeek = null;
    if (Math.abs(this.video.currentTime - target) > 0.018) this.video.currentTime = target;
  }

  private openVideo(srcId: string, file: File, target: number) {
    this.releaseVideo();
    this.videoUrl = URL.createObjectURL(file);
    this.videoSrc = srcId;
    this.videoSeek = target;
    this.video.src = this.videoUrl;
    this.video.load();
  }

  private prepareVideo(clip: Clip, time: number) {
    const target = Math.min(Math.max(0, clip.srcDur - 0.001), Math.max(0, time));
    if (this.videoSrc !== clip.srcId || this.video.error) {
      const file = this.files.get(clip.srcId);
      if (!file) return;
      this.openVideo(clip.srcId, file, target);
    } else {
      this.videoSeek = target;
      this.applyVideoSeek();
    }
  }

  private photoIds() {
    return [this.clip, this.clips[this.curIdx + 1]].filter((c) => c?.kind === "image").map((c) => c.srcId);
  }

  private clearStagedPhoto() {
    const staged = this.stagedPhoto;
    if (staged) staged.canvas.width = staged.canvas.height = 0;
    this.stagedPhoto = null;
  }

  private preparePhotos() {
    const ids = this.photoIds();
    for (const [id, canvas] of this.imgCache) {
      if (!ids.includes(id)) {
        canvas.width = canvas.height = 0;
        this.imgCache.delete(id);
      }
    }
    if (this.importingClips) return;
    const staged = this.stagedPhoto;
    if (staged && ids.includes(staged.id)) {
      this.imgCache.set(staged.id, staged.canvas);
      this.stagedPhoto = null;
    } else this.clearStagedPhoto();
    if (this.photoRequest) return;
    const id = ids.find((id) => !this.imgCache.has(id) && !this.imgErrors.has(id) && this.files.has(id));
    if (!id) return;
    this.photoRequest = readPhoto(this.files.get(id)!, (image) => {
      if (this.photoIds().includes(id)) this.imgCache.set(id, snapshot(image, image.naturalWidth, image.naturalHeight, 1920));
    }).catch(() => {
      if (this.files.has(id)) this.imgErrors.add(id);
    }).finally(() => {
      this.photoRequest = null;
      this.preparePhotos();
    });
  }

  private enter(idx: number, t: number, keepVideo = false) {
    this.curIdx = idx;
    const clip = this.clip;
    const next = this.clips[idx + 1];
    // One decoder: preload a video only when its predecessor is a still image.
    if (!keepVideo) {
      delete this.requests.video;
      this.video.pause();
      const skip = (c?: Clip) => this.tolerant && !!c && this.frozenSrcs.has(c.srcId);
      if (clip?.kind === "video" && !skip(clip)) this.prepareVideo(clip, clip.trimStart + t - this.starts[idx]);
      else if (next?.kind === "video" && !skip(next)) this.prepareVideo(next, next.trimStart);
      else this.releaseVideo();
    }
    this.preparePhotos();
  }

  private source(clip: Clip | undefined): Source | null {
    if (!clip) return null;
    if (clip.kind === "image") {
      const c = this.imgCache.get(clip.srcId);
      return c ? { el: c, w: c.width, h: c.height } : null;
    }
    if (this.tolerant && this.frozenSrcs.has(clip.srcId)) return null;
    const el = this.video;
    if (this.videoSrc !== clip.srcId || !matchesMedia(el, this.videoUrl) || this.videoSeek !== null || el.seeking || el.error || el.readyState < CURRENT_DATA || !el.videoWidth) return null;
    return { el, w: el.videoWidth, h: el.videoHeight };
  }

  private isContinuous(a: Clip, b: Clip) {
    return a.kind === "video" && b.kind === "video" && a.srcId === b.srcId && Math.abs(a.trimStart + a.dur - b.trimStart) < 0.025;
  }

  visual(t: number): Visual {
    const idx = this.curIdx;
    const clip = this.clip;
    if (!clip) return { cur: null, frameKey: "", poster: "", kind: "none", prog: 0, next: null, alpha: 0, fadeFrom: "", fadeIn: 1, frozen: false };
    const elapsed = Math.max(0, t - this.starts[idx]);
    const prev = this.clips[idx - 1];
    const next = this.clips[idx + 1];
    const fade = Math.min(this.fade, clip.dur / 2);
    const videoPair = clip.kind === "video" && prev?.kind === "video" && !this.isContinuous(prev, clip);
    return {
      cur: this.source(clip), frameKey: `${clip.id}/${clip.srcId}`, poster: clip.thumb, kind: clip.kind, prog: Math.min(1, elapsed / clip.dur),
      next: fade && elapsed > clip.dur - fade && next && (clip.kind === "image" || next.kind === "image") ? this.source(next) : null,
      alpha: fade ? Math.min(1, Math.max(0, 1 - (clip.dur - elapsed) / fade)) : 0,
      fadeFrom: videoPair && elapsed < fade ? `${prev.id}/${prev.srcId}` : "",
      fadeIn: fade ? Math.min(1, elapsed / fade) : 1,
      frozen: this.frozen,
    };
  }

  /* ----- music ----- */
  async loadAudio(file: Blob, decoded?: AudioBuffer): Promise<AudioAnalysis> {
    this.pause();
    this.audioSeek = null;
    const url = URL.createObjectURL(file);
    const previous = this.audioUrl;
    this.audioUrl = url;
    this.audio.src = url;
    this.audio.load();
    try {
      await waitForMedia(this.audio, () => matchesMedia(this.audio, url) && this.audio.readyState >= METADATA, 10000);
      if (!Number.isFinite(this.audio.duration) || this.audio.duration <= 0) throw new Error("audio duration");
    } catch (error) {
      this.audioUrl = previous;
      if (previous) this.audio.src = previous;
      else this.audio.removeAttribute("src");
      this.audio.load();
      URL.revokeObjectURL(url);
      this.positionAudio(this.T);
      throw error;
    }
    if (previous) URL.revokeObjectURL(previous);
    this.audioFile = file;
    this.hasAudio = true;
    this.audioDur = this.audio.duration;
    if (this.lastIssue?.target === "audio") this.lastIssue = null;
    let a: AudioAnalysis;
    try {
      // Skip whole-file analysis for long tracks; playback still reads the Blob directly.
      if (!decoded && (this.audioDur > 300 || file.size > 48 * 1024 * 1024)) throw new Error("analysis budget");
      const buffer = decoded ?? (await new OfflineAudioContext(2, 1, 11025).decodeAudioData(await file.arrayBuffer()));
      a = analyzeBuffer(buffer);
    } catch {
      a = { peaks: Array(220).fill(0.35), bpm: 0, firstBeat: 0, duration: this.audioDur };
    }
    this.audio.loop = false;
    this.T = Math.min(this.T, this.duration);
    this.positionAudio(this.T);
    return a;
  }

  clearAudio() {
    this.pause();
    this.releaseAudio();
    this.audioFile = null;
    this.hasAudio = false;
    this.audioDur = 0;
    this.T = Math.min(this.T, this.duration);
    if (this.lastIssue?.target === "audio") this.lastIssue = null;
  }

  private releaseAudio() {
    delete this.requests.audio;
    const url = this.audioUrl;
    this.audioSeek = this.audioUrl = null;
    this.audio.pause();
    this.audio.removeAttribute("src");
    this.audio.load();
    if (url) URL.revokeObjectURL(url);
  }

  private resetAudioElement() {
    this.releaseAudio();
    this.audioNode?.disconnect();
    this.audioNode = null;
    const old = this.audio;
    this.audio = this.makeAudio();
    old.remove();
    document.body.appendChild(this.audio);
    if (this.ctx && this.ctx.state !== "closed" && this.musicGain) {
      this.audioNode = this.ctx.createMediaElementSource(this.audio);
      this.audioNode.connect(this.musicGain);
    }
    if (this.audioFile) {
      this.audioUrl = URL.createObjectURL(this.audioFile);
      this.audio.src = this.audioUrl;
      this.audio.loop = this.loop && this.hasClips;
      this.audio.load();
      this.positionAudio(this.T);
    }
  }

  private musicTarget(t: number): number {
    if (!this.hasAudio) return -1;
    const tm = t - this.effOffset;
    if (tm < 0) return -1;
    if (this.loop && this.hasClips) return tm % this.audioDur;
    return tm >= this.audioDur ? -1 : tm;
  }

  private positionAudio(t: number) {
    if (!this.hasAudio) return;
    const target = this.musicTarget(t);
    this.audio.playbackRate = 1;
    this.audioSeek = target < 0 ? null : target;
    if (target < 0) {
      delete this.requests.audio;
      this.audio.pause();
    } else this.applyAudioSeek();
  }

  private applyAudioSeek() {
    if (this.audioSeek === null || !matchesMedia(this.audio, this.audioUrl) || this.audio.readyState < METADATA || this.audio.error) return;
    const target = this.audioSeek;
    this.audioSeek = null;
    if (Math.abs(this.audio.currentTime - target) > 0.024) this.audio.currentTime = target;
  }

  private playElement(track: Track) {
    if (this.requests[track]) return;
    const el = this[track];
    const request = this.requests[track] = {};
    const onRejected = (error: unknown) => {
      if (this.requests[track] !== request || !this.playing) return;
      delete this.requests[track];
      if (error instanceof DOMException && error.name === "NotAllowedError") {
        this.fail(track, "پخش نیاز به اجازه دارد. روی «تلاش دوباره» بزنید.");
      } else this.recover(track, this.time);
    };
    try {
      void Promise.resolve(el.play()).then(() => {
        if (this.requests[track] === request) delete this.requests[track];
      }, onRejected);
    } catch (error) { queueMicrotask(() => onRejected(error)); }
  }

  private syncMusic(t: number, now: number) {
    if (!this.hasAudio) return;
    const loopNow = this.loop && this.hasClips;
    if (this.audio.loop !== loopNow) this.audio.loop = loopNow;
    const target = this.musicTarget(t);
    if (target < 0) {
      delete this.requests.audio;
      if (!this.audio.paused) this.audio.pause();
      this.audioProgressAt = now;
      return;
    }
    if (this.audio.seeking || this.audio.readyState < CURRENT_DATA) return;
    if (this.audio.paused || this.audio.ended) {
      if (now - this.lastAudioTry > 300) {
        this.lastAudioTry = now;
        this.positionAudio(t);
        this.playElement("audio");
      }
      return;
    }
    if (!this.hasClips || this.audio.readyState < FUTURE_DATA || now - this.lastSync < 150) return;
    this.lastSync = now;
    let drift = this.audio.currentTime - target;
    if (loopNow) {
      if (drift > this.audioDur / 2) drift -= this.audioDur;
      else if (drift < -this.audioDur / 2) drift += this.audioDur;
    }
    const ad = Math.abs(drift);
    if (ad > 0.5 && now - this.lastAudioSeek > 1700) {
      this.lastAudioSeek = now;
      this.positionAudio(t);
    } else {
      const rate = ad > 0.045 ? 1 - Math.max(-0.04, Math.min(0.04, drift * 0.45)) : 1;
      if (Math.abs(this.audio.playbackRate - rate) > 0.004) this.audio.playbackRate = rate;
    }
  }

  private fail(target: PlaybackIssue["target"], message?: string) {
    const clip = this.clip;
    const issue: PlaybackIssue = {
      target,
      clipId: target === "video" || target === "image" ? clip?.id : undefined,
      message: message ?? (target === "video" ? `پخش ویدئوی «${clip?.name ?? ""}» بازیابی نشد. اگر تکرار شد، نسخه MP4 با کدک H.264 را جایگزین کنید.`
        : target === "audio" ? "پخش موزیک بازیابی نشد. اگر تکرار شد، نسخه MP3 یا WAV را جایگزین کنید."
          : target === "image" ? `عکس «${clip?.name ?? ""}» باز نشد. نسخه JPG یا PNG را امتحان کنید.`
            : "رسم تصویر از سر گرفته نشد. دوباره تلاش کنید."),
    };
    this.pause();
    this.lastIssue = issue;
    this.onPlaybackError?.(issue);
  }

  reportPreviewFailure() {
    this.fail("preview");
  }

  private pauseTracks() {
    this.requests = {};
    this.video.pause();
    this.audio.pause();
  }

  private resetGate(now: number, clearRecoveries = true) {
    this.waitSince = this.passSince = now;
    if (clearRecoveries) this.restarted = {};
    this.probed = {};
  }

  private hold(t: number, now: number, fresh = false) {
    if (fresh || (this.started && this.lastGoodTime - this.T > 0.7)) this.resetGate(now, fresh);
    else if (this.started) this.passSince = now;
    this.T = this.lastGoodTime = t;
    this.started = false;
    this.pauseTracks();
    this.applyVolumes();
    this.positionAudio(t);
  }

  waitForFrame() {
    if (this.started) this.hold(this.time, performance.now());
  }

  private recover(target: MediaTarget, t: number) {
    if (!this.playing) return;
    const now = performance.now();
    if (this.started) this.hold(t, now);
    if (this.lastGoodTime - this.videoProgressMark >= 1 || this.lastGoodTime - this.audioProgressMark >= 1) this.restarted = {};
    if (this.restarted[target] && now - this.waitSince <= this.waitLimit) {
      this.giveUp(target);
      return;
    }
    if (now - this.waitSince > this.waitLimit) {
      this.giveUp(target);
      return;
    }
    this.restarted[target] = true;
    this.probed = {};
    this.passSince = now;
    this.pauseTracks();
    try {
      this.reopen(target);
      this.positionAudio(t);
    } catch { this.giveUp(target); }
  }

  private reopen(target: PlaybackIssue["target"]) {
    if (target === "video") {
      this.resetVideoElement();
      const clip = this.clip;
      if (clip?.kind === "video") this.prepareVideo(clip, clip.trimStart + this.T - this.starts[this.curIdx]);
    } else if (target === "audio") this.resetAudioElement();
    else if (target === "image" && this.clip?.kind === "image") {
      this.imgErrors.delete(this.clip.srcId);
      this.preparePhotos();
    }
  }

  private visualsReady() {
    return !this.clip || this.frozen || !!this.source(this.clip);
  }

  private startVideo(now: number) {
    if (this.clip?.kind !== "video" || this.frozen) return;
    this.videoProgressAt = now;
    this.videoPosition = this.video.currentTime;
    if (this.video.paused) this.playElement("video");
  }

  private nudge(track: Track) {
    const el = this[track];
    if (!this.probed[track] && el.paused) {
      this.probed[track] = true;
      this.playElement(track);
    }
  }

  private pinProbe(track: Track, target: number) {
    const el = this[track];
    if (!this.probed[track] || el.seeking || el.currentTime - target < 0.12) return;
    // A silent probe may wake the decoder, but must not skip the start of a clip.
    delete this.requests[track];
    el.pause();
    if (track === "audio") this.positionAudio(this.T);
    else {
      this.videoSeek = target;
      this.applyVideoSeek();
    }
  }

  private tryBegin(now: number, beforeRun?: BeforeRun) {
    const clip = this.clip;
    const hasVideo = clip?.kind === "video" && !this.frozen;
    const audioTarget = this.musicTarget(this.T);
    const needsMusic = audioTarget >= 0;
    if (hasVideo && this.video.error) return this.recover("video", this.T);
    if (needsMusic && this.audio.error) return this.recover("audio", this.T);
    if (clip?.kind === "image" && this.imgErrors.has(clip.srcId)) return this.recover("image", this.T);

    if (hasVideo) this.pinProbe("video", clip.trimStart + this.T - this.starts[this.curIdx]);
    if (needsMusic) this.pinProbe("audio", audioTarget);
    const visualReady = this.visualsReady();
    const musicReady = !needsMusic || (this.audioSeek === null && !this.audio.seeking && this.audio.readyState >= CURRENT_DATA);
    const soundReady = (!needsMusic && (!hasVideo || this.videoVol === 0)) || this.ctx?.state === "running";
    const ready = visualReady && musicReady && soundReady;
    if (ready && (!beforeRun || beforeRun(this.T))) {
      this.started = true;
      this.t0 = performance.now();
      this.audioProgressAt = this.t0;
      this.audioPosition = this.audio.currentTime;
      this.applyVolumes();
      this.startVideo(this.t0);
      if (needsMusic) {
        this.lastAudioTry = this.t0;
        if (this.audio.paused) this.playElement("audio");
      }
      return;
    }

    if (now - this.waitSince > this.waitLimit) {
      if (!visualReady && clip) this.giveUp(clip.kind);
      else if (!musicReady || !soundReady) this.fail("audio", "صدا آماده نشد. برای فعال کردن دوبارهٔ صدا روی «تلاش دوباره» بزنید.");
      else this.fail("preview");
      return;
    }
    if (now - this.passSince > REOPEN_DELAY) {
      if (!musicReady && !this.restarted.audio) return this.recover("audio", this.T);
      if (hasVideo && !visualReady && !this.restarted.video) return this.recover("video", this.T);
    }
    // Some WebViews never buffer the first frame while paused. Prime without audio.
    if (now - this.passSince > PROBE_DELAY) {
      if (!musicReady && matchesMedia(this.audio, this.audioUrl)) this.nudge("audio");
      if (hasVideo && !visualReady && musicReady && matchesMedia(this.video, this.videoUrl)) this.nudge("video");
    }
  }

  tick(beforeRun?: BeforeRun) {
    this.applyVideoSeek();
    this.applyAudioSeek();
    if (!this.playing) return;
    const now = performance.now();
    if (this.waiting) {
      this.tryBegin(now, beforeRun);
      return;
    }
    const clip = this.clip;
    const end = this.clipEnd;
    let t = this.time;
    if (clip?.kind === "video" && !this.frozen) {
      if (this.video.error) return this.recover("video", this.lastGoodTime);
      if (!this.source(clip)) {
        this.hold(this.lastGoodTime, now);
        return;
      }
      if (this.video.ended && end - t <= 0.08) t = end;
      if (t < end) {
        if (Math.abs(this.video.currentTime - this.videoPosition) > 0.005) {
          this.videoPosition = this.video.currentTime;
          this.videoProgressAt = now;
          if (this.video.currentTime - this.videoProgressMark > 0.5) {
            this.videoProgressMark = this.video.currentTime;
            this.restarted.video = undefined;
          }
        }
        if (now - this.videoProgressAt > this.stallLimit) return this.recover("video", this.lastGoodTime);
      }
    }
    const audioTarget = this.musicTarget(t);
    if (audioTarget >= 0) {
      if (this.audio.error) return this.recover("audio", this.lastGoodTime);
      if (Math.abs(this.audio.currentTime - this.audioPosition) > 0.005) {
        this.audioPosition = this.audio.currentTime;
        this.audioProgressAt = now;
        if (this.audio.currentTime - this.audioProgressMark > 0.5) {
          this.audioProgressMark = this.audio.currentTime;
          this.restarted.audio = undefined;
        }
      }
      if (now - this.audioProgressAt > this.stallLimit && !(this.audio.ended && this.audioDur - audioTarget < 0.15)) {
        return this.recover("audio", this.lastGoodTime);
      }
    }
    this.lastGoodTime = t;
    if (t >= end && clip && this.curIdx + 1 < this.clips.length) {
      const next = this.clips[this.curIdx + 1];
      const continuous = this.isContinuous(clip, next);
      t = this.T = end;
      this.t0 = now;
      this.resetGate(now);
      this.enter(this.curIdx + 1, end, continuous);
      if (!this.visualsReady()) {
        this.hold(end, now);
        return;
      }
      this.startVideo(now);
    }
    this.syncMusic(t, now);
  }

  play(beforeRun?: BeforeRun, retry?: PlaybackIssue["target"]) {
    if (this.duration <= 0 || this.playing) return;
    this.ensureAudio();
    const target = retry ?? this.lastIssue?.target;
    this.seek(this.T >= this.duration - 0.015 ? 0 : this.T, target);
    this.audio.loop = this.hasClips && this.loop;
    this.playing = true;
    this.tryBegin(this.waitSince, beforeRun);
  }

  pause() {
    this.T = this.time;
    this.playing = false;
    this.started = false;
    this.pauseTracks();
    this.applyVolumes();
  }

  seek(t: number, retry?: PlaybackIssue["target"]) {
    const time = Math.max(0, Math.min(this.duration, t));
    this.lastIssue = null;
    this.hold(time, performance.now(), true);
    if (retry === "video") this.resetVideoElement();
    else if (retry === "audio") this.resetAudioElement();
    this.enter(this.indexAt(time), time);
    if (retry === "image") this.reopen("image");
  }
}

export const engine = new Engine();
