package com.iranmusicstudio;

import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // keep screen awake while editing / rendering
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (getBridge() != null) {
            WebView wv = getBridge().getWebView();
            if (wv != null) {
                WebSettings s = wv.getSettings();
                // allow programmatic video/audio playback (needed for background render flow)
                s.setMediaPlaybackRequiresUserGesture(false);
            }
        }
    }
}
