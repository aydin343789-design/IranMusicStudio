import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.iranmusicstudio",
  appName: "استودیو پهلوی",
  webDir: "dist",
  backgroundColor: "#0f131d",
  android: {
    allowMixedContent: false,
    webContentsDebuggingEnabled: false,
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
