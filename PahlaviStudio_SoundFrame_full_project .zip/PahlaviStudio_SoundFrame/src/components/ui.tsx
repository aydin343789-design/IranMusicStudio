import type { ReactNode } from "react";
import { cn } from "../utils/cn";

export function Card({
  title,
  icon,
  right,
  children,
  className,
}: {
  title?: string;
  icon?: ReactNode;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-xl bg-low/90 p-3 shadow-lg", className)}>
      {title && (
        <header className="mb-3 flex items-center justify-between gap-2">
          <h3 className="flex items-center gap-2 text-[13px] font-semibold text-ink">
            <span className="text-cyan-dim">{icon}</span>
            {title}
          </h3>
          {right}
        </header>
      )}
      {children}
    </section>
  );
}

export function SliderRow({
  label,
  value,
  min,
  max,
  step = 0.01,
  onChange,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  format?: (v: number) => string;
}) {
  const p = ((value - min) / (max - min)) * 100;
  return (
    <label className="block">
      <div className="mb-0.5 flex items-center justify-between text-[12px]">
        <span className="text-mute">{label}</span>
        <span className="rounded-md bg-high px-1.5 py-0.5 font-mono text-[10px] text-cyan">
          {format ? format(value) : value}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        style={{ ["--p" as string]: `${p}%` }}
        onChange={(e) => onChange(parseFloat(e.target.value))}
      />
    </label>
  );
}

export function Toggle({
  label,
  hint,
  on,
  onChange,
}: {
  label: string;
  hint?: string;
  on: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      className="flex w-full items-center justify-between gap-3 rounded-lg bg-mid px-3 py-2 text-start transition active:scale-[0.99]"
    >
      <span className="min-w-0">
        <span className="block text-[12.5px] text-ink">{label}</span>
        {hint && <span className="block text-[10.5px] text-mute/70">{hint}</span>}
      </span>
      <span
        className={cn(
          "relative h-5 w-9 shrink-0 rounded-full transition",
          on ? "bg-cyan-dim shadow-[0_0_10px_rgba(0,242,254,0.5)]" : "bg-highest",
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all",
            on ? "start-[18px]" : "start-0.5",
          )}
        />
      </span>
    </button>
  );
}

export function Pill({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("rounded-md bg-high px-1.5 py-0.5 font-mono text-[10px] text-cyan", className)}>
      {children}
    </span>
  );
}
