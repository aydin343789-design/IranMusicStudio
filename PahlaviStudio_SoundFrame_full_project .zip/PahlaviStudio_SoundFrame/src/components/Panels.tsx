import { useRef } from "react";
import {
  BarChart3,
  AudioLines,
  Rows3,
  CircleDot,
  Activity,
  Waves,
  Mountain,
  Grip,
  Target,
  Flower2,
  Video,
  Music2,
  Upload,
  Trash2,
  Sparkles,
  Wand2,
  Save,
  RotateCcw,
  Lock,
  Unlock,
  Repeat,
  Download,
  Square,
  Circle,
  Minus,
  Plus,
  Crosshair,
  Loader2,
  Share2,
} from "lucide-react";
import type { ReactNode } from "react";
import { Card, Pill, SliderRow, Toggle } from "./ui";
import { cn } from "../utils/cn";
import { fa, fmtTime } from "../lib/format";
import { PALETTES, STYLE_LIST, makeColorFn, DEFAULT_VIZ, type VizSettings, type VizStyle } from "../lib/visualizers";
import type { Aspect } from "../lib/renderer";
import type { ExportState, Media, Project } from "../lib/types";
import { useTime } from "../lib/timeStore";
import { isNative, shareFile } from "../lib/native";

const STYLE_ICONS: Record<VizStyle, ReactNode> = {
  bars: <BarChart3 size={20} />,
  mirror: <AudioLines size={20} />,
  led: <Rows3 size={20} />,
  circle: <CircleDot size={20} />,
  ringwave: <Activity size={20} />,
  wave: <Waves size={20} />,
  area: <Mountain size={20} />,
  dots: <Grip size={20} />,
  rings: <Target size={20} />,
  flower: <Flower2 size={20} />,
};

function paletteGradient(id: string, v: VizSettings) {
  const f = makeColorFn({ ...v, palette: id });
  const stops = Array.from({ length: 7 }, (_, i) => f(i / 6)).join(",");
  return `linear-gradient(90deg, ${stops})`;
}

function Btn({
  children,
  onClick,
  active,
  danger,
  className,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  active?: boolean;
  danger?: boolean;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex items-center justify-center gap-1.5 rounded-lg bg-mid px-3 py-2 text-[12px] text-ink transition hover:bg-bright active:scale-95 disabled:opacity-40",
        active && "bg-high text-cyan ring-1 ring-cyan/40",
        danger && "text-[#ffb4ab]",
        className,
      )}
    >
      {children}
    </button>
  );
}

/* ------------------------------------------------------------------ */
export function MediaPanel(props: {
  media: Media;
  project: Project;
  setProject: (p: Partial<Project>) => void;
  busy: string;
  onVideo: (f: File) => void;
  onAudio: (f: File) => void;
  onDemo: () => void;
  onClearVideo: () => void;
  onClearAudio: () => void;
  onSave: () => void;
  onReset: () => void;
  saved: boolean;
}) {
  const { media, project, busy } = props;
  const vRef = useRef<HTMLInputElement>(null);
  const aRef = useRef<HTMLInputElement>(null);
  const aspects: { id: Aspect; label: string; hint: string }[] = [
    { id: "auto", label: "اصلی", hint: "مطابق ویدئو" },
    { id: "9:16", label: "۹:۱۶", hint: "ریلز / استوری" },
    { id: "16:9", label: "۱۶:۹", hint: "یوتیوب" },
    { id: "1:1", label: "۱:۱", hint: "پست مربعی" },
  ];
  return (
    <div className="fade-up flex flex-col gap-3">
      <Card title="ویدئو" icon={<Video size={16} />}>
        <input
          ref={vRef}
          type="file"
          accept="video/*"
          hidden
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) props.onVideo(f);
            e.target.value = "";
          }}
        />
        {media.videoName ? (
          <div className="flex items-center justify-between gap-2 rounded-lg bg-mid p-2.5">
            <div className="min-w-0">
              <div className="truncate text-[12.5px]">{media.videoName}</div>
              <div className="mt-0.5 font-mono text-[10px] text-mute">
                {fa(media.vw)}×{fa(media.vh)} · {fmtTime(media.videoDur)}
              </div>
            </div>
            <div className="flex gap-1.5">
              <Btn onClick={() => vRef.current?.click()}>تعویض</Btn>
              <Btn danger onClick={props.onClearVideo}>
                <Trash2 size={14} />
              </Btn>
            </div>
          </div>
        ) : (
          <button
            onClick={() => vRef.current?.click()}
            className="flex w-full flex-col items-center gap-2 rounded-lg border border-dashed border-line bg-mid/50 px-3 py-6 text-mute transition hover:border-cyan/60 hover:text-cyan"
          >
            {busy === "video" ? <Loader2 className="animate-spin" /> : <Upload />}
            <span className="text-[12.5px]">انتخاب ویدئو (MP4, WebM, MOV)</span>
            <span className="text-[10.5px] opacity-70">ویدئو روی دستگاه شما می‌ماند و آپلود نمی‌شود</span>
          </button>
        )}
      </Card>

      <Card title="موزیک" icon={<Music2 size={16} />}>
        <input
          ref={aRef}
          type="file"
          accept="audio/*"
          hidden
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) props.onAudio(f);
            e.target.value = "";
          }}
        />
        {media.audioName ? (
          <div className="flex items-center justify-between gap-2 rounded-lg bg-mid p-2.5">
            <div className="min-w-0">
              <div className="truncate text-[12.5px]">{media.audioName}</div>
              <div className="mt-0.5 font-mono text-[10px] text-mute">
                {fmtTime(media.audioDur)}
                {media.analysis && media.analysis.bpm > 0 && ` · ${fa(media.analysis.bpm)} BPM`}
              </div>
            </div>
            <div className="flex gap-1.5">
              <Btn onClick={() => aRef.current?.click()}>تعویض</Btn>
              <Btn danger onClick={props.onClearAudio}>
                <Trash2 size={14} />
              </Btn>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            <button
              onClick={() => aRef.current?.click()}
              className="flex w-full flex-col items-center gap-2 rounded-lg border border-dashed border-line bg-mid/50 px-3 py-6 text-mute transition hover:border-cyan/60 hover:text-cyan"
            >
              {busy === "audio" ? <Loader2 className="animate-spin" /> : <Upload />}
              <span className="text-[12.5px]">انتخاب موزیک (MP3, WAV, M4A, OGG)</span>
            </button>
            <Btn onClick={props.onDemo} className="bg-high text-cyan">
              {busy === "demo" ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
              ساخت موزیک دمو برای امتحان
            </Btn>
          </div>
        )}
      </Card>

      <Card title="نسبت تصویر خروجی" icon={<Crosshair size={16} />}>
        <div className="grid grid-cols-4 gap-1.5">
          {aspects.map((a) => (
            <button
              key={a.id}
              onClick={() => props.setProject({ aspect: a.id })}
              className={cn(
                "rounded-lg bg-mid px-1 py-2 text-center transition active:scale-95",
                project.aspect === a.id && "bg-high ring-1 ring-cyan/50",
              )}
            >
              <div className={cn("text-[13px] font-semibold", project.aspect === a.id ? "text-cyan" : "text-ink")}>{a.label}</div>
              <div className="text-[9.5px] text-mute/80">{a.hint}</div>
            </button>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-2">
        <Btn onClick={props.onSave} className="bg-high text-cyan">
          <Save size={14} /> {props.saved ? "ذخیره شد ✓" : "ذخیره تنظیمات پروژه"}
        </Btn>
        <Btn onClick={props.onReset}>
          <RotateCcw size={14} /> بازنشانی
        </Btn>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
export function StudioControls(props: {
  media: Media;
  project: Project;
  setProject: (p: Partial<Project>) => void;
  hasVideo: boolean;
  onAlignBeat: () => void;
  flash: boolean;
}) {
  const { project: p, media } = props;
  const nudge = (d: number) => props.setProject({ offset: Math.round((p.offset + d) * 100) / 100 });
  return (
    <div className="fade-up mt-3 flex flex-col gap-3">
      <Card title="موقعیت موزیک روی ویدئو" icon={<Music2 size={16} />} right={<Pill>{fa(p.offset.toFixed(2))} s</Pill>}>
        <div className="grid grid-cols-5 gap-1.5" dir="ltr">
          <Btn onClick={() => nudge(-1)} disabled={p.locked || !props.hasVideo}>
            <Minus size={12} />۱s
          </Btn>
          <Btn onClick={() => nudge(-0.1)} disabled={p.locked || !props.hasVideo}>
            <Minus size={12} />۰.۱
          </Btn>
          <Btn onClick={() => props.setProject({ offset: 0 })} disabled={p.locked}>
            ۰
          </Btn>
          <Btn onClick={() => nudge(0.1)} disabled={p.locked || !props.hasVideo}>
            <Plus size={12} />۰.۱
          </Btn>
          <Btn onClick={() => nudge(1)} disabled={p.locked || !props.hasVideo}>
            <Plus size={12} />۱s
          </Btn>
        </div>
        {!props.hasVideo && <p className="mt-2 text-[11px] text-mute/70">برای تنظیم موقعیت، ابتدا یک ویدئو اضافه کنید.</p>}
      </Card>

      <Card title="میکس صدا" icon={<AudioLines size={16} />}>
        <div className="flex flex-col gap-2">
          <SliderRow label="صدای موزیک" value={p.musicVol} min={0} max={1} onChange={(v) => props.setProject({ musicVol: v })} format={(v) => `${fa(Math.round(v * 100))}٪`} />
          <Toggle
            label="صدای اصلی ویدئو"
            hint={p.videoMuted ? "بی‌صدا — فقط موزیک شنیده می‌شود" : "با موزیک ترکیب می‌شود"}
            on={!p.videoMuted}
            onChange={(v) => props.setProject({ videoMuted: !v })}
          />
          {!p.videoMuted && (
            <SliderRow label="صدای ویدئو" value={p.videoVol} min={0} max={1} onChange={(v) => props.setProject({ videoVol: v })} format={(v) => `${fa(Math.round(v * 100))}٪`} />
          )}
        </div>
      </Card>

      <Card title="ابزار سریع" icon={<Wand2 size={16} />}>
        <div className="grid grid-cols-3 gap-1.5">
          <button
            onClick={props.onAlignBeat}
            disabled={!media.analysis || media.analysis.bpm <= 0 || !props.hasVideo}
            className={cn(
              "flex flex-col items-center gap-1 rounded-xl bg-mid px-1 py-2.5 text-[11px] transition active:scale-95 disabled:opacity-40",
              props.flash && "bg-crimson/70",
            )}
          >
            <Wand2 size={18} className="text-rose" />
            هماهنگی بیت
          </button>
          <button
            onClick={() => props.setProject({ loop: !p.loop })}
            className={cn("flex flex-col items-center gap-1 rounded-xl bg-mid px-1 py-2.5 text-[11px] transition active:scale-95", p.loop && "bg-high text-cyan")}
          >
            <Repeat size={18} className="text-cyan-dim" />
            تکرار موزیک {p.loop ? "✓" : ""}
          </button>
          <button
            onClick={() => props.setProject({ locked: !p.locked })}
            className={cn("flex flex-col items-center gap-1 rounded-xl bg-mid px-1 py-2.5 text-[11px] transition active:scale-95", p.locked && "bg-high text-[#ffb4ab]")}
          >
            {p.locked ? <Lock size={18} className="text-[#ffb4ab]" /> : <Unlock size={18} className="text-[#849495]" />}
            قفل ترک‌ها
          </button>
        </div>
        <div className="mt-2">
          <Toggle label="نمایش خطوط بیت روی تایم‌لاین" on={p.showBeats} onChange={(v) => props.setProject({ showBeats: v })} />
        </div>
        {media.analysis && media.analysis.bpm > 0 && (
          <p className="mt-2 text-[11px] leading-5 text-mute/80">
            تمپو: <b className="text-cyan">{fa(media.analysis.bpm)} BPM</b> — اولین ضرب در ثانیه{" "}
            <b className="text-cyan">{fa(media.analysis.firstBeat.toFixed(2))}</b>. «هماهنگی بیت» ابتدای موزیک را طوری برش می‌دهد که اولین ضرب دقیقاً با شروع ویدئو هم‌زمان شود.
          </p>
        )}
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
export function EqPanel({ viz, setViz }: { viz: VizSettings; setViz: (p: Partial<VizSettings>) => void }) {
  return (
    <div className="fade-up flex flex-col gap-3">
      <Card title="شکل اکولایزر" icon={<AudioLines size={16} />}>
        <div className="grid grid-cols-5 gap-1.5">
          {STYLE_LIST.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                const box = { ...viz.box };
                const round = ["circle", "ringwave", "rings", "flower"].includes(s.id);
                const wasRound = ["circle", "ringwave", "rings", "flower"].includes(viz.style);
                if (round && !wasRound) {
                  box.w = 0.7;
                  box.h = 0.4;
                } else if (!round && wasRound) {
                  box.w = 0.8;
                  box.h = 0.3;
                }
                setViz({ style: s.id, box });
              }}
              className={cn(
                "flex flex-col items-center gap-1 rounded-xl bg-mid px-0.5 py-2 text-[10px] text-mute transition active:scale-95",
                viz.style === s.id && "bg-high text-cyan ring-1 ring-cyan/50 shadow-[0_0_14px_rgba(0,242,254,0.2)]",
              )}
            >
              {STYLE_ICONS[s.id]}
              <span className="leading-3">{s.label}</span>
            </button>
          ))}
        </div>
      </Card>

      <Card title="رنگ" icon={<Circle size={16} />}>
        <div className="grid grid-cols-4 gap-1.5">
          {Object.entries(PALETTES).map(([id, pl]) => (
            <button
              key={id}
              onClick={() => setViz({ palette: id })}
              className={cn("rounded-lg bg-mid p-1 transition active:scale-95", viz.palette === id && "ring-1 ring-cyan")}
            >
              <div className="h-5 rounded-md" style={{ background: paletteGradient(id, viz) }} />
              <div className="mt-1 text-[10px] text-mute">{pl.name}</div>
            </button>
          ))}
        </div>
        {viz.palette === "custom" && (
          <div className="mt-2 flex items-center gap-3 rounded-lg bg-mid p-2 text-[12px] text-mute">
            رنگ اول
            <input type="color" value={viz.colorA} onChange={(e) => setViz({ colorA: e.target.value })} className="h-8 w-10" />
            رنگ دوم
            <input type="color" value={viz.colorB} onChange={(e) => setViz({ colorB: e.target.value })} className="h-8 w-10" />
          </div>
        )}
      </Card>

      <Card title="تنظیمات حرکت" icon={<Activity size={16} />}>
        <div className="flex flex-col gap-1.5">
          <SliderRow label="تعداد المان‌ها" value={viz.count} min={12} max={96} step={1} onChange={(v) => setViz({ count: v })} format={(v) => fa(v)} />
          <SliderRow label="حساسیت" value={viz.sensitivity} min={0.4} max={2.2} onChange={(v) => setViz({ sensitivity: v })} format={(v) => fa(v.toFixed(2))} />
          <SliderRow label="نرمی حرکت" value={viz.smoothing} min={0} max={1} onChange={(v) => setViz({ smoothing: v })} format={(v) => fa(Math.round(v * 100))} />
          <SliderRow label="ضخامت" value={viz.thickness} min={0.1} max={1} onChange={(v) => setViz({ thickness: v })} format={(v) => fa(Math.round(v * 100))} />
          <SliderRow label="درخشش نئونی" value={viz.glow} min={0} max={40} step={1} onChange={(v) => setViz({ glow: v })} format={(v) => fa(v)} />
          <SliderRow label="شفافیت" value={viz.opacity} min={0.1} max={1} onChange={(v) => setViz({ opacity: v })} format={(v) => `${fa(Math.round(v * 100))}٪`} />
        </div>
      </Card>

      <Card title="اندازه و بازه نمایش" icon={<Crosshair size={16} />}>
        <div className="flex flex-col gap-1.5">
          <SliderRow
            label="اندازه کلی"
            value={Math.max(viz.box.w, viz.box.h)}
            min={0.15}
            max={1.2}
            onChange={(v) => {
              const r = viz.box.w / Math.max(0.01, viz.box.h);
              setViz({ box: { ...viz.box, w: r >= 1 ? v : v * r, h: r >= 1 ? v / r : v } });
            }}
            format={(v) => `${fa(Math.round(v * 100))}٪`}
          />
          <SliderRow label="شروع افکت" value={viz.rangeStart} min={0} max={0.95} onChange={(v) => setViz({ rangeStart: Math.min(v, viz.rangeEnd - 0.03) })} format={(v) => `${fa(Math.round(v * 100))}٪`} />
          <SliderRow label="پایان افکت" value={viz.rangeEnd} min={0.05} max={1} onChange={(v) => setViz({ rangeEnd: Math.max(v, viz.rangeStart + 0.03) })} format={(v) => `${fa(Math.round(v * 100))}٪`} />
          <div className="grid grid-cols-2 gap-1.5 pt-1">
            <Btn onClick={() => setViz({ box: { ...viz.box, cx: 0.5, cy: 0.5 } })}>
              <Crosshair size={13} /> وسط‌چین
            </Btn>
            <Btn onClick={() => setViz({ box: DEFAULT_VIZ.box, rangeStart: 0, rangeEnd: 1 })}>
              <RotateCcw size={13} /> بازنشانی
            </Btn>
          </div>
          <p className="text-[11px] text-mute/70">کادر نئونی روی تصویر را بکشید تا جابه‌جا شود و از گوشه پایین برای تغییر اندازه استفاده کنید.</p>
        </div>
      </Card>

      <Card title="واکنش به ضرب" icon={<Sparkles size={16} />}>
        <div className="flex flex-col gap-2">
          <Toggle label="زوم ضربانی ویدئو" hint="با هر ضرب بیس تصویر کمی پالس می‌زند" on={viz.beatZoom} onChange={(v) => setViz({ beatZoom: v })} />
          <Toggle label="فلش نوری روی ضرب" on={viz.beatFlash} onChange={(v) => setViz({ beatFlash: v })} />
          <SliderRow
            label="تأخیر هماهنگی تصویر با صدا (اگر اکولایزر زودتر از صدا حرکت می‌کند زیاد کنید)"
            value={viz.syncMs}
            min={0}
            max={400}
            step={5}
            onChange={(v) => setViz({ syncMs: v })}
            format={(v) => `${fa(v)} ms`}
          />
          <SliderRow label="تیره‌کردن ویدئو (خوانایی بهتر)" value={viz.dim} min={0} max={0.8} onChange={(v) => setViz({ dim: v })} format={(v) => `${fa(Math.round(v * 100))}٪`} />
        </div>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
function ExportProgress() {
  const { time, duration } = useTime();
  const p = duration > 0 ? Math.min(1, time / duration) : 0;
  return (
    <>
      <div className="mb-2 flex items-center justify-between text-[12px]">
        <span className="flex items-center gap-1.5 text-rose">
          <span className="h-2 w-2 animate-pulse rounded-full bg-rose" /> در حال ضبط…
        </span>
        <Pill>{fa(Math.round(p * 100))}٪</Pill>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-highest">
        <div className="h-full rounded-full bg-gradient-to-r from-cyan to-pink" style={{ width: `${p * 100}%` }} />
      </div>
    </>
  );
}

export function ExportPanel(props: {
  project: Project;
  setProject: (p: Partial<Project>) => void;
  cw: number;
  ch: number;
  duration: number;
  ready: boolean;
  exp: ExportState;
  onStart: () => void;
  onCancel: () => void;
}) {
  const { exp, project } = props;
  const rec = exp.status === "recording";
  const size = (project.bitrate * 1e6 * props.duration) / 8 / 1e6;
  const outLong = project.exportLong;
  return (
    <div className="fade-up flex flex-col gap-3">
      <Card title="مشخصات خروجی" icon={<Download size={16} />}>
        <div className="grid grid-cols-3 gap-1.5 text-center">
          {[
            ["ضلع بلندتر", `${fa(outLong)}px`],
            ["مدت", fmtTime(props.duration)],
            ["حجم تقریبی", `${fa(size.toFixed(1))} MB`],
          ].map(([k, v]) => (
            <div key={k} className="rounded-lg bg-mid px-1 py-2">
              <div className="text-[10px] text-mute">{k}</div>
              <div className="mt-0.5 font-mono text-[12px] text-cyan">{v}</div>
            </div>
          ))}
        </div>

        <div className="mb-1 mt-3 text-[12px] text-mute">رزولوشن (پیشنهاد موبایل: ۷۲۰p)</div>
        <div className="grid grid-cols-3 gap-1.5">
          {[
            [960, "۵۴۰p · سریع"],
            [1280, "۷۲۰p · متعادل"],
            [1920, "۱۰۸۰p · سنگین"],
          ].map(([b, l]) => (
            <Btn key={b} active={outLong === b} disabled={rec} onClick={() => props.setProject({ exportLong: b as number })}>
              {l}
            </Btn>
          ))}
        </div>

        <div className="mb-1 mt-3 text-[12px] text-mute">کیفیت (بیت‌ریت)</div>
        <div className="grid grid-cols-3 gap-1.5">
          {[
            [3, "کم"],
            [6, "خوب"],
            [10, "عالی"],
          ].map(([b, l]) => (
            <Btn key={b} active={project.bitrate === b} disabled={rec} onClick={() => props.setProject({ bitrate: b as number })}>
              {l} · {fa(b)}Mbps
            </Btn>
          ))}
        </div>
        <div className="mt-3">
          <Toggle
            label="بی‌صدا کردن اسپیکر هنگام رندر"
            hint="صدا در فایل خروجی ضبط می‌شود، فقط پخش زنده قطع می‌شود"
            on={project.muteWhileExport}
            onChange={(v) => props.setProject({ muteWhileExport: v })}
          />
        </div>
      </Card>

      <Card title="رندر و دریافت" icon={<Circle size={16} />}>
        {!rec ? (
          <button
            disabled={!props.ready}
            onClick={props.onStart}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-cyan py-3 text-[14px] font-bold text-[#006a70] shadow-[0_0_18px_rgba(0,242,254,0.4)] transition active:scale-95 disabled:opacity-40 disabled:shadow-none"
          >
            <Circle size={16} fill="currentColor" /> شروع رندر و ضبط
          </button>
        ) : (
          <div>
            <ExportProgress />
            <Btn danger className="mt-3 w-full" onClick={props.onCancel}>
              <Square size={13} fill="currentColor" /> لغو
            </Btn>
          </div>
        )}
        {!props.ready && <p className="mt-2 text-[11px] text-mute/70">برای رندر، حداقل یک ویدئو یا موزیک اضافه کنید.</p>}
        <p className="mt-2 text-[11px] leading-5 text-mute/70">
          برای ساخت فایل نهایی، رندر را شروع کنید و تا پایان برنامه را باز و روی صفحه نگه دارید. در اندروید، فایل پس از رندر در Documents/PahlaviStudio ذخیره می‌شود؛ دکمهٔ «ذخیره / اشتراک‌گذاری» هم منوی اشتراک‌گذاری اندروید را باز می‌کند.
          {isNative && " ویدئو مستقیم روی حافظه ذخیره می‌شود و رم اشغال نمی‌کند."}
        </p>
        {exp.status === "error" && <p className="mt-2 rounded-lg bg-crimson/40 p-2 text-[12px] text-[#ffdad6]">{exp.message}</p>}
        {exp.status === "done" && exp.url && (
          <div className="mt-3 rounded-xl bg-mid p-2">
            <video src={exp.url} controls playsInline className="mx-auto max-h-[300px] w-full rounded-lg bg-black" />
            {isNative && exp.uri ? (
              <>
                <button
                  onClick={() => shareFile(exp.uri!, "استودیو پهلوی")}
                  className="mt-2 flex w-full items-center justify-center gap-2 rounded-lg bg-high py-2.5 text-[13px] font-semibold text-cyan transition hover:bg-bright"
                >
                  <Share2 size={16} /> ذخیره / اشتراک‌گذاری ({exp.ext?.toUpperCase()} · {fa(((exp.size ?? 0) / 1e6).toFixed(1))} MB)
                </button>
                {exp.savedTo && (
                  <p className="mt-2 text-center text-[11px] text-cyan" dir="ltr">
                    ✓ {exp.savedTo}
                  </p>
                )}
              </>
            ) : (
              <a
                href={exp.url}
                download={`pahlavi-studio-${Date.now()}.${exp.ext}`}
                className="mt-2 flex items-center justify-center gap-2 rounded-lg bg-high py-2.5 text-[13px] font-semibold text-cyan transition hover:bg-bright"
              >
                <Download size={16} /> دانلود فایل ({exp.ext?.toUpperCase()} · {fa(((exp.size ?? 0) / 1e6).toFixed(1))} MB)
              </a>
            )}
          </div>
        )}
      </Card>
    </div>
  );
}
