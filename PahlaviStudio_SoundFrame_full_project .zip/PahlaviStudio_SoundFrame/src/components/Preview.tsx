import { memo, useEffect, useRef, useState, type RefObject } from "react";
import { Maximize2, Move, Eye, EyeOff, VolumeX, Volume2 } from "lucide-react";
import type { VizBox } from "../lib/visualizers";
import { fmtTime } from "../lib/format";
import { useTime } from "../lib/timeStore";

interface Props {
  canvasRef: RefObject<HTMLCanvasElement | null>;
  cw: number;
  ch: number;
  box: VizBox;
  onBox: (b: VizBox) => void;
  playing: boolean;
  hasMedia: boolean;
  videoMuted: boolean;
  recording: boolean;
  styleLabel: string;
  onTogglePlay: () => void;
}

function TimeLabel() {
  const { time, duration } = useTime();
  return (
    <span className="rounded-md bg-mid px-1.5 py-0.5 font-mono text-[11px] text-ink">
      {fmtTime(time)} / {fmtTime(duration)}
    </span>
  );
}

function Preview({
  canvasRef,
  cw,
  ch,
  box,
  onBox,
  playing,
  hasMedia,
  videoMuted,
  recording,
  styleLabel,
  onTogglePlay,
}: Props) {
  const holder = useRef<HTMLDivElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const [avail, setAvail] = useState(360);
  const [edit, setEdit] = useState(true);
  const drag = useRef<null | { mode: "move" | "size"; sx: number; sy: number; box: VizBox }>(null);

  useEffect(() => {
    const el = holder.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setAvail(el.clientWidth));
    ro.observe(el);
    setAvail(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const maxH = Math.min(typeof window !== "undefined" ? window.innerHeight * 0.58 : 520, 600);
  const ar = cw / ch;
  const dw = Math.min(avail, maxH * ar);
  const dh = dw / ar;

  const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

  const onDown = (mode: "move" | "size") => (e: React.PointerEvent) => {
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { mode, sx: e.clientX, sy: e.clientY, box: { ...box } };
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const r = stage.current!.getBoundingClientRect();
    if (d.mode === "move") {
      onBox({
        ...d.box,
        cx: clamp(d.box.cx + (e.clientX - d.sx) / r.width, 0, 1),
        cy: clamp(d.box.cy + (e.clientY - d.sy) / r.height, 0, 1),
      });
    } else {
      const px = (e.clientX - r.left) / r.width;
      const py = (e.clientY - r.top) / r.height;
      onBox({
        ...d.box,
        w: clamp(Math.abs(px - d.box.cx) * 2, 0.1, 1.4),
        h: clamp(Math.abs(py - d.box.cy) * 2, 0.06, 1.4),
      });
    }
  };
  const onUp = () => {
    drag.current = null;
  };

  const goFull = () => {
    const el = stage.current;
    if (el?.requestFullscreen) void el.requestFullscreen();
  };

  const showEdit = edit && !recording;

  return (
    <div className="rounded-xl bg-lowest p-2 shadow-2xl">
      <div className="mb-2 flex items-center justify-between gap-2 px-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="flex items-center gap-1 rounded-md bg-mid px-1.5 py-0.5 font-mono text-[10px] text-cyan">
            <span className={`h-1.5 w-1.5 rounded-full ${playing ? "animate-ping bg-cyan" : "bg-cyan/50"}`} />
            {cw}×{ch}
          </span>
          <span
            className={`flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] ${
              videoMuted ? "bg-crimson/80 text-[#ffb2b5]" : "bg-mid text-cyan"
            }`}
          >
            {videoMuted ? <VolumeX size={11} /> : <Volume2 size={11} />}
            صدای اصلی ویدئو: {videoMuted ? "خاموش" : "روشن"}
          </span>
        </div>
        <TimeLabel />
      </div>

      <div ref={holder} className="flex w-full justify-center">
        <div
          ref={stage}
          className="relative overflow-hidden rounded-lg bg-black"
          style={{ width: dw, height: dh }}
          onClick={onTogglePlay}
        >
          <canvas ref={canvasRef} width={cw} height={ch} className="block h-full w-full" />

          {!hasMedia && (
            <div className="pointer-events-none absolute inset-x-0 top-3 flex justify-center">
              <span className="rounded-full bg-black/55 px-3 py-1 text-[11px] text-mute backdrop-blur">
                ویدئو و موزیک را از تب «رسانه» اضافه کنید
              </span>
            </div>
          )}

          {showEdit && (
            <div
              className="absolute touch-none select-none"
              style={{
                left: `${(box.cx - box.w / 2) * 100}%`,
                top: `${(box.cy - box.h / 2) * 100}%`,
                width: `${box.w * 100}%`,
                height: `${box.h * 100}%`,
              }}
              onClick={(e) => e.stopPropagation()}
              onPointerDown={onDown("move")}
              onPointerMove={onMove}
              onPointerUp={onUp}
              onPointerCancel={onUp}
            >
              <div className="absolute inset-0 cursor-move rounded-md border border-dashed border-cyan/60 bg-cyan/[0.03]" />
              {(["-top-1.5 -start-1.5", "-top-1.5 -end-1.5", "-bottom-1.5 -start-1.5"] as const).map((pos) => (
                <span key={pos} className={`absolute h-2.5 w-2.5 rounded-full bg-cyan shadow-[0_0_8px_rgba(0,242,254,0.9)] ${pos}`} />
              ))}
              <span
                onPointerDown={onDown("size")}
                onPointerMove={onMove}
                onPointerUp={onUp}
                className="absolute -bottom-3 -end-3 flex h-6 w-6 cursor-nwse-resize items-center justify-center"
              >
                <span className="h-3 w-3 rounded-full bg-cyan shadow-[0_0_10px_rgba(0,242,254,1)]" />
              </span>
              <span className="pointer-events-none absolute -top-5 start-0 flex items-center gap-1 text-[10px] text-cyan">
                <Move size={10} /> {styleLabel}
              </span>
            </div>
          )}
        </div>
      </div>

      <div className="mt-2 flex items-center justify-between px-1 text-mute">
        <button
          onClick={() => setEdit((v) => !v)}
          className="flex items-center gap-1.5 rounded-lg bg-mid px-2 py-1 text-[11px] hover:text-cyan"
        >
          {edit ? <Eye size={13} /> : <EyeOff size={13} />}
          {edit ? "کادر ویرایش: روشن" : "کادر ویرایش: خاموش"}
        </button>
        <button
          onClick={goFull}
          aria-label="تمام‌صفحه"
          className="flex h-7 w-7 items-center justify-center rounded-lg bg-mid hover:text-cyan"
        >
          <Maximize2 size={14} />
        </button>
      </div>
    </div>
  );
}

export default memo(Preview);
