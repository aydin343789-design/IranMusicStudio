import type { Aspect } from "./renderer";
import type { AudioAnalysis } from "./engine";

export interface Project {
  aspect: Aspect;
  musicVol: number;
  videoVol: number;
  videoMuted: boolean;
  loop: boolean;
  offset: number;
  locked: boolean;
  showBeats: boolean;
  muteWhileExport: boolean;
  bitrate: number;
  exportLong: number;
}

export interface Media {
  videoName: string;
  audioName: string;
  vw: number;
  vh: number;
  videoDur: number;
  audioDur: number;
  analysis: AudioAnalysis | null;
  thumbs: string[];
}

export type Tab = "media" | "studio" | "eq" | "export";

export interface ExportState {
  status: "idle" | "recording" | "done" | "error";
  progress: number;
  url?: string;
  ext?: string;
  size?: number;
  message?: string;
  uri?: string;
  savedTo?: string;
}

export const DEFAULT_PROJECT: Project = {
  aspect: "auto",
  musicVol: 0.9,
  videoVol: 0.8,
  videoMuted: true,
  loop: true,
  offset: 0,
  locked: false,
  showBeats: true,
  muteWhileExport: false,
  bitrate: 6,
  exportLong: 1280,
};

export const EMPTY_MEDIA: Media = {
  videoName: "",
  audioName: "",
  vw: 0,
  vh: 0,
  videoDur: 0,
  audioDur: 0,
  analysis: null,
  thumbs: [],
};
