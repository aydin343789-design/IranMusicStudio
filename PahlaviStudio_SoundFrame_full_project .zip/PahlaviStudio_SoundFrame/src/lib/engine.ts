export interface AudioAnalysis {
  peaks: number[];
  bpm: number;
  firstBeat: number;
  duration: number;
}

/* ---------- Audio analysis (waveform peaks + BPM) ---------- */
export function analyzeBuffer(buf: AudioBuffer): AudioAnalysis {
  const ch = buf.getChannelData(0);
  const ch2 = buf.numberOfChannels > 1 ? buf.getChannelData(1) : ch;
  const len = ch.length;

  // waveform peaks
  const N = 220;
  const peaks: number[] = [];
  const step = Math.max(1, Math.floor(len / N));
  let maxPeak = 0.0001;
  for (let i = 0; i < N; i++) {
    let m = 0;
    const s = i * step;
    const e = Math.min(len, s + step);
    const inc = Math.max(1, Math.floor((e - s) / 200));
    for (let j = s; j < e; j += inc) {
      const a = Math.abs((ch[j] + ch2[j]) / 2);
      if (a > m) m = a;
    }
    peaks.push(m);
    if (m > maxPeak) maxPeak = m;
  }
  const norm = peaks.map((p) => Math.pow(p / maxPeak, 0.8));

  // energy envelope
  const sr = buf.sampleRate;
  const hop = Math.max(64, Math.round(sr / 86));
  const maxFrames = Math.min(Math.floor(len / hop), Math.floor((sr * 90) / hop));
  const env = new Float32Array(maxFrames);
  for (let f = 0; f < maxFrames; f++) {
    let sum = 0;
    const s = f * hop;
    for (let j = 0; j < hop; j++) {
      const a = ch[s + j];
      sum += a * a;
    }
    env[f] = Math.sqrt(sum / hop);
  }
  const onset = new Float32Array(maxFrames);
  for (let i = 1; i < maxFrames; i++) onset[i] = Math.max(0, env[i] - env[i - 1]);
  const fr = sr / hop;

  let bestBpm = 120;
  let bestScore = -1;
  for (let bpm = 70; bpm <= 180; bpm += 0.5) {
    const lag = (60 / bpm) * fr;
    let score = 0;
    for (let i = 0; i + lag * 2 + 2 < maxFrames; i++) {
      const j = i + lag;
      const j0 = Math.floor(j);
      const fj = j - j0;
      const o2 = onset[j0] * (1 - fj) + onset[j0 + 1] * fj;
      const k = i + lag * 2;
      const k0 = Math.floor(k);
      const fk = k - k0;
      const o4 = onset[k0] * (1 - fk) + onset[k0 + 1] * fk;
      score += onset[i] * (o2 + o4 * 0.5);
    }
    if (score > bestScore) {
      bestScore = score;
      bestBpm = bpm;
    }
  }

  const period = (60 / bestBpm) * fr;
  let bestPhase = 0;
  let bestPS = -1;
  for (let ph = 0; ph < period; ph += 0.5) {
    let s = 0;
    for (let t = ph; t < maxFrames - 1; t += period) s += onset[Math.round(t)];
    if (s > bestPS) {
      bestPS = s;
      bestPhase = ph;
    }
  }

  return {
    peaks: norm,
    bpm: Math.round(bestBpm * 2) / 2,
    firstBeat: bestPhase / fr,
    duration: buf.duration,
  };
}

/* ---------- Demo synthwave beat ---------- */
export async function generateDemoBeat(): Promise<{ blob: Blob; buffer: AudioBuffer }> {
  const bpm = 124;
  const beat = 60 / bpm;
  const bars = 8;
  const dur = beat * 4 * bars + 0.5;
  const sr = 44100;
  const oc = new OfflineAudioContext(2, Math.ceil(dur * sr), sr);
  const master = oc.createGain();
  master.gain.value = 0.8;
  master.connect(oc.destination);

  const noiseBuf = oc.createBuffer(1, sr, sr);
  const nd = noiseBuf.getChannelData(0);
  for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;

  const kick = (t: number) => {
    const o = oc.createOscillator();
    const g = oc.createGain();
    o.frequency.setValueAtTime(150, t);
    o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
    g.gain.setValueAtTime(1, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.38);
    o.connect(g).connect(master);
    o.start(t);
    o.stop(t + 0.4);
  };
  const hat = (t: number, vol: number) => {
    const s = oc.createBufferSource();
    s.buffer = noiseBuf;
    const f = oc.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = 7500;
    const g = oc.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    s.connect(f).connect(g).connect(master);
    s.start(t);
    s.stop(t + 0.06);
  };
  const snare = (t: number) => {
    const s = oc.createBufferSource();
    s.buffer = noiseBuf;
    const f = oc.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 1800;
    const g = oc.createGain();
    g.gain.setValueAtTime(0.6, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    s.connect(f).connect(g).connect(master);
    s.start(t);
    s.stop(t + 0.22);
  };
  const bass = (t: number, freq: number, d: number) => {
    const o = oc.createOscillator();
    o.type = "sawtooth";
    o.frequency.value = freq;
    const f = oc.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(900, t);
    f.frequency.exponentialRampToValueAtTime(180, t + d);
    const g = oc.createGain();
    g.gain.setValueAtTime(0.32, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + d);
    o.connect(f).connect(g).connect(master);
    o.start(t);
    o.stop(t + d + 0.02);
  };
  const lead = (t: number, freq: number, d: number) => {
    for (const det of [-6, 6]) {
      const o = oc.createOscillator();
      o.type = "square";
      o.frequency.value = freq;
      o.detune.value = det;
      const f = oc.createBiquadFilter();
      f.type = "lowpass";
      f.frequency.value = 2600;
      const g = oc.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.06, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0005, t + d);
      o.connect(f).connect(g).connect(master);
      o.start(t);
      o.stop(t + d + 0.02);
    }
  };

  const roots = [55, 55, 43.65, 49]; // A1 A1 F1 G1
  const arp = [1, 1.5, 2, 3, 2, 1.5, 2, 3];
  for (let b = 0; b < bars; b++) {
    const root = roots[b % 4];
    for (let s = 0; s < 4; s++) {
      const t = (b * 4 + s) * beat;
      kick(t);
      if (s === 1 || s === 3) snare(t);
      hat(t + beat / 2, 0.35);
      if (s % 2 === 0) hat(t, 0.15);
    }
    for (let e = 0; e < 16; e++) {
      const t = (b * 16 + e) * (beat / 4);
      bass(t, root * (e % 4 === 3 ? 2 : 1), beat / 4.5);
    }
    if (b >= 2) {
      for (let e = 0; e < 8; e++) {
        const t = (b * 8 + e) * (beat / 2);
        lead(t, root * 4 * arp[e], beat / 2);
      }
    }
  }
  const buffer = await oc.startRendering();
  return { blob: bufferToWav(buffer), buffer };
}

function bufferToWav(buf: AudioBuffer): Blob {
  const nCh = buf.numberOfChannels;
  const len = buf.length * nCh * 2 + 44;
  const ab = new ArrayBuffer(len);
  const view = new DataView(ab);
  const ws = (o: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(o + i, s.charCodeAt(i));
  };
  ws(0, "RIFF");
  view.setUint32(4, len - 8, true);
  ws(8, "WAVE");
  ws(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, nCh, true);
  view.setUint32(24, buf.sampleRate, true);
  view.setUint32(28, buf.sampleRate * nCh * 2, true);
  view.setUint16(32, nCh * 2, true);
  view.setUint16(34, 16, true);
  ws(36, "data");
  view.setUint32(40, len - 44, true);
  const chans = Array.from({ length: nCh }, (_, c) => buf.getChannelData(c));
  let off = 44;
  for (let i = 0; i < buf.length; i++) {
    for (let c = 0; c < nCh; c++) {
      const s = Math.max(-1, Math.min(1, chans[c][i]));
      view.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      off += 2;
    }
  }
  return new Blob([ab], { type: "audio/wav" });
}

/* ---------- Video thumbnails ---------- */
export async function makeThumbs(url: string, count = 8): Promise<string[]> {
  return new Promise((resolve) => {
    const v = document.createElement("video");
    v.muted = true;
    v.preload = "auto";
    v.playsInline = true;
    v.src = url;
    const out: string[] = [];
    const c = document.createElement("canvas");
    let finished = false;
    const done = () => {
      if (finished) return;
      finished = true;
      v.removeAttribute("src");
      v.load();
      resolve(out);
    };
    setTimeout(done, 10000);
    v.onerror = done;
    v.onloadedmetadata = () => {
      const d = v.duration;
      if (!isFinite(d) || d <= 0) return done();
      const ar = v.videoWidth / v.videoHeight || 1;
      c.height = 96;
      c.width = Math.round(96 * ar);
      let i = 0;
      const next = () => {
        if (i >= count) return done();
        v.currentTime = Math.min(d - 0.05, (i + 0.5) * (d / count));
      };
      v.onseeked = () => {
        try {
          c.getContext("2d")!.drawImage(v, 0, 0, c.width, c.height);
          out.push(c.toDataURL("image/jpeg", 0.6));
        } catch {
          return done();
        }
        i++;
        next();
      };
      next();
    };
  });
}

/* ---------- Main engine ---------- */
export class Engine {
  video = document.createElement("video");
  audio = new Audio();
  ctx: AudioContext | null = null;
  analyser: AnalyserNode | null = null;
  musicGain: GainNode | null = null;
  videoGain: GainNode | null = null;
  speaker: GainNode | null = null;
  recDest: MediaStreamAudioDestinationNode | null = null;

  hasVideo = false;
  hasAudio = false;
  videoDur = 0;
  audioDur = 0;
  offset = 0;
  loop = true;
  playing = false;
  musicVol = 0.9;
  videoVol = 0;
  speakerOn = true;
  private videoUrl: string | null = null;
  private audioUrl: string | null = null;

  constructor() {
    this.video.playsInline = true;
    this.video.preload = "auto";
    this.video.setAttribute("playsinline", "");
    this.audio.preload = "auto";
    this.video.loop = false;
    // Keep the media elements in the DOM (invisible): detached media elements
    // are decoded unreliably inside Android WebView.
    const hide = (el: HTMLElement) => {
      el.style.cssText =
        "position:fixed;left:0;top:0;width:2px;height:2px;opacity:0.01;pointer-events:none;z-index:-1;";
      document.body.appendChild(el);
    };
    hide(this.video);
    hide(this.audio);
  }

  ensureAudio() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AC();
      this.ctx = ctx;
      this.analyser = ctx.createAnalyser();
      this.analyser.fftSize = 2048;
      this.analyser.smoothingTimeConstant = 0.35;
      this.analyser.minDecibels = -85;
      this.analyser.maxDecibels = -25;
      this.musicGain = ctx.createGain();
      this.videoGain = ctx.createGain();
      this.speaker = ctx.createGain();
      this.recDest = ctx.createMediaStreamDestination();
      const mix = ctx.createGain();
      ctx.createMediaElementSource(this.audio).connect(this.musicGain);
      ctx.createMediaElementSource(this.video).connect(this.videoGain);
      this.musicGain.connect(mix);
      this.videoGain.connect(mix);
      mix.connect(this.analyser);
      mix.connect(this.speaker);
      mix.connect(this.recDest);
      this.speaker.connect(ctx.destination);
      this.applyVolumes();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  applyVolumes() {
    if (this.musicGain) this.musicGain.gain.value = this.musicVol;
    if (this.videoGain) this.videoGain.gain.value = this.videoVol;
    if (this.speaker) this.speaker.gain.value = this.speakerOn ? 1 : 0;
  }

  get duration() {
    return this.hasVideo ? this.videoDur : this.hasAudio ? this.audioDur : 0;
  }
  get effOffset() {
    return this.hasVideo ? this.offset : 0;
  }
  get time() {
    if (this.hasVideo) return this.video.currentTime;
    if (this.hasAudio) return this.audio.currentTime;
    return 0;
  }

  async loadVideo(file: File | Blob): Promise<{ url: string; w: number; h: number; dur: number }> {
    this.ensureAudio();
    this.pause();
    if (this.videoUrl) URL.revokeObjectURL(this.videoUrl);
    const url = URL.createObjectURL(file);
    this.videoUrl = url;
    this.video.src = url;
    await new Promise<void>((res, rej) => {
      this.video.onloadeddata = () => res();
      this.video.onerror = () => rej(new Error("video"));
      this.video.load();
    });
    this.video.onloadeddata = null;
    this.video.onerror = null;
    this.hasVideo = true;
    this.videoDur = this.video.duration;
    this.seek(0);
    return { url, w: this.video.videoWidth, h: this.video.videoHeight, dur: this.videoDur };
  }

  clearVideo() {
    this.pause();
    this.video.removeAttribute("src");
    this.video.load();
    if (this.videoUrl) URL.revokeObjectURL(this.videoUrl);
    this.videoUrl = null;
    this.hasVideo = false;
    this.videoDur = 0;
  }

  async loadAudio(file: Blob, decoded?: AudioBuffer): Promise<AudioAnalysis> {
    this.ensureAudio();
    this.pause();
    if (this.audioUrl) URL.revokeObjectURL(this.audioUrl);
    const url = URL.createObjectURL(file);
    this.audioUrl = url;
    this.audio.src = url;
    await new Promise<void>((res, rej) => {
      this.audio.onloadedmetadata = () => res();
      this.audio.onerror = () => rej(new Error("audio"));
      this.audio.load();
    });
    this.audio.onloadedmetadata = null;
    this.audio.onerror = null;
    this.hasAudio = true;
    this.audioDur = this.audio.duration;
    let a: AudioAnalysis;
    try {
      // Decode at a LOW sample rate (11 kHz): the analysis only needs bass/onsets and the
      // waveform outline, and this uses ~4x less RAM than decoding at 44.1 kHz.
      const buffer =
        decoded ?? (await new OfflineAudioContext(2, 1, 11025).decodeAudioData(await file.arrayBuffer()));
      a = analyzeBuffer(buffer);
    } catch {
      // too big / unsupported for analysis: still play it, just without waveform + BPM
      a = { peaks: Array(220).fill(0.35), bpm: 0, firstBeat: 0, duration: this.audioDur };
    }
    this.audio.loop = false;
    this.seek(0);
    return a;
  }

  clearAudio() {
    this.pause();
    this.audio.removeAttribute("src");
    this.audio.load();
    if (this.audioUrl) URL.revokeObjectURL(this.audioUrl);
    this.audioUrl = null;
    this.hasAudio = false;
    this.audioDur = 0;
  }

  /** target time in music for a given timeline time (-1 = not started yet / ended) */
  private musicTarget(t: number): number {
    if (!this.hasAudio) return -1;
    const tm = t - this.effOffset;
    if (tm < 0) return -1;
    if (this.loop) return tm % this.audioDur;
    return tm >= this.audioDur ? -1 : tm;
  }

  private syncMusic(force: boolean) {
    if (!this.hasVideo || !this.hasAudio) return;
    const loopNow = this.loop;
    if (this.audio.loop !== loopNow) this.audio.loop = loopNow;
    const target = this.musicTarget(this.video.currentTime);
    if (target < 0) {
      if (!this.audio.paused) this.audio.pause();
      if (force) this.audio.currentTime = 0;
      return;
    }
    if (this.playing) {
      if (this.audio.paused || this.audio.ended) {
        this.audio.currentTime = target;
        this.audio.playbackRate = 1;
        void this.audio.play().catch(() => {});
        return;
      }
      let drift = this.audio.currentTime - target; // >0 : music is ahead
      if (loopNow && this.audioDur > 1) {
        if (drift > this.audioDur / 2) drift -= this.audioDur;
        else if (drift < -this.audioDur / 2) drift += this.audioDur;
      }
      const ad = Math.abs(drift);
      if (force || ad > 0.4) {
        this.audio.currentTime = target;
        this.audio.playbackRate = 1;
      } else if (ad > 0.035) {
        // gently speed up / slow down instead of hard seeking (no clicks, no stutter)
        const r = 1 - Math.max(-0.06, Math.min(0.06, drift * 0.6));
        if (Math.abs(this.audio.playbackRate - r) > 0.004) this.audio.playbackRate = r;
      } else if (this.audio.playbackRate !== 1) {
        this.audio.playbackRate = 1;
      }
    } else if (force) {
      this.audio.currentTime = target;
    }
  }

  tick() {
    if (this.playing) this.syncMusic(false);
  }

  async play() {
    if (this.duration <= 0) return;
    this.ensureAudio();
    if (this.time >= this.duration - 0.05) this.seek(0);
    this.playing = true;
    this.audio.loop = this.hasVideo && this.loop;
    this.audio.playbackRate = 1;
    if (this.hasVideo) {
      void this.video.play().catch(() => {});
      this.syncMusic(true);
    } else if (this.hasAudio) {
      void this.audio.play().catch(() => {});
    }
  }

  pause() {
    this.playing = false;
    this.video.pause();
    this.audio.pause();
  }

  seek(t: number) {
    const tt = Math.max(0, Math.min(this.duration || 0, t));
    if (this.hasVideo) {
      this.video.currentTime = tt;
      this.syncMusic(true);
    } else if (this.hasAudio) {
      this.audio.currentTime = tt;
    }
  }

  waitSeek(): Promise<void> {
    return new Promise((res) => {
      const el = this.hasVideo ? this.video : this.audio;
      if (!el.seeking) return res();
      el.addEventListener("seeked", () => res(), { once: true });
      setTimeout(res, 800);
    });
  }
}

export const engine = new Engine();
