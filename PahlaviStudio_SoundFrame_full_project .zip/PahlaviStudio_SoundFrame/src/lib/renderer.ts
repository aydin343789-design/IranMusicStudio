import { engine } from "./engine";
import { DRAWERS, makeColorFn, type DrawParams, type VizSettings } from "./visualizers";

export type Aspect = "auto" | "9:16" | "16:9" | "1:1";

/** Canvas size for a given aspect, with `long` = length of the longer side in pixels. */
export function canvasSize(aspect: Aspect, vw: number, vh: number, long: number): [number, number] {
  const even = (n: number) => Math.max(2, Math.round(n / 2) * 2);
  if (aspect === "9:16") return [even((long * 9) / 16), even(long)];
  if (aspect === "16:9") return [even(long), even((long * 9) / 16)];
  if (aspect === "1:1") return [even(long), even(long)];
  if (vw > 0 && vh > 0) {
    const s = Math.min(1, long / Math.max(vw, vh));
    return [even(vw * s), even(vh * s)];
  }
  return [even((long * 9) / 16), even(long)];
}

interface Slot {
  t: number;
  vals: Float32Array;
  wave: Uint8Array<ArrayBuffer>;
  bass: number;
}

const RING = 40;
const MAXN = 128;

export class Renderer {
  private g: CanvasRenderingContext2D;
  private freq: Uint8Array<ArrayBuffer> = new Uint8Array(1024);
  private ring: Slot[] = Array.from({ length: RING }, () => ({
    t: -1,
    vals: new Float32Array(MAXN),
    wave: new Uint8Array(2048),
    bass: 0,
  }));
  private head = 0;
  private cur = new Float32Array(MAXN); // live (un-delayed) smoothed bands
  private peak = new Float32Array(MAXN).fill(0.3);
  private gPeak = 0.3;
  private bassS = 0;
  private prevBass = 0;
  private fluxAvg = 0.02;
  private beat = 0;
  private lastBeat = 0;
  private ripples: { p: number }[] = [];
  private lastNow = 0;
  private edges: Float64Array = new Float64Array(0);
  private edgeKey = "";
  private glow: HTMLCanvasElement | null = null;
  private glowG: CanvasRenderingContext2D | null = null;
  private colorKey = "";
  private colorFn: ReturnType<typeof makeColorFn> | null = null;
  /** true while exporting: no output-latency compensation, recorded audio is un-delayed */
  recording = false;
  bassLevel = 0;

  constructor(public canvas: HTMLCanvasElement) {
    this.g = canvas.getContext("2d", { alpha: false })!;
  }

  private computeEdges(n: number, binHz: number) {
    const key = `${n}:${binHz.toFixed(3)}`;
    if (key === this.edgeKey) return;
    this.edgeKey = key;
    const e = new Float64Array(n + 1);
    const fmin = 40;
    const fmax = 14000;
    for (let i = 0; i <= n; i++) e[i] = (fmin * Math.pow(fmax / fmin, i / n)) / binHz;
    this.edges = e;
  }

  /** read analyser -> bands (fast attack / smooth release, auto-gain), push to ring */
  private analyse(s: VizSettings, now: number, dt: number) {
    const an = engine.analyser;
    const n = Math.min(MAXN, Math.max(8, Math.round(s.count)));
    const slot = this.ring[this.head];
    if (an) {
      if (this.freq.length !== an.frequencyBinCount) this.freq = new Uint8Array(an.frequencyBinCount);
      if (slot.wave.length !== an.fftSize) slot.wave = new Uint8Array(an.fftSize);
      an.getByteFrequencyData(this.freq);
      an.getByteTimeDomainData(slot.wave);
    } else {
      this.freq.fill(0);
      slot.wave.fill(128);
    }
    const sr = engine.ctx?.sampleRate ?? 44100;
    const binHz = sr / 2 / this.freq.length;
    this.computeEdges(n, binHz);
    const maxBin = this.freq.length - 2;
    const attack = 1 - Math.exp(-dt * 60);
    const relRate = 5 + (1 - s.smoothing) * 16;
    const release = 1 - Math.exp(-dt * relRate);
    const peakDecay = Math.exp(-dt / 7);
    let frameMax = 0;

    for (let i = 0; i < n; i++) {
      const c0 = this.edges[i];
      const c1 = this.edges[i + 1];
      let raw: number;
      if (c1 - c0 < 1.6) {
        // low bands: fewer bins than bars -> interpolate so bass bars don't share one value
        const pos = Math.min(maxBin, (c0 + c1) / 2);
        const k = Math.floor(pos);
        const f = pos - k;
        raw = (this.freq[k] * (1 - f) + this.freq[k + 1] * f) / 255;
      } else {
        const b0 = Math.floor(c0);
        const b1 = Math.min(maxBin, Math.ceil(c1));
        let sum = 0;
        let mx = 0;
        for (let b = b0; b <= b1; b++) {
          const q = this.freq[b];
          sum += q;
          if (q > mx) mx = q;
        }
        raw = (sum / (b1 - b0 + 1)) * 0.4 / 255 + (mx * 0.6) / 255;
      }
      if (raw > frameMax) frameMax = raw;
      // per-band automatic gain so quiet highs react as clearly as loud bass
      this.peak[i] = Math.max(raw, this.peak[i] * peakDecay, 0.22);
      const ref = (this.peak[i] * 0.55 + this.gPeak * 0.45) * 0.88;
      let v = Math.min(1.15, raw / ref);
      v = Math.pow(Math.max(0, v), 1.35) * s.sensitivity * 0.92;
      v = Math.min(1, v);
      const c = this.cur[i];
      this.cur[i] = v > c ? c + (v - c) * attack : c + (v - c) * release;
    }
    this.gPeak = Math.max(frameMax, this.gPeak * peakDecay, 0.25);

    // bass energy 30-170 Hz
    const bEnd = Math.max(2, Math.min(maxBin, Math.floor(170 / binHz)));
    let bs = 0;
    for (let i = 1; i <= bEnd; i++) bs += this.freq[i];
    bs = bs / bEnd / 255;
    this.bassS = bs > this.bassS ? this.bassS + (bs - this.bassS) * attack : this.bassS + (bs - this.bassS) * (1 - Math.exp(-dt * 10));

    slot.t = now;
    slot.bass = this.bassS;
    for (let i = 0; i < n; i++) slot.vals[i] = Math.max(0.02, this.cur[i]);
    this.head = (this.head + 1) % RING;
    return { n, slot };
  }

  /** pick the analysed frame that matches what is currently being HEARD */
  private pick(target: number): Slot {
    let best: Slot | null = null;
    let oldest: Slot | null = null;
    for (let k = 1; k <= RING; k++) {
      const sl = this.ring[(this.head - k + RING) % RING];
      if (sl.t < 0) break;
      oldest = sl;
      if (sl.t <= target) {
        best = sl;
        break;
      }
    }
    return best ?? oldest ?? this.ring[(this.head - 1 + RING) % RING];
  }

  private drawViz(g: CanvasRenderingContext2D, s: VizSettings, p: Omit<DrawParams, "g">) {
    DRAWERS[s.style]({ g, ...p });
  }

  frame(time: number, dur: number, s: VizSettings, nowMs: number) {
    const g = this.g;
    const { width: cw, height: ch } = this.canvas;
    const now = nowMs / 1000;
    const dt = Math.min(0.1, Math.max(0.001, now - this.lastNow || 0.016));
    this.lastNow = now;
    const { n } = this.analyse(s, now, dt);

    // latency compensation: the analyser hears audio earlier than the speaker plays it
    let delay = 0;
    if (!this.recording) {
      const lat = engine.ctx ? (engine.ctx.outputLatency || engine.ctx.baseLatency || 0) : 0;
      delay = Math.min(0.45, Math.max(0, s.syncMs / 1000 + lat));
    }
    const slot = this.pick(now - delay);

    // beat detection on the delayed (= heard) signal: spectral flux of the bass
    const flux = Math.max(0, slot.bass - this.prevBass);
    this.prevBass = slot.bass;
    this.fluxAvg = this.fluxAvg * 0.96 + flux * 0.04;
    if (flux > Math.max(0.03, this.fluxAvg * 2.4) && slot.bass > 0.28 && now - this.lastBeat > 0.2) {
      this.lastBeat = now;
      this.beat = 1;
      this.ripples.push({ p: 0 });
    }
    this.beat = Math.max(0, this.beat - dt * 4.2);
    for (const r of this.ripples) r.p += dt * 0.9;
    this.ripples = this.ripples.filter((r) => r.p < 1);
    this.bassLevel = slot.bass;

    // background
    g.globalAlpha = 1;
    if (engine.hasVideo && engine.video.readyState >= 2 && engine.video.videoWidth > 0) {
      const v = engine.video;
      const sc = Math.max(cw / v.videoWidth, ch / v.videoHeight) * (s.beatZoom ? 1 + this.beat * 0.04 : 1);
      const dw = v.videoWidth * sc;
      const dh = v.videoHeight * sc;
      g.drawImage(v, (cw - dw) / 2, (ch - dh) / 2, dw, dh);
    } else {
      const hue = (now * 12) % 360;
      const bg = g.createLinearGradient(0, 0, cw, ch);
      bg.addColorStop(0, `hsl(${230 + Math.sin(now * 0.2) * 20},45%,10%)`);
      bg.addColorStop(1, `hsl(${(hue + 280) % 360},50%,${12 + this.beat * 6}%)`);
      g.fillStyle = bg;
      g.fillRect(0, 0, cw, ch);
      g.strokeStyle = "rgba(255,255,255,0.04)";
      g.lineWidth = 1;
      g.beginPath();
      const gs = cw / 12;
      for (let x = 0; x < cw; x += gs) {
        g.moveTo(x, 0);
        g.lineTo(x, ch);
      }
      for (let y = 0; y < ch; y += gs) {
        g.moveTo(0, y);
        g.lineTo(cw, y);
      }
      g.stroke();
    }
    if (s.dim > 0) {
      g.fillStyle = `rgba(0,0,0,${s.dim})`;
      g.fillRect(0, 0, cw, ch);
    }

    // range fade
    let alpha = s.opacity;
    if (dur > 0) {
      const a = s.rangeStart * dur;
      const b = s.rangeEnd * dur;
      alpha *= Math.min(1, Math.max(0, Math.min(time - a, b - time) / 0.6));
    }

    if (alpha > 0.005) {
      const bw = s.box.w * cw;
      const bh = s.box.h * ch;
      const bx = s.box.cx * cw - bw / 2;
      const by = s.box.cy * ch - bh / 2;
      const key = `${s.palette}|${s.colorA}|${s.colorB}`;
      if (key !== this.colorKey || !this.colorFn) {
        this.colorKey = key;
        this.colorFn = makeColorFn(s);
      }
      const base = {
        x: bx,
        y: by,
        w: bw,
        h: bh,
        v: slot.vals,
        n,
        wave: slot.wave,
        color: this.colorFn,
        bass: slot.bass,
        beat: this.beat,
        thick: s.thickness,
        sens: s.sensitivity,
        time: now,
        ripples: this.ripples,
      };

      // cheap neon glow: draw the visual again on a tiny canvas and scale it up (soft blur),
      // instead of the very slow canvas shadowBlur.
      if (s.glow > 0) {
        const GS = 0.25;
        const gw = Math.max(8, Math.round(cw * GS));
        const gh = Math.max(8, Math.round(ch * GS));
        if (!this.glow) {
          this.glow = document.createElement("canvas");
          this.glowG = this.glow.getContext("2d");
        }
        if (this.glow.width !== gw || this.glow.height !== gh) {
          this.glow.width = gw;
          this.glow.height = gh;
        }
        const gg = this.glowG!;
        gg.setTransform(1, 0, 0, 1, 0, 0);
        gg.clearRect(0, 0, gw, gh);
        gg.setTransform(gw / cw, 0, 0, gh / ch, 0, 0);
        gg.globalAlpha = 1;
        this.drawViz(gg, s, base);
        g.save();
        g.globalCompositeOperation = "lighter";
        g.globalAlpha = Math.min(1, (s.glow / 24) * 0.9 + this.beat * 0.15) * alpha;
        g.imageSmoothingEnabled = true;
        g.imageSmoothingQuality = "low";
        g.drawImage(this.glow, 0, 0, cw, ch);
        g.restore();
      }

      g.save();
      g.globalAlpha = alpha;
      this.drawViz(g, s, base);
      g.restore();
    }

    if (s.beatFlash && this.beat > 0) {
      g.fillStyle = `rgba(255,255,255,${this.beat * 0.16})`;
      g.fillRect(0, 0, cw, ch);
    }
  }
}
