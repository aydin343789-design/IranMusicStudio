export type VizStyle =
  | "bars"
  | "mirror"
  | "led"
  | "circle"
  | "ringwave"
  | "wave"
  | "area"
  | "dots"
  | "rings"
  | "flower";

export interface VizBox {
  cx: number;
  cy: number;
  w: number;
  h: number;
}

export interface VizSettings {
  style: VizStyle;
  palette: string;
  colorA: string;
  colorB: string;
  count: number;
  sensitivity: number;
  smoothing: number;
  glow: number;
  thickness: number;
  opacity: number;
  rangeStart: number;
  rangeEnd: number;
  beatZoom: boolean;
  beatFlash: boolean;
  dim: number;
  syncMs: number;
  box: VizBox;
}

export const STYLE_LIST: { id: VizStyle; label: string }[] = [
  { id: "bars", label: "میله‌ای" },
  { id: "mirror", label: "آینه‌ای" },
  { id: "led", label: "LED" },
  { id: "circle", label: "دایره‌ای" },
  { id: "ringwave", label: "حلقه موج" },
  { id: "wave", label: "موج" },
  { id: "area", label: "کوهستانی" },
  { id: "dots", label: "نقطه‌ای" },
  { id: "rings", label: "حلقه‌های پالس" },
  { id: "flower", label: "گل" },
];

export const PALETTES: Record<string, { name: string; stops: string[] }> = {
  neon: { name: "نئون", stops: ["#00f2fe", "#7c4dff", "#ff4fd8"] },
  sunset: { name: "غروب", stops: ["#ff512f", "#f09819", "#ffe259"] },
  aurora: { name: "شفق", stops: ["#00f5a0", "#00d9f5", "#a18cd1"] },
  fire: { name: "آتش", stops: ["#ff0844", "#ff6a00", "#ffd200"] },
  ice: { name: "یخ", stops: ["#ffffff", "#9be7ff", "#4facfe"] },
  rainbow: {
    name: "رنگین‌کمان",
    stops: ["#ff3b3b", "#ffd23b", "#3bff7a", "#3bd6ff", "#6a5cff", "#ff3bd6"],
  },
  mono: { name: "سفید", stops: ["#ffffff", "#e6e6e6"] },
  custom: { name: "سفارشی", stops: [] },
};

type RGB = [number, number, number];

function hexToRgb(h: string): RGB {
  const s = h.replace("#", "");
  const n = parseInt(s.length === 3 ? s.split("").map((c) => c + c).join("") : s, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export type ColorFn = (t: number, a?: number) => string;

export function makeColorFn(s: VizSettings): ColorFn {
  const stops: RGB[] = (
    s.palette === "custom" ? [s.colorA, s.colorB] : PALETTES[s.palette]?.stops ?? PALETTES.neon.stops
  ).map(hexToRgb);
  return (t, a = 1) => {
    const tt = Math.min(1, Math.max(0, t));
    if (stops.length === 1) return `rgba(${stops[0].join(",")},${a})`;
    const p = tt * (stops.length - 1);
    const i = Math.min(stops.length - 2, Math.floor(p));
    const f = p - i;
    const c = stops[i].map((v, k) => Math.round(v + (stops[i + 1][k] - v) * f));
    return `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  };
}

export interface DrawParams {
  g: CanvasRenderingContext2D;
  x: number;
  y: number;
  w: number;
  h: number;
  v: Float32Array;
  n: number;
  wave: Uint8Array;
  color: ColorFn;
  bass: number;
  beat: number;
  thick: number;
  sens: number;
  time: number;
  ripples: { p: number }[];
}

function rr(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rad = Math.max(0, Math.min(r, w / 2, h / 2));
  g.beginPath();
  g.moveTo(x + rad, y);
  g.arcTo(x + w, y, x + w, y + h, rad);
  g.arcTo(x + w, y + h, x, y + h, rad);
  g.arcTo(x, y + h, x, y, rad);
  g.arcTo(x, y, x + w, y, rad);
  g.closePath();
}

function hGradient(p: DrawParams, x0: number, x1: number) {
  const gr = p.g.createLinearGradient(x0, 0, x1, 0);
  for (let i = 0; i <= 6; i++) gr.addColorStop(i / 6, p.color(i / 6));
  return gr;
}

function bars(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick } = p;
  const gap = w / n;
  const bw = Math.max(1.5, gap * (0.25 + thick * 0.7));
  for (let i = 0; i < n; i++) {
    const bh = Math.max(bw, v[i] * h);
    g.fillStyle = color(i / Math.max(1, n - 1));
    rr(g, x + i * gap + (gap - bw) / 2, y + h - bh, bw, bh, bw / 2);
    g.fill();
  }
}

function mirror(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick } = p;
  const gap = w / n;
  const bw = Math.max(1.5, gap * (0.25 + thick * 0.7));
  const cy = y + h / 2;
  for (let i = 0; i < n; i++) {
    const bh = Math.max(bw, v[i] * h);
    g.fillStyle = color(i / Math.max(1, n - 1));
    rr(g, x + i * gap + (gap - bw) / 2, cy - bh / 2, bw, bh, bw / 2);
    g.fill();
  }
}

function led(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick } = p;
  const segs = 16;
  const sh = h / segs;
  const gap = w / n;
  const bw = Math.max(2, gap * (0.3 + thick * 0.6));
  for (let i = 0; i < n; i++) {
    const lit = Math.round(v[i] * segs);
    for (let s = 0; s < segs; s++) {
      const on = s < lit;
      g.fillStyle = on ? color(s / segs) : "rgba(255,255,255,0.06)";
      const yy = y + h - (s + 1) * sh + sh * 0.12;
      rr(g, x + i * gap + (gap - bw) / 2, yy, bw, sh * 0.76, 1.5);
      g.fill();
    }
  }
}

function circle(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, bass, thick, time } = p;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const R = Math.min(w, h) / 2;
  const r0 = R * 0.42 * (1 + bass * 0.14);
  const len = R * 0.58;
  const total = n * 2;
  g.lineCap = "round";
  g.lineWidth = Math.max(1.5, ((2 * Math.PI * r0) / total) * (0.35 + thick * 0.6));
  for (let k = 0; k < total; k++) {
    const idx = k < n ? k : total - 1 - k;
    const a = (k / total) * Math.PI * 2 - Math.PI / 2 + time * 0.12;
    const l = Math.max(2, v[idx] * len);
    g.strokeStyle = color(idx / Math.max(1, n - 1));
    g.beginPath();
    g.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
    g.lineTo(cx + Math.cos(a) * (r0 + l), cy + Math.sin(a) * (r0 + l));
    g.stroke();
  }
  g.lineWidth = 2;
  g.strokeStyle = color(0.5, 0.7);
  g.beginPath();
  g.arc(cx, cy, r0 * 0.9, 0, Math.PI * 2);
  g.stroke();
  g.fillStyle = color(0.5, 0.12 + bass * 0.25);
  g.fill();
}

function ringwave(p: DrawParams) {
  const { g, x, y, w, h, wave, color, sens, bass, thick, time } = p;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const R = Math.min(w, h) / 2;
  const r0 = R * 0.55 * (1 + bass * 0.1);
  const steps = 180;
  const half = Math.floor(wave.length / 2);
  const draw = (scale: number, alpha: number, lw: number, col: number) => {
    g.beginPath();
    for (let j = 0; j <= steps; j++) {
      const m = j <= steps / 2 ? j : steps - j; // mirrored => seamless
      const si = Math.floor((m / (steps / 2)) * (half - 1));
      const d = (wave[si] - 128) / 128;
      const a = (j / steps) * Math.PI * 2 + time * 0.2;
      const r = (r0 + d * R * 0.55 * sens * 1.4) * scale;
      const px = cx + Math.cos(a) * r;
      const py = cy + Math.sin(a) * r;
      if (j === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.closePath();
    g.lineWidth = lw;
    g.strokeStyle = color(col, alpha);
    g.stroke();
  };
  draw(1.18, 0.35, 1.5, 0.85);
  draw(1, 1, 2 + thick * 3, 0.15);
  draw(0.82, 0.5, 1.5, 0.55);
}

function wave(p: DrawParams) {
  const { g, x, y, w, h, wave: wv, sens, thick } = p;
  const cy = y + h / 2;
  const grad = hGradient(p, x, x + w);
  const pts = 160;
  const draw = (flip: number, alpha: number, lw: number) => {
    g.beginPath();
    for (let j = 0; j <= pts; j++) {
      const si = Math.floor((j / pts) * (wv.length * 0.5 - 1));
      const d = (wv[si] - 128) / 128;
      const px = x + (j / pts) * w;
      const py = cy + flip * d * (h / 2) * sens * 1.6;
      if (j === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.globalAlpha *= alpha;
    g.lineWidth = lw;
    g.strokeStyle = grad;
    g.lineJoin = "round";
    g.stroke();
    g.globalAlpha /= alpha;
  };
  draw(-1, 0.35, 2);
  draw(1, 1, 2 + thick * 4);
}

function area(p: DrawParams) {
  const { g, x, y, w, h, v, n, color } = p;
  const pts: [number, number][] = [];
  for (let i = 0; i < n; i++) pts.push([x + (i / (n - 1)) * w, y + h - Math.max(0.03, v[i]) * h]);
  g.beginPath();
  g.moveTo(x, y + h);
  g.lineTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length - 1; i++) {
    const mx = (pts[i][0] + pts[i + 1][0]) / 2;
    const my = (pts[i][1] + pts[i + 1][1]) / 2;
    g.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
  }
  g.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
  g.lineTo(x + w, y + h);
  g.closePath();
  const fill = g.createLinearGradient(0, y, 0, y + h);
  fill.addColorStop(0, color(0.5, 0.75));
  fill.addColorStop(1, color(0, 0.05));
  g.fillStyle = fill;
  g.fill();
  g.lineWidth = 2.5;
  g.strokeStyle = hGradient(p, x, x + w);
  g.stroke();
}

function dots(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick } = p;
  const cols = Math.min(n, 28);
  const rows = 12;
  const cw = w / cols;
  const ch = h / rows;
  const rad = (Math.min(cw, ch) / 2) * (0.35 + thick * 0.55);
  for (let c = 0; c < cols; c++) {
    const val = v[Math.floor((c / cols) * n)];
    const lit = Math.round(val * rows);
    for (let r = 0; r < rows; r++) {
      const on = r < lit;
      g.fillStyle = on ? color(r / rows) : "rgba(255,255,255,0.07)";
      g.beginPath();
      g.arc(x + (c + 0.5) * cw, y + h - (r + 0.5) * ch, rad, 0, Math.PI * 2);
      g.fill();
    }
  }
}

function rings(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick, ripples, bass } = p;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const R = Math.min(w, h) / 2;
  const bands = 5;
  for (let j = 0; j < bands; j++) {
    const a = Math.floor((j / bands) * n);
    const b = Math.max(a + 1, Math.floor(((j + 1) / bands) * n));
    let e = 0;
    for (let i = a; i < b; i++) e += v[i];
    e /= b - a;
    const r = R * (0.2 + j * 0.15) * (1 + e * 0.18);
    g.lineWidth = 2 + e * 14 * (0.3 + thick);
    g.strokeStyle = color(j / (bands - 1), 0.45 + e * 0.55);
    g.beginPath();
    g.arc(cx, cy, r, 0, Math.PI * 2);
    g.stroke();
  }
  for (const rp of ripples) {
    g.lineWidth = 3;
    g.strokeStyle = color(0.5 + rp.p * 0.5, (1 - rp.p) * 0.8);
    g.beginPath();
    g.arc(cx, cy, R * (0.2 + rp.p * 0.8), 0, Math.PI * 2);
    g.stroke();
  }
  g.fillStyle = color(0, 0.4 + bass * 0.5);
  g.beginPath();
  g.arc(cx, cy, R * 0.1 * (1 + bass * 0.5), 0, Math.PI * 2);
  g.fill();
}

function flower(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, bass, time } = p;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const R = Math.min(w, h) / 2;
  const total = n * 2;
  const build = (r0: number, len: number, rot: number) => {
    const pts: [number, number][] = [];
    for (let k = 0; k < total; k++) {
      const idx = k < n ? k : total - 1 - k;
      const a = (k / total) * Math.PI * 2 + rot;
      const r = r0 + v[idx] * len;
      pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
    }
    g.beginPath();
    const last = pts[pts.length - 1];
    g.moveTo((last[0] + pts[0][0]) / 2, (last[1] + pts[0][1]) / 2);
    for (let i = 0; i < pts.length; i++) {
      const nx = pts[(i + 1) % pts.length];
      g.quadraticCurveTo(pts[i][0], pts[i][1], (pts[i][0] + nx[0]) / 2, (pts[i][1] + nx[1]) / 2);
    }
    g.closePath();
  };
  const r0 = R * 0.3 * (1 + bass * 0.12);
  build(r0, R * 0.7, time * 0.15);
  const rg = g.createRadialGradient(cx, cy, r0 * 0.3, cx, cy, R);
  rg.addColorStop(0, color(0, 0.55));
  rg.addColorStop(1, color(1, 0.15));
  g.fillStyle = rg;
  g.fill();
  g.lineWidth = 2.5;
  g.strokeStyle = color(0.7);
  g.stroke();
  build(r0 * 0.6, R * 0.35, -time * 0.25);
  g.lineWidth = 1.8;
  g.strokeStyle = color(0.2, 0.9);
  g.stroke();
}

export const DRAWERS: Record<VizStyle, (p: DrawParams) => void> = {
  bars,
  mirror,
  led,
  circle,
  ringwave,
  wave,
  area,
  dots,
  rings,
  flower,
};

export const DEFAULT_VIZ: VizSettings = {
  style: "bars",
  palette: "neon",
  colorA: "#00f2fe",
  colorB: "#ff4fd8",
  count: 48,
  sensitivity: 1.1,
  smoothing: 0.7,
  glow: 14,
  thickness: 0.65,
  opacity: 1,
  rangeStart: 0,
  rangeEnd: 1,
  beatZoom: true,
  beatFlash: false,
  dim: 0.25,
  syncMs: 60,
  box: { cx: 0.5, cy: 0.5, w: 0.8, h: 0.3 },
};
