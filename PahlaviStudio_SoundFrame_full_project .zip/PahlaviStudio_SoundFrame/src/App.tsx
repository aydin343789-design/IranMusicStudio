import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AudioLines,
  FolderOpen,
  Sliders,
  Film,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  RotateCw,
  Save,
  X,
} from "lucide-react";
import { engine, generateDemoBeat, makeThumbs } from "./lib/engine";
import { timeStore } from "./lib/timeStore";
import { FileSink, isNative, saveToPublicFolder } from "./lib/native";
import { Renderer, canvasSize } from "./lib/renderer";
import { DEFAULT_VIZ, STYLE_LIST, type VizSettings } from "./lib/visualizers";
import { DEFAULT_PROJECT, EMPTY_MEDIA, type ExportState, type Media, type Project, type Tab } from "./lib/types";
import Preview from "./components/Preview";
import Timeline from "./components/Timeline";
import { EqPanel, ExportPanel, MediaPanel, StudioControls } from "./components/Panels";
import { cn } from "./utils/cn";

const STORE_KEY = "soundframe.studio.v1";

function loadSaved(): { viz: VizSettings; project: Project } {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) {
      const j = JSON.parse(raw);
      return {
        viz: { ...DEFAULT_VIZ, ...j.viz, box: { ...DEFAULT_VIZ.box, ...(j.viz?.box ?? {}) } },
        project: { ...DEFAULT_PROJECT, ...j.project, offset: 0 },
      };
    }
  } catch {
    /* ignore */
  }
  return { viz: DEFAULT_VIZ, project: DEFAULT_PROJECT };
}

const PREVIEW_LONG = 720;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export default function App() {
  const saved = useMemo(loadSaved, []);
  const [viz, setVizState] = useState<VizSettings>(saved.viz);
  const [project, setProjectState] = useState<Project>(saved.project);
  const [media, setMedia] = useState<Media>(EMPTY_MEDIA);
  const [tab, setTab] = useState<Tab>("media");
  const [playing, setPlaying] = useState(false);
  const [exportRes, setExportRes] = useState<number | null>(null);
  const [exp, setExp] = useState<ExportState>({ status: "idle", progress: 0 });
  const [busy, setBusy] = useState("");
  const [notice, setNotice] = useState("");
  const [savedFlag, setSavedFlag] = useState(false);
  const [flash, setFlash] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<Renderer | null>(null);
  const vizRef = useRef(viz);
  vizRef.current = viz;
  const expRef = useRef(exp);
  expRef.current = exp;
  const recRef = useRef<null | { rec: MediaRecorder; cancelled: boolean }>(null);
  const finishing = useRef(false);

  const setViz = useCallback((p: Partial<VizSettings>) => setVizState((v) => ({ ...v, ...p })), []);
  const setProject = useCallback((p: Partial<Project>) => {
    if (expRef.current.status === "recording" && p.aspect) return;
    setProjectState((v) => ({ ...v, ...p }));
  }, []);

  const [cw, ch] = canvasSize(project.aspect, media.vw, media.vh, exportRes ?? PREVIEW_LONG);
  const hasVideo = !!media.videoName;
  const hasAudio = !!media.audioName;
  const duration = hasVideo ? media.videoDur : hasAudio ? media.audioDur : 0;

  const toast = useCallback((m: string) => {
    setNotice(m);
    setTimeout(() => setNotice(""), 4000);
  }, []);

  /* ---- engine params ---- */
  useEffect(() => {
    engine.offset = project.offset;
    engine.loop = project.loop;
    engine.musicVol = project.musicVol;
    engine.videoVol = project.videoMuted ? 0 : project.videoVol;
    engine.applyVolumes();
    if (!engine.playing && engine.hasVideo) engine.seek(engine.time);
  }, [project.offset, project.loop, project.musicVol, project.videoVol, project.videoMuted]);

  /* ---- recording finish ---- */
  const finishRecording = useCallback(async () => {
    const r = recRef.current;
    if (!r || finishing.current) return;
    finishing.current = true;
    await sleep(350);
    if (r.rec.state !== "inactive") r.rec.stop();
    engine.pause();
    engine.seek(0);
    setPlaying(false);
  }, []);

  const handleEnd = useCallback(() => {
    if (recRef.current) {
      void finishRecording();
    } else {
      engine.pause();
      engine.seek(0);
      setPlaying(false);
    }
  }, [finishRecording]);

  /* ---- main render loop (adaptive frame pacing) ---- */
  useEffect(() => {
    if (canvasRef.current && !rendererRef.current) rendererRef.current = new Renderer(canvasRef.current);
    let raf = 0;
    let lastUi = 0;
    let lastRender = 0;
    let interval = 16.6;
    let costEma = 6;
    let lastAdapt = 0;
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const r = rendererRef.current;
      if (!r) return;
      engine.tick();
      const t = engine.time;
      const dur = engine.duration;
      const rec = recRef.current !== null;
      // 30 fps while recording (steady frames), adaptive 60/30 fps for live preview
      if (now - lastRender >= (rec ? 31 : interval - 3)) {
        lastRender = now;
        const t0 = performance.now();
        r.frame(t, dur, vizRef.current, now);
        costEma = costEma * 0.9 + (performance.now() - t0) * 0.1;
        if (!rec && now - lastAdapt > 1500) {
          lastAdapt = now;
          interval = costEma > 11 ? 33.3 : costEma < 6 ? 16.6 : interval;
        }
      }
      if (engine.playing && dur > 0 && t >= dur - 0.05) handleEnd();
      if (now - lastUi > 50) {
        lastUi = now;
        timeStore.set(t, dur);
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [handleEnd]);

  useEffect(() => {
    const onEnded = () => {
      if (engine.playing) handleEnd();
    };
    const onAudioEnded = () => {
      if (engine.playing && !engine.hasVideo) onEnded();
    };
    engine.video.addEventListener("ended", onEnded);
    engine.audio.addEventListener("ended", onAudioEnded);
    return () => {
      engine.video.removeEventListener("ended", onEnded);
      engine.audio.removeEventListener("ended", onAudioEnded);
    };
  }, [handleEnd]);

  /* ---- transport ---- */
  const togglePlay = useCallback(async () => {
    if (engine.duration <= 0) {
      toast("ابتدا یک ویدئو یا موزیک اضافه کنید");
      setTab("media");
      return;
    }
    if (engine.playing) {
      engine.pause();
      setPlaying(false);
    } else {
      await engine.play();
      setPlaying(true);
    }
  }, [toast]);

  const seek = useCallback((t: number) => {
    engine.seek(t);
    timeStore.set(Math.max(0, Math.min(engine.duration, t)), engine.duration);
  }, []);
  const onBox = useCallback((box: VizSettings["box"]) => setViz({ box }), [setViz]);
  const onOffset = useCallback((o: number) => setProject({ offset: o }), [setProject]);

  /* ---- media loading ---- */
  const onVideo = async (file: File) => {
    setBusy("video");
    try {
      const info = await engine.loadVideo(file);
      setPlaying(false);
      setMedia((m) => ({ ...m, videoName: file.name, vw: info.w, vh: info.h, videoDur: info.dur, thumbs: [] }));
      timeStore.set(0, engine.duration);
      makeThumbs(info.url, 8).then((th) => setMedia((m) => (m.videoName === file.name ? { ...m, thumbs: th } : m)));
      toast("ویدئو بارگذاری شد ✓");
    } catch {
      toast("این ویدئو توسط مرورگر پشتیبانی نمی‌شود. فرمت MP4 (H.264) یا WebM را امتحان کنید.");
    }
    setBusy("");
  };

  const onAudio = async (file: File) => {
    setBusy("audio");
    try {
      const a = await engine.loadAudio(file);
      setPlaying(false);
      setMedia((m) => ({ ...m, audioName: file.name, audioDur: a.duration, analysis: a }));
      toast(`موزیک بارگذاری شد — تمپو حدود ${Math.round(a.bpm)} BPM`);
    } catch {
      toast("خواندن فایل موزیک ممکن نشد. فرمت MP3 یا WAV را امتحان کنید.");
    }
    setBusy("");
  };

  const onDemo = async () => {
    setBusy("demo");
    try {
      engine.ensureAudio();
      const { blob, buffer } = await generateDemoBeat();
      const a = await engine.loadAudio(blob, buffer);
      setPlaying(false);
      setMedia((m) => ({ ...m, audioName: "Synthwave Demo.wav", audioDur: a.duration, analysis: a }));
      toast("موزیک دمو ساخته شد. دکمه پخش را بزنید!");
    } catch {
      toast("ساخت موزیک دمو ممکن نشد.");
    }
    setBusy("");
  };

  const clearVideo = () => {
    engine.clearVideo();
    setPlaying(false);
    setMedia((m) => ({ ...m, videoName: "", vw: 0, vh: 0, videoDur: 0, thumbs: [] }));
    timeStore.set(0, engine.duration);
  };
  const clearAudio = () => {
    engine.clearAudio();
    setPlaying(false);
    setMedia((m) => ({ ...m, audioName: "", audioDur: 0, analysis: null }));
    timeStore.set(0, engine.duration);
  };

  const alignBeat = () => {
    if (!media.analysis) return;
    setProject({ offset: -Math.round(media.analysis.firstBeat * 100) / 100 });
    setFlash(true);
    setTimeout(() => setFlash(false), 500);
    toast("اولین ضرب موزیک با شروع ویدئو هماهنگ شد");
  };

  const save = () => {
    localStorage.setItem(STORE_KEY, JSON.stringify({ viz, project }));
    setSavedFlag(true);
    setTimeout(() => setSavedFlag(false), 1800);
  };
  const reset = () => {
    setVizState(DEFAULT_VIZ);
    setProjectState({ ...DEFAULT_PROJECT });
    localStorage.removeItem(STORE_KEY);
    toast("تنظیمات به حالت پیش‌فرض برگشت");
  };

  /* ---- export ---- */
  const startExport = async () => {
    const canvas = canvasRef.current;
    const renderer = rendererRef.current;
    if (!canvas || !renderer || engine.duration <= 0) return;
    if (typeof MediaRecorder === "undefined" || !canvas.captureStream) {
      setExp({ status: "error", progress: 0, message: "این دستگاه از ضبط خروجی پشتیبانی نمی‌کند (نیاز به نسخه جدید Android System WebView / Chrome)." });
      return;
    }
    if (exp.url && !isNative) URL.revokeObjectURL(exp.url);
    setExp({ status: "recording", progress: 0 });
    engine.ensureAudio();
    engine.pause();
    setPlaying(false);
    engine.seek(0);
    // switch the canvas to the chosen export resolution
    renderer.recording = true;
    setExportRes(project.exportLong);
    await engine.waitSeek();
    await sleep(500);
    if (!engine.recDest) return;

    const stream = canvas.captureStream(30);
    engine.recDest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
    const mimes = [
      "video/mp4;codecs=avc1.640028,mp4a.40.2",
      "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
      "video/mp4",
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm",
    ];
    const mime = mimes.find((m) => MediaRecorder.isTypeSupported(m)) ?? "";
    const ext = mime.includes("mp4") ? "mp4" : "webm";
    const stopUi = () => {
      renderer.recording = false;
      setExportRes(null);
    };
    let rec: MediaRecorder;
    try {
      rec = new MediaRecorder(stream, {
        mimeType: mime || undefined,
        videoBitsPerSecond: project.bitrate * 1e6,
        audioBitsPerSecond: 160000,
      });
    } catch {
      stopUi();
      setExp({ status: "error", progress: 0, message: "ساخت ضبط‌کننده ناموفق بود. رزولوشن یا کیفیت را کمتر کنید." });
      return;
    }
    const fileName = `pahlavi-studio-${Date.now()}.${ext}`;
    const sink = isNative ? new FileSink(fileName) : null;
    const chunks: Blob[] = [];
    rec.ondataavailable = (e) => {
      if (!e.data.size) return;
      if (sink) sink.push(e.data); // streamed to disk: no RAM growth
      else chunks.push(e.data);
    };
    const info = { rec, cancelled: false };
    recRef.current = info;
    finishing.current = false;
    rec.onerror = () => {
      info.cancelled = true;
      stopUi();
      setExp({ status: "error", progress: 0, message: "خطا در ضبط. رزولوشن را کمتر کنید و دوباره امتحان کنید." });
      engine.pause();
      setPlaying(false);
    };
    rec.onstop = async () => {
      engine.speakerOn = true;
      engine.applyVolumes();
      recRef.current = null;
      finishing.current = false;
      stopUi();
      if (info.cancelled) {
        if (sink) void sink.remove();
        setExp((e) => (e.status === "error" ? e : { status: "idle", progress: 0 }));
        return;
      }
      const type = (rec.mimeType || mime || "video/webm").split(";")[0];
      if (sink) {
        try {
          const { uri, src } = await sink.finish();
          const savedTo = await saveToPublicFolder(fileName, fileName);
          setExp({ status: "done", progress: 1, url: src, uri, ext, size: sink.bytes, savedTo });
        } catch {
          setExp({ status: "error", progress: 0, message: "ذخیره فایل روی حافظه ناموفق بود. فضای خالی دستگاه را بررسی کنید." });
        }
      } else {
        const blob = new Blob(chunks, { type });
        chunks.length = 0;
        setExp({ status: "done", progress: 1, url: URL.createObjectURL(blob), ext, size: blob.size });
      }
    };
    engine.speakerOn = !project.muteWhileExport;
    engine.applyVolumes();
    rec.start(1000);
    await engine.play();
    setPlaying(true);
  };

  const cancelExport = () => {
    const r = recRef.current;
    if (!r) return;
    r.cancelled = true;
    if (r.rec.state !== "inactive") r.rec.stop();
    engine.pause();
    engine.seek(0);
    setPlaying(false);
  };

  const recording = exp.status === "recording";
  const styleLabel = STYLE_LIST.find((s) => s.id === viz.style)?.label ?? "";

  const navItems: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "media", label: "رسانه‌ها", icon: <FolderOpen size={21} /> },
    { id: "studio", label: "استودیو", icon: <Sliders size={21} /> },
    { id: "eq", label: "اکولایزر", icon: <AudioLines size={21} /> },
    { id: "export", label: "خروجی", icon: <Film size={21} /> },
  ];

  return (
    <div className="min-h-screen bg-surface pb-[calc(7rem+var(--sab))] pt-[calc(4rem+var(--sat))] text-ink" dir="rtl">
      {/* header */}
      <header className="fixed inset-x-0 top-0 z-50 bg-surface/90 pt-[var(--sat)] shadow-[0_1px_12px_rgba(0,0,0,0.45)]">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-2 px-4">
          <div className="flex min-w-0 items-center gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-cyan to-[#ff4fd8] text-[#00373a] shadow-[0_0_14px_rgba(0,242,254,0.4)]">
              <AudioLines size={20} strokeWidth={2.6} />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className={cn("h-1.5 w-1.5 rounded-full bg-cyan-dim", playing && "animate-pulse")} />
                <span className="truncate text-[15px] font-bold tracking-tight">استودیو پهلوی</span>
              </div>
              <div className="truncate text-[10.5px] text-mute">میکس موزیک و ویدئو با اکولایزر زنده</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="hidden rounded-md bg-mid px-2 py-1 font-mono text-[10px] text-cyan sm:block">
              {recording ? "● REC" : playing ? "MONITOR ACTIVE" : "READY"}
            </span>
            <button
              onClick={save}
              aria-label="ذخیره تنظیمات پروژه" title="ذخیره تنظیمات پروژه"
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-high text-cyan-dim shadow-[0_0_12px_rgba(0,242,254,0.2)] transition hover:bg-bright active:scale-95"
            >
              <Save size={18} />
            </button>
          </div>
        </div>
      </header>

      {notice && (
        <div className="fixed inset-x-0 top-[calc(72px+var(--sat))] z-[60] flex justify-center px-4">
          <div className="fade-up flex max-w-md items-center gap-2 rounded-xl bg-high px-3 py-2 text-[12.5px] text-ink shadow-2xl ring-1 ring-cyan/30">
            <span className="grow">{notice}</span>
            <button onClick={() => setNotice("")} className="text-mute">
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      <main className="mx-auto grid max-w-[520px] grid-cols-1 gap-3 px-3 pt-3 lg:max-w-6xl lg:grid-cols-2 lg:gap-5 lg:px-4">
        {/* left: preview + transport */}
        <div className="flex flex-col gap-3 lg:sticky lg:top-[calc(76px+var(--sat))] lg:self-start">
          <Preview
            canvasRef={canvasRef}
            cw={cw}
            ch={ch}
            box={viz.box}
            onBox={onBox}
            playing={playing}
            hasMedia={hasVideo || hasAudio}
            videoMuted={project.videoMuted || !hasVideo}
            recording={recording}
            styleLabel={styleLabel}
            onTogglePlay={togglePlay}
          />

          <div className="flex items-center justify-between gap-1.5 rounded-xl bg-low/90 p-2 shadow-lg">
            <div className="flex gap-1.5">
              <button
                aria-label="۵ ثانیه به عقب"
                onClick={() => seek(engine.time - 5)}
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-mid text-ink transition hover:text-cyan active:scale-95"
              >
                <RotateCcw size={18} />
              </button>
              <button
                aria-label="ابتدا"
                onClick={() => seek(0)}
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-mid text-ink transition hover:text-cyan active:scale-95"
              >
                <SkipForward size={18} />
              </button>
            </div>
            <button
              onClick={togglePlay}
              disabled={recording}
              className={cn(
                "flex h-11 min-w-[130px] items-center justify-center gap-2 rounded-xl px-5 text-[14px] font-bold transition active:scale-95 disabled:opacity-60",
                playing
                  ? "bg-rose text-[#680018] shadow-[0_0_18px_rgba(255,179,181,0.4)]"
                  : "bg-cyan text-[#006a70] shadow-[0_0_18px_rgba(0,242,254,0.45)]",
              )}
            >
              {playing ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
              {playing ? "توقف" : "پخش زنده"}
            </button>
            <div className="flex gap-1.5">
              <button
                aria-label="پایان"
                onClick={() => seek(Math.max(0, duration - 0.1))}
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-mid text-ink transition hover:text-cyan active:scale-95"
              >
                <SkipBack size={18} />
              </button>
              <button
                aria-label="۵ ثانیه به جلو"
                onClick={() => seek(engine.time + 5)}
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-mid text-ink transition hover:text-cyan active:scale-95"
              >
                <RotateCw size={18} />
              </button>
            </div>
          </div>
        </div>

        {/* right: panels */}
        <div className="min-w-0 pb-4">
          {tab === "media" && (
            <MediaPanel
              media={media}
              project={project}
              setProject={setProject}
              busy={busy}
              onVideo={onVideo}
              onAudio={onAudio}
              onDemo={onDemo}
              onClearVideo={clearVideo}
              onClearAudio={clearAudio}
              onSave={save}
              onReset={reset}
              saved={savedFlag}
            />
          )}
          {tab === "studio" && (
            <div>
              <Timeline
                duration={duration}
                onSeek={seek}
                hasVideo={hasVideo}
                hasAudio={hasAudio}
                thumbs={media.thumbs}
                analysis={media.analysis}
                audioName={media.audioName}
                videoName={media.videoName}
                audioDur={media.audioDur}
                offset={project.offset}
                loop={project.loop}
                locked={project.locked}
                showBeats={project.showBeats}
                onOffset={onOffset}
                rangeStart={viz.rangeStart}
                rangeEnd={viz.rangeEnd}
                videoMuted={project.videoMuted}
                musicVol={project.musicVol}
              />
              <StudioControls
                media={media}
                project={project}
                setProject={setProject}
                hasVideo={hasVideo}
                onAlignBeat={alignBeat}
                flash={flash}
              />
            </div>
          )}
          {tab === "eq" && <EqPanel viz={viz} setViz={setViz} />}
          {tab === "export" && (
            <ExportPanel
              project={project}
              setProject={setProject}
              cw={cw}
              ch={ch}
              duration={duration}
              ready={duration > 0}
              exp={exp}
              onStart={startExport}
              onCancel={cancelExport}
            />
          )}
        </div>
      </main>

      {/* bottom nav */}
      <nav className="pb-safe fixed inset-x-0 bottom-0 z-50 bg-lowest/95 shadow-[0_-4px_24px_rgba(0,0,0,0.7)]">
        <div className="mx-auto flex h-20 max-w-[520px] items-center justify-around px-2">
          {navItems.map((n) => (
            <button
              key={n.id}
              onClick={() => setTab(n.id)}
              className={cn(
                "flex h-14 min-w-[74px] flex-col items-center justify-center gap-1 rounded-xl text-mute transition active:scale-95",
                tab === n.id && "bg-high/60 text-cyan-dim shadow-[0_0_16px_rgba(0,242,254,0.18)]",
              )}
            >
              {n.icon}
              <span className="text-[10.5px] font-medium">{n.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
