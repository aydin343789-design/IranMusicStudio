import { expect, test, type Page } from "@playwright/test";
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const ffmpeg = process.env.FFMPEG_PATH || "ffmpeg";
let dir: string;

function encode(...args: string[]) {
  return execFileSync(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", ...args]);
}

test.beforeAll(() => {
  dir = mkdtempSync(join(tmpdir(), "soundframe-tests-"));
  for (const [name, color] of [["intro", "red"], ["outro", "blue"]]) {
    encode("-f", "lavfi", "-i", `color=${color}:s=320x180`, "-frames:v", "1", "-threads", "1", join(dir, `${name}.png`));
  }
  for (const [name, length] of [["clip", "3"], ["long", "65"]]) {
    encode("-f", "lavfi", "-i", `color=lime:s=320x180:r=30:d=${length}`,
      "-vf", "drawbox=x=0:y=0:w=40:h=40:color=white:t=fill:enable='lt(mod(t,1),0.5)'",
      "-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-threads", "1", join(dir, `${name}.mp4`));
  }
  encode("-f", "lavfi", "-i", "color=lime:s=180x320:r=30:d=3", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-threads", "1", join(dir, "portrait.mp4"));
  encode("-f", "lavfi", "-i", "sine=f=220:d=12", join(dir, "music.wav"));
});

test.afterAll(() => {
  if (dir) rmSync(dir, { recursive: true, force: true });
});

async function addClip(page: Page, name: string) {
  await page.locator('input[accept="video/*,image/*"][multiple]').setInputFiles(join(dir, name));
  await expect(clipPreview(page, name)).toBeVisible();
}

const clipPreview = (page: Page, name: string) => page.getByRole("button", { name: `پیش‌نمایش ${name}`, exact: true });
const play = (page: Page) => page.getByRole("button", { name: "پخش زنده", exact: true });
const studio = (page: Page) => page.getByRole("button", { name: "استودیو", exact: true });
const preset = (page: Page, name: string) => page.getByRole("button", { name, exact: true });

async function addMusic(page: Page) {
  await page.locator('input[accept="audio/*"]').setInputFiles(join(dir, "music.wav"));
  await expect(page.getByText("music.wav", { exact: true })).toBeVisible();
}

async function mixedProject(page: Page) {
  await page.goto("/");
  for (const name of ["intro.png", "clip.mp4", "outro.png"]) await addClip(page, name);
  await addMusic(page);
  await studio(page).click();
  await preset(page, "افقی ۱۶:۹").click();
  await page.getByRole("button", { name: "ابتدا", exact: true }).click();
}

async function previewColor(page: Page, x = 0.5, y = 0.125) {
  return page.locator("canvas").evaluate((source: HTMLCanvasElement, point) => {
    const sample = document.createElement("canvas");
    sample.width = sample.height = 1;
    const ctx = sample.getContext("2d")!;
    ctx.drawImage(source, Math.floor(source.width * point.x), Math.floor(source.height * point.y), 1, 1, 0, 0, 1, 1);
    const pixel = ctx.getImageData(0, 0, 1, 1).data;
    return Array.from(pixel.slice(0, 3));
  }, { x, y });
}

function dominant(pixel: number[]) {
  const i = pixel.findIndex((value, index) => value > 110 && pixel.every((other, channel) => index === channel || other < 75));
  return ["red", "green", "blue"][i] ?? "none";
}

async function stallVideo(page: Page, acrossDecoders = false) {
  await page.waitForFunction(() => {
    const video = document.querySelector("video");
    return video && !video.paused && video.currentTime > 0.14;
  }, undefined, { timeout: 8000 });
  await page.locator("video").evaluate((clip, all) => {
    Object.defineProperty(all ? HTMLVideoElement.prototype : clip, "readyState", { configurable: true, get: () => HTMLMediaElement.HAVE_METADATA });
  }, acrossDecoders);
}

async function resumeVideo(page: Page) {
  await page.locator("video").evaluate((clip) => { Reflect.deleteProperty(clip, "readyState"); });
}

test("previews and exports photo, motion clip, photo with audio", async ({ page }, testInfo) => {
  await mixedProject(page);
  await expect.poll(async () => dominant(await previewColor(page))).toBe("red");
  await play(page).click();
  await expect.poll(async () => dominant(await previewColor(page)), { timeout: 6500 }).toBe("green");
  await expect.poll(async () => dominant(await previewColor(page)), { timeout: 4500 }).toBe("blue");

  await page.getByRole("button", { name: "خروجی", exact: true }).click();
  await page.getByRole("button", { name: /شروع رندر/ }).click();
  await stallVideo(page);
  await expect(page.getByText("در انتظار فریم بعدی", { exact: true })).toBeVisible();
  await expect(page.locator("audio")).toHaveJSProperty("paused", true);
  expect(dominant(await previewColor(page))).toBe("green");
  await resumeVideo(page);
  const link = page.getByRole("link", { name: /دانلود فایل/ });
  await expect(link).toBeVisible({ timeout: 18000 });
  const output = page.locator("video[controls]");
  await output.evaluate((video: HTMLVideoElement) => { video.preload = "metadata"; video.load(); });
  await expect(output).toHaveJSProperty("videoWidth", 1280);
  await expect(output).toHaveJSProperty("videoHeight", 720);
  const downloading = page.waitForEvent("download");
  await link.click();
  const download = await downloading;
  expect(download.suggestedFilename()).toMatch(/^pahlavi-studio-/);
  const file = testInfo.outputPath(download.suggestedFilename());
  await download.saveAs(file);

  const sample = (seconds: string, crop = "2:2:iw/2:ih/8") => encode("-i", file, "-ss", seconds,
    "-frames:v", "1", "-vf", `crop=${crop},scale=1:1`, "-pix_fmt", "rgb24", "-f", "rawvideo", "pipe:1");
  for (const [time, color] of [["0.1", "red"], ["4.5", "green"], ["6.3", "green"], ["8.4", "blue"]]) {
    expect(dominant([...sample(time)]), `background at ${time}s`).toBe(color);
  }
  expect([...sample("4.65", "2:2:iw/16:ih/10")]).not.toEqual([...sample("5.25", "2:2:iw/16:ih/10")]);
  const audio = encode("-i", file, "-ss", "4.5", "-t", "0.2", "-vn", "-ac", "1", "-f", "s16le", "pipe:1");
  expect(audio.some((byte) => byte !== 0)).toBe(true);
});

test("retains the video frame during a temporary decoder stall", async ({ page }) => {
  await mixedProject(page);
  await play(page).click();
  await stallVideo(page);
  await expect(page.getByText("در حال آماده‌سازی پخش", { exact: true })).toBeVisible();
  expect(dominant(await previewColor(page))).toBe("green");
  await resumeVideo(page);
  await expect.poll(async () => dominant(await previewColor(page)), { timeout: 4500 }).toBe("blue");
});

test("does not offer a broken export if the video never recovers", async ({ page }) => {
  await mixedProject(page);
  await page.getByRole("button", { name: "خروجی", exact: true }).click();
  await page.getByRole("button", { name: /شروع رندر/ }).click();
  await stallVideo(page, true);
  await expect(page.getByRole("alert")).toContainText("clip.mp4", { timeout: 12000 });
  await expect(page.getByRole("link", { name: /دانلود فایل/ })).toHaveCount(0);
  await expect(page.getByRole("button", { name: /شروع رندر/ })).toBeEnabled();
});

test("continues past the opening seconds of a long MP4", async ({ page }) => {
  await page.goto("/");
  await addClip(page, "long.mp4");
  await play(page).click();
  await page.waitForFunction(() => Array.from(document.querySelectorAll("video")).some((video) => video.currentTime > 3.5), { }, { timeout: 9500 });
  expect(dominant(await previewColor(page, 0.5, 0.375))).toBe("green");
});

test("only Studio templates change the project frame", async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem("soundframe.studio.v1", JSON.stringify({ project: { aspect: "auto" } })));
  await page.goto("/");
  const stage = page.getByRole("group", { name: "قاب پیش‌نمایش" });
  const frame = page.locator("canvas");
  await expect(frame).toHaveJSProperty("width", 360);
  await expect(frame).toHaveJSProperty("height", 640);
  const initial = (await stage.boundingBox())!;
  expect(initial.width / initial.height).toBeCloseTo(9 / 16, 2);

  await addClip(page, "intro.png");
  await expect.poll(async () => dominant(await previewColor(page, 0.5, 0.375))).toBe("red");
  expect(dominant(await previewColor(page))).toBe("none");
  await addClip(page, "portrait.mp4");
  await expect.poll(async () => dominant(await previewColor(page))).toBe("green");
  const afterImport = (await stage.boundingBox())!;
  expect(afterImport.width).toBe(initial.width);
  expect(afterImport.height).toBe(initial.height);
  await expect(frame).toHaveJSProperty("width", 360);
  await expect(frame).toHaveJSProperty("height", 640);

  await clipPreview(page, "intro.png").click();
  await expect.poll(async () => dominant(await previewColor(page, 0.5, 0.375))).toBe("red");
  await page.getByRole("button", { name: "تغییر قالب در استودیو" }).click();
  await expect(page.getByRole("group", { name: "قالب تصویر" })).toBeVisible();
  await preset(page, "مربعی ۱:۱").click();
  await expect(frame).toHaveJSProperty("width", 640);
  await expect(frame).toHaveJSProperty("height", 640);
  let box = (await stage.boundingBox())!;
  expect(box.width / box.height).toBeCloseTo(1, 2);
  await preset(page, "پر کردن قاب").click();
  await expect.poll(async () => dominant(await previewColor(page))).toBe("red");
  await preset(page, "نمایش کامل").click();
  await expect.poll(async () => dominant(await previewColor(page))).toBe("none");
  await preset(page, "پست ۴:۵").click();
  await expect(frame).toHaveJSProperty("width", 512);
  box = (await stage.boundingBox())!;
  expect(box.width / box.height).toBeCloseTo(4 / 5, 2);
});

test("inline video replacement, deletion and undo preserve timeline order", async ({ page }) => {
  await page.goto("/");
  for (const name of ["intro.png", "clip.mp4", "outro.png"]) await addClip(page, name);
  const clips = page.getByRole("list", { name: "فهرست رسانه‌های پروژه" });
  const order = () => clips.getByRole("listitem").locator("bdi").allTextContents();
  const replace = async (file: Parameters<import("@playwright/test").FileChooser["setFiles"]>[0]) => {
    const chooser = page.waitForEvent("filechooser");
    await page.getByRole("button", { name: "تعویض clip.mp4", exact: true }).click();
    await (await chooser).setFiles(file);
  };
  await replace({ name: "wrong.mp4", mimeType: "video/mp4", buffer: Buffer.from("not a video") });
  await expect(page.getByRole("status").filter({ hasText: "باقی ماند" })).toBeVisible();
  expect(await order()).toEqual(["intro.png", "clip.mp4", "outro.png"]);
  await replace(join(dir, "portrait.mp4"));
  await expect(clipPreview(page, "portrait.mp4")).toHaveAttribute("aria-pressed", "true");
  expect(await order()).toEqual(["intro.png", "portrait.mp4", "outro.png"]);
  await expect.poll(async () => dominant(await previewColor(page))).toBe("green");

  await page.getByRole("button", { name: "حذف portrait.mp4", exact: true }).click();
  await expect(clipPreview(page, "outro.png")).toHaveAttribute("aria-pressed", "true");
  expect(await order()).toEqual(["intro.png", "outro.png"]);
  await expect.poll(async () => dominant(await previewColor(page, 0.5, 0.375))).toBe("blue");
  await page.getByRole("button", { name: "بازگردانی", exact: true }).click();
  await expect(clipPreview(page, "portrait.mp4")).toHaveAttribute("aria-pressed", "true");
  expect(await order()).toEqual(["intro.png", "portrait.mp4", "outro.png"]);
  await expect.poll(async () => dominant(await previewColor(page))).toBe("green");
});

test("shows the selected video poster until a fresh frame is available", async ({ page }) => {
  await page.goto("/");
  await addClip(page, "intro.png");
  await addClip(page, "portrait.mp4");
  await clipPreview(page, "intro.png").click();
  await expect.poll(async () => dominant(await previewColor(page, 0.5, 0.375))).toBe("red");
  await page.locator("video").evaluate((clip) => {
    Object.defineProperty(clip, "readyState", { configurable: true, get: () => HTMLMediaElement.HAVE_METADATA });
  });
  await clipPreview(page, "portrait.mp4").click();
  await expect(page.getByText("در حال آماده‌سازی فریم", { exact: true })).toBeVisible();
  await expect.poll(async () => dominant(await previewColor(page))).toBe("green");
  await resumeVideo(page);
  await expect(page.getByText("در حال آماده‌سازی فریم", { exact: true })).toHaveCount(0);
});

test("keeps transport and inline delete within a narrow mobile screen", async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 640 });
  await page.goto("/");
  await addClip(page, "portrait.mp4");
  for (const name of ["۵ ثانیه به جلو", "۵ ثانیه به عقب", "حذف portrait.mp4"]) {
    const box = (await page.getByRole("button", { name, exact: true }).boundingBox())!;
    expect(box.x).toBeGreaterThanOrEqual(0);
    expect(box.x + box.width).toBeLessThanOrEqual(320);
  }
});

test("starts video with music when the decoder waits for a play request", async ({ page }) => {
  await page.goto("/");
  await addClip(page, "long.mp4");
  await addMusic(page);
  await page.locator("video").evaluate((video) => {
    const el = video as HTMLVideoElement;
    const readyState = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, "readyState")!.get!;
    const play = el.play.bind(el);
    let requested = false;
    Object.defineProperty(el, "readyState", { configurable: true, get: () => Math.min(readyState.call(el), requested ? 2 : 1) });
    el.play = () => {
      requested = true;
      return play();
    };
  });
  await play(page).click();
  await page.waitForFunction(() => {
    const video = document.querySelector("video");
    const audio = document.querySelector("audio");
    return video && audio && !video.paused && !audio.paused && video.currentTime > 0.6 && audio.currentTime > 0.45;
  }, undefined, { timeout: 4500 });
});

async function expectAV(page: Page, minTime = 0.3) {
  await page.waitForFunction((time) => {
    const video = document.querySelector("video");
    const audio = document.querySelector("audio");
    return video && audio && !video.paused && !audio.paused && video.currentTime > time
      && Math.abs((video.currentTime % 12) - (audio.currentTime % 12)) < 0.6;
  }, minTime, { timeout: 8000 });
}

test("recreates a stuck video decoder and resumes the mix at the playhead", async ({ page }) => {
  await page.goto("/");
  await addClip(page, "long.mp4");
  await addMusic(page);
  await play(page).click();
  await expectAV(page, 1.2);
  const stoppedAt = await page.locator("video").evaluate((el: HTMLVideoElement) => {
    el.dataset.stuck = "true";
    Object.defineProperty(el, "readyState", { configurable: true, get: () => HTMLMediaElement.HAVE_METADATA });
    return el.currentTime;
  });
  await expect(page.locator('video[data-stuck="true"]')).toHaveCount(0, { timeout: 6000 });
  await expectAV(page, stoppedAt + 0.22);
  await expect(page.locator("video")).toHaveCount(1);
  await expect(page.getByRole("alert")).toHaveCount(0);
  await expect(page.getByText("music.wav", { exact: true })).toBeVisible();
});

async function refuseVideo(page: Page, enabled: boolean) {
  await page.evaluate((shouldRefuse) => {
    if (shouldRefuse) Object.defineProperty(HTMLVideoElement.prototype, "play", {
      configurable: true,
      value: () => Promise.reject(new DOMException("Decoder unavailable", "NotSupportedError")),
    });
    else Reflect.deleteProperty(HTMLVideoElement.prototype, "play");
  }, enabled);
}

test("retries a terminal playback error without losing the project", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveTitle(/استودیو پهلوی/);
  await expect(page.getByRole("heading", { name: "استودیو پهلوی" })).toBeVisible();
  await addClip(page, "long.mp4");
  await addMusic(page);
  await refuseVideo(page, true);
  await play(page).click();
  await expect(page.getByRole("alert")).toContainText("long.mp4");
  const retry = page.getByRole("button", { name: "تلاش دوباره", exact: true });
  await expect(retry).toBeEnabled();
  // A second unsuccessful attempt must also leave the controls usable.
  await retry.click();
  await expect(page.getByRole("alert")).toContainText("long.mp4");
  await refuseVideo(page, false);
  await retry.click();
  await expectAV(page);
  await expect(page.getByRole("alert")).toHaveCount(0);
  await expect(clipPreview(page, "long.mp4")).toBeVisible();
});

test("replaces the failed clip from its error and continues playing", async ({ page }) => {
  await page.goto("/");
  await addClip(page, "long.mp4");
  await addMusic(page);
  await refuseVideo(page, true);
  await play(page).click();
  await expect(page.getByRole("alert")).toContainText("long.mp4");
  await refuseVideo(page, false);
  const picker = page.waitForEvent("filechooser");
  await page.getByRole("button", { name: "تعویض فایل", exact: true }).click();
  await (await picker).setFiles(join(dir, "portrait.mp4"));
  await expect(clipPreview(page, "portrait.mp4")).toBeVisible();
  await expect(clipPreview(page, "long.mp4")).toHaveCount(0);
  await expectAV(page);
  await expect(page.getByRole("alert")).toHaveCount(0);
});

test("recreates a music element after an unexpected play rejection", async ({ page }) => {
  await page.goto("/");
  await addClip(page, "long.mp4");
  await addMusic(page);
  await page.locator("audio").evaluate((el: HTMLAudioElement) => {
    el.dataset.stuck = "true";
    el.play = () => Promise.reject(new DOMException("Audio clock interrupted", "AbortError"));
  });
  await play(page).click();
  await expect(page.locator('audio[data-stuck="true"]')).toHaveCount(0);
  await expectAV(page);
  await expect(page.getByRole("alert")).toHaveCount(0);
});
test("keeps playing across clip changes, EQ edits and file replacement", async ({ page }) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(String(error)));
  await mixedProject(page);
  await play(page).click();
  await expect.poll(async () => dominant(await previewColor(page)), { timeout: 7000 }).toBe("green");

  await page.getByRole("button", { name: "اکولایزر", exact: true }).click();
  await page.getByRole("button", { name: "گل", exact: true }).click();
  await page.getByRole("button", { name: "رنگین‌کمان", exact: true }).click();
  await page.waitForTimeout(1200);
  await expect(page.getByRole("alert")).toHaveCount(0);
  await expect(page.getByRole("button", { name: "توقف", exact: true })).toBeVisible();

  const chooser = page.waitForEvent("filechooser");
  await page.getByRole("button", { name: "رسانه‌ها", exact: true }).click();
  await page.getByRole("button", { name: "تعویض clip.mp4", exact: true }).click();
  await (await chooser).setFiles(join(dir, "portrait.mp4"));
  await expect(clipPreview(page, "portrait.mp4")).toBeVisible();
  await page.getByRole("button", { name: "اکولایزر", exact: true }).click();
  await page.getByRole("button", { name: "قله‌دار", exact: true }).click();
  await play(page).click();
  await page.waitForFunction(() => {
    const video = document.querySelector("video");
    const audio = document.querySelector("audio");
    return video && audio && !video.paused && !audio.paused && video.currentTime > 0.3;
  }, undefined, { timeout: 8000 });
  await expect(page.getByRole("alert")).toHaveCount(0);
  await expect.poll(async () => dominant(await previewColor(page))).toBe("green");
  expect(errors).toEqual([]);
});
