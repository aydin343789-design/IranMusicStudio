import { useSyncExternalStore } from "react";

/**
 * A tiny external store for the playhead position.
 * Only the small components that display time subscribe to it,
 * so the whole app tree no longer re-renders 15 times per second.
 */
interface TimeState {
  time: number;
  duration: number;
}

let state: TimeState = { time: 0, duration: 0 };
const subs = new Set<() => void>();

export const timeStore = {
  set(time: number, duration: number) {
    if (Math.abs(time - state.time) < 0.01 && duration === state.duration) return;
    state = { time, duration };
    subs.forEach((f) => f());
  },
  get: () => state,
  subscribe(f: () => void) {
    subs.add(f);
    return () => {
      subs.delete(f);
    };
  },
};

export function useTime(): TimeState {
  return useSyncExternalStore(timeStore.subscribe, timeStore.get);
}
