export type VizStyle =
  | "bars"
  | "mirror"
  | "led"
  | "circle"
  | "ringwave"
  | "wave"
  | "area"
  | "dots"
  | "rings"
  | "flower"
  | "peaks"
  | "particles"
  | "ribbon";

export interface VizBox {
  cx: number;
  cy: number;
  w: number;
  h: number;
}

export interface VizSettings {
  style: VizStyle;
  palette: string;
  colorA: string;
  colorB: string;
  count: number;
  sensitivity: number;
  smoothing: number;
  glow: number;
  thickness: number;
  opacity: number;
  rangeStart: number;
  rangeEnd: number;
  beatZoom: boolean;
  beatFlash: boolean;
  dim: number;
  syncMs: number;
  kenBurns: boolean;
  colorCycle: boolean;
  title: string;
  titlePos: "top" | "center" | "bottom";
  titleSize: number;
  box: VizBox;
}

export const STYLE_LIST: { id: VizStyle; label: string }[] = [
  { id: "bars", label: "میله‌ای" },
  { id: "mirror", label: "آینه‌ای" },
  { id: "led", label: "LED" },
  { id: "circle", label: "دایره‌ای" },
  { id: "ringwave", label: "حلقه موج" },
  { id: "wave", label: "موج" },
  { id: "area", label: "کوهستانی" },
  { id: "dots", label: "نقطه‌ای" },
  { id: "rings", label: "حلقه‌های پالس" },
  { id: "flower", label: "گل" },
  { id: "peaks", label: "قله‌دار" },
  { id: "particles", label: "ذرات" },
  { id: "ribbon", label: "روبان" },
];

export const PALETTES: Record<string, { name: string; stops: string[] }> = {
  neon: { name: "نئون", stops: ["#00f2fe", "#7c4dff", "#ff4fd8"] },
  sunset: { name: "غروب", stops: ["#ff512f", "#f09819", "#ffe259"] },
  aurora: { name: "شفق", stops: ["#00f5a0", "#00d9f5", "#a18cd1"] },
  fire: { name: "آتش", stops: ["#ff0844", "#ff6a00", "#ffd200"] },
  ice: { name: "یخ", stops: ["#ffffff", "#9be7ff", "#4facfe"] },
  rainbow: {
    name: "رنگین‌کمان",
    stops: ["#ff3b3b", "#ffd23b", "#3bff7a", "#3bd6ff", "#6a5cff", "#ff3bd6"],
  },
  mono: { name: "سفید", stops: ["#ffffff", "#e6e6e6"] },
  custom: { name: "سفارشی", stops: [] },
};

type RGB = [number, number, number];

function hexToRgb(h: string): RGB {
  const s = h.replace("#", "");
  const n = parseInt(s.length === 3 ? s.split("").map((c) => c + c).join("") : s, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export type ColorFn = ((t: number, a?: number) => string) & { shift: number };

export function makeColorFn(s: VizSettings): ColorFn {
  const stops: RGB[] = (
    s.palette === "custom" ? [s.colorA, s.colorB] : PALETTES[s.palette]?.stops ?? PALETTES.neon.stops
  ).map(hexToRgb);
  const fn = ((t: number, a = 1) => {
    let u = (t + fn.shift) % 2;
    if (u < 0) u += 2;
    const tt = u > 1 ? 2 - u : u;
    if (stops.length === 1) return `rgba(${stops[0].join(",")},${a})`;
    const p = tt * (stops.length - 1);
    const i = Math.min(stops.length - 2, Math.floor(p));
    const f = p - i;
    const c = stops[i].map((v, k) => Math.round(v + (stops[i + 1][k] - v) * f));
    return `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  }) as ColorFn;
  fn.shift = 0;
  return fn;
}

export interface DrawParams {
  g: CanvasRenderingContext2D;
  x: number;
  y: number;
  w: number;
  h: number;
  v: Float32Array;
  n: number;
  wave: Uint8Array;
  color: ColorFn;
  bass: number;
  beat: number;
  thick: number;
  sens: number;
  time: number;
  ripples: { p: number }[];
}

function rr(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rad = Math.max(0, Math.min(r, w / 2, h / 2));
  g.beginPath();
  g.moveTo(x + rad, y);
  g.arcTo(x + w, y, x + w, y + h, rad);
  g.arcTo(x + w, y + h, x, y + h, rad);
  g.arcTo(x, y + h, x, y, rad);
  g.arcTo(x, y, x + w, y, rad);
  g.closePath();
}

function hGradient(p: DrawParams, x0: number, x1: number) {
  const gr = p.g.createLinearGradient(x0, 0, x1, 0);
  for (let i = 0; i <= 6; i++) gr.addColorStop(i / 6, p.color(i / 6));
  return gr;
}

function bars(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick } = p;
  const gap = w / n;
  const bw = Math.max(1.5, gap * (0.25 + thick * 0.7));
  for (let i = 0; i < n; i++) {
    const bh = Math.max(bw, v[i] * h);
    g.fillStyle = color(i / Math.max(1, n - 1));
    rr(g, x + i * gap + (gap - bw) / 2, y + h - bh, bw, bh, bw / 2);
    g.fill();
  }
}

function mirror(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick } = p;
  const gap = w / n;
  const bw = Math.max(1.5, gap * (0.25 + thick * 0.7));
  const cy = y + h / 2;
  for (let i = 0; i < n; i++) {
    const bh = Math.max(bw, v[i] * h);
    g.fillStyle = color(i / Math.max(1, n - 1));
    rr(g, x + i * gap + (gap - bw) / 2, cy - bh / 2, bw, bh, bw / 2);
    g.fill();
  }
}

function led(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick } = p;
  const segs = 16;
  const sh = h / segs;
  const gap = w / n;
  const bw = Math.max(2, gap * (0.3 + thick * 0.6));
  // one colour string per row instead of one per cell (n × 16 string allocations per frame)
  const rowColor: string[] = [];
  for (let s = 0; s < segs; s++) rowColor.push(color(s / segs));
  // all unlit cells share a single path and a single fill call
  g.beginPath();
  for (let i = 0; i < n; i++) {
    const lit = Math.round(v[i] * segs);
    const bx = x + i * gap + (gap - bw) / 2;
    for (let s = lit; s < segs; s++) g.rect(bx, y + h - (s + 1) * sh + sh * 0.12, bw, sh * 0.76);
  }
  g.fillStyle = "rgba(255,255,255,0.06)";
  g.fill();
  for (let s = 0; s < segs; s++) {
    g.fillStyle = rowColor[s];
    g.beginPath();
    const yy = y + h - (s + 1) * sh + sh * 0.12;
    for (let i = 0; i < n; i++) {
      if (s < Math.round(v[i] * segs)) g.rect(x + i * gap + (gap - bw) / 2, yy, bw, sh * 0.76);
    }
    g.fill();
  }
}

function circle(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, bass, thick, time } = p;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const R = Math.min(w, h) / 2;
  const r0 = R * 0.42 * (1 + bass * 0.14);
  const len = R * 0.58;
  const total = n * 2;
  g.lineCap = "round";
  g.lineWidth = Math.max(1.5, ((2 * Math.PI * r0) / total) * (0.35 + thick * 0.6));
  for (let k = 0; k < total; k++) {
    const idx = k < n ? k : total - 1 - k;
    const a = (k / total) * Math.PI * 2 - Math.PI / 2 + time * 0.12;
    const l = Math.max(2, v[idx] * len);
    g.strokeStyle = color(idx / Math.max(1, n - 1));
    g.beginPath();
    g.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
    g.lineTo(cx + Math.cos(a) * (r0 + l), cy + Math.sin(a) * (r0 + l));
    g.stroke();
  }
  g.lineWidth = 2;
  g.strokeStyle = color(0.5, 0.7);
  g.beginPath();
  g.arc(cx, cy, r0 * 0.9, 0, Math.PI * 2);
  g.stroke();
  g.fillStyle = color(0.5, 0.12 + bass * 0.25);
  g.fill();
}

function ringwave(p: DrawParams) {
  const { g, x, y, w, h, wave, color, sens, bass, thick, time } = p;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const R = Math.min(w, h) / 2;
  const r0 = R * 0.55 * (1 + bass * 0.1);
  const steps = 180;
  const half = Math.floor(wave.length / 2);
  const draw = (scale: number, alpha: number, lw: number, col: number) => {
    g.beginPath();
    for (let j = 0; j <= steps; j++) {
      const m = j <= steps / 2 ? j : steps - j; // mirrored => seamless
      const si = Math.floor((m / (steps / 2)) * (half - 1));
      const d = (wave[si] - 128) / 128;
      const a = (j / steps) * Math.PI * 2 + time * 0.2;
      const r = (r0 + d * R * 0.55 * sens * 1.4) * scale;
      const px = cx + Math.cos(a) * r;
      const py = cy + Math.sin(a) * r;
      if (j === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.closePath();
    g.lineWidth = lw;
    g.strokeStyle = color(col, alpha);
    g.stroke();
  };
  draw(1.18, 0.35, 1.5, 0.85);
  draw(1, 1, 2 + thick * 3, 0.15);
  draw(0.82, 0.5, 1.5, 0.55);
}

function wave(p: DrawParams) {
  const { g, x, y, w, h, wave: wv, sens, thick } = p;
  const cy = y + h / 2;
  const grad = hGradient(p, x, x + w);
  const pts = 160;
  const draw = (flip: number, alpha: number, lw: number) => {
    g.beginPath();
    for (let j = 0; j <= pts; j++) {
      const si = Math.floor((j / pts) * (wv.length * 0.5 - 1));
      const d = (wv[si] - 128) / 128;
      const px = x + (j / pts) * w;
      const py = cy + flip * d * (h / 2) * sens * 1.6;
      if (j === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.globalAlpha *= alpha;
    g.lineWidth = lw;
    g.strokeStyle = grad;
    g.lineJoin = "round";
    g.stroke();
    g.globalAlpha /= alpha;
  };
  draw(-1, 0.35, 2);
  draw(1, 1, 2 + thick * 4);
}

function area(p: DrawParams) {
  const { g, x, y, w, h, v, n, color } = p;
  const pts: [number, number][] = [];
  for (let i = 0; i < n; i++) pts.push([x + (i / (n - 1)) * w, y + h - Math.max(0.03, v[i]) * h]);
  g.beginPath();
  g.moveTo(x, y + h);
  g.lineTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length - 1; i++) {
    const mx = (pts[i][0] + pts[i + 1][0]) / 2;
    const my = (pts[i][1] + pts[i + 1][1]) / 2;
    g.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
  }
  g.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
  g.lineTo(x + w, y + h);
  g.closePath();
  const fill = g.createLinearGradient(0, y, 0, y + h);
  fill.addColorStop(0, color(0.5, 0.75));
  fill.addColorStop(1, color(0, 0.05));
  g.fillStyle = fill;
  g.fill();
  g.lineWidth = 2.5;
  g.strokeStyle = hGradient(p, x, x + w);
  g.stroke();
}

function dots(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick } = p;
  const cols = Math.min(n, 28);
  const rows = 12;
  const cw = w / cols;
  const ch = h / rows;
  const rad = (Math.min(cw, ch) / 2) * (0.35 + thick * 0.55);
  for (let c = 0; c < cols; c++) {
    const val = v[Math.floor((c / cols) * n)];
    const lit = Math.round(val * rows);
    for (let r = 0; r < rows; r++) {
      const on = r < lit;
      g.fillStyle = on ? color(r / rows) : "rgba(255,255,255,0.07)";
      g.beginPath();
      g.arc(x + (c + 0.5) * cw, y + h - (r + 0.5) * ch, rad, 0, Math.PI * 2);
      g.fill();
    }
  }
}

function rings(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick, ripples, bass } = p;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const R = Math.min(w, h) / 2;
  const bands = 5;
  for (let j = 0; j < bands; j++) {
    const a = Math.floor((j / bands) * n);
    const b = Math.max(a + 1, Math.floor(((j + 1) / bands) * n));
    let e = 0;
    for (let i = a; i < b; i++) e += v[i];
    e /= b - a;
    const r = R * (0.2 + j * 0.15) * (1 + e * 0.18);
    g.lineWidth = 2 + e * 14 * (0.3 + thick);
    g.strokeStyle = color(j / (bands - 1), 0.45 + e * 0.55);
    g.beginPath();
    g.arc(cx, cy, r, 0, Math.PI * 2);
    g.stroke();
  }
  for (const rp of ripples) {
    g.lineWidth = 3;
    g.strokeStyle = color(0.5 + rp.p * 0.5, (1 - rp.p) * 0.8);
    g.beginPath();
    g.arc(cx, cy, R * (0.2 + rp.p * 0.8), 0, Math.PI * 2);
    g.stroke();
  }
  g.fillStyle = color(0, 0.4 + bass * 0.5);
  g.beginPath();
  g.arc(cx, cy, R * 0.1 * (1 + bass * 0.5), 0, Math.PI * 2);
  g.fill();
}

function flower(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, bass, time } = p;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const R = Math.min(w, h) / 2;
  const total = n * 2;
  const build = (r0: number, len: number, rot: number) => {
    const pts: [number, number][] = [];
    for (let k = 0; k < total; k++) {
      const idx = k < n ? k : total - 1 - k;
      const a = (k / total) * Math.PI * 2 + rot;
      const r = r0 + v[idx] * len;
      pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
    }
    g.beginPath();
    const last = pts[pts.length - 1];
    g.moveTo((last[0] + pts[0][0]) / 2, (last[1] + pts[0][1]) / 2);
    for (let i = 0; i < pts.length; i++) {
      const nx = pts[(i + 1) % pts.length];
      g.quadraticCurveTo(pts[i][0], pts[i][1], (pts[i][0] + nx[0]) / 2, (pts[i][1] + nx[1]) / 2);
    }
    g.closePath();
  };
  const r0 = R * 0.3 * (1 + bass * 0.12);
  build(r0, R * 0.7, time * 0.15);
  const rg = g.createRadialGradient(cx, cy, r0 * 0.3, cx, cy, R);
  rg.addColorStop(0, color(0, 0.55));
  rg.addColorStop(1, color(1, 0.15));
  g.fillStyle = rg;
  g.fill();
  g.lineWidth = 2.5;
  g.strokeStyle = color(0.7);
  g.stroke();
  build(r0 * 0.6, R * 0.35, -time * 0.25);
  g.lineWidth = 1.8;
  g.strokeStyle = color(0.2, 0.9);
  g.stroke();
}


/* ---- peak-hold bars with reflection ---- */
const caps = new Float32Array(128);
let capT = 0;
function peaks(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, thick, time } = p;
  const dt = Math.min(0.1, Math.max(0, time - capT));
  capT = time;
  const gap = w / n;
  const bw = Math.max(1.5, gap * (0.3 + thick * 0.65));
  const base = y + h * 0.78;
  const hh = h * 0.78;
  for (let i = 0; i < n; i++) {
    const bh = Math.max(bw, v[i] * hh);
    caps[i] = Math.max(v[i], caps[i] - dt * 0.45);
    const px = x + i * gap + (gap - bw) / 2;
    const c = color(i / Math.max(1, n - 1));
    g.fillStyle = c;
    rr(g, px, base - bh, bw, bh, bw / 2);
    g.fill();
    // reflection
    const rh = bh * 0.45;
    const gr = g.createLinearGradient(0, base + 2, 0, base + 2 + rh);
    gr.addColorStop(0, color(i / Math.max(1, n - 1), 0.35));
    gr.addColorStop(1, color(i / Math.max(1, n - 1), 0));
    g.fillStyle = gr;
    g.fillRect(px, base + 2, bw, rh);
    // cap
    g.fillStyle = "rgba(255,255,255,0.95)";
    rr(g, px, base - Math.max(bw, caps[i] * hh) - bw * 1.2, bw, Math.max(2, bw * 0.55), 1.5);
    g.fill();
  }
}

/* ---- beat particles ---- */
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  c: number;
  r: number;
}
let parts: Particle[] = [];
let partT = 0;
let prevBeat = 0;
function particles(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, bass, beat, time } = p;
  const dt = Math.min(0.08, Math.max(0, time - partT));
  partT = time;
  const cx = x + w / 2;
  const cy = y + h / 2;
  const R = Math.min(w, h) / 2;
  if (dt > 0) {
    if (beat > 0.95 && prevBeat <= 0.95) {
      const k = 18 + Math.round(bass * 24);
      for (let i = 0; i < k; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = R * (0.8 + Math.random() * 1.6);
        parts.push({ x: cx, y: cy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1, c: Math.random(), r: 1.5 + Math.random() * 3.5 });
      }
    }
    if (Math.random() < bass * 0.8) {
      const i = Math.floor(Math.random() * n);
      if (v[i] > 0.55) {
        const a = Math.random() * Math.PI * 2;
        parts.push({ x: cx + Math.cos(a) * R * 0.3, y: cy + Math.sin(a) * R * 0.3, vx: Math.cos(a) * R * 0.5, vy: Math.sin(a) * R * 0.5 - R * 0.2, life: 0.9, c: i / n, r: 1 + Math.random() * 2.5 });
      }
    }
    prevBeat = beat;
    for (const q of parts) {
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      q.vx *= 1 - dt * 1.2;
      q.vy *= 1 - dt * 1.2;
      q.life -= dt * 0.6;
    }
    parts = parts.filter((q) => q.life > 0).slice(-220);
  }
  // ring of dots reacting to the spectrum
  const total = n * 2;
  for (let k = 0; k < total; k++) {
    const idx = k < n ? k : total - 1 - k;
    const a = (k / total) * Math.PI * 2 - Math.PI / 2 + time * 0.1;
    const r = R * 0.34 * (1 + bass * 0.12) + v[idx] * R * 0.28;
    g.fillStyle = color(idx / Math.max(1, n - 1), 0.9);
    g.beginPath();
    g.arc(cx + Math.cos(a) * r, cy + Math.sin(a) * r, 1.6 + v[idx] * 3.2, 0, Math.PI * 2);
    g.fill();
  }
  // core orb
  const orb = R * 0.2 * (1 + bass * 0.7);
  const rg = g.createRadialGradient(cx, cy, 0, cx, cy, orb * 1.6);
  rg.addColorStop(0, color(0.1, 0.95));
  rg.addColorStop(0.5, color(0.6, 0.45));
  rg.addColorStop(1, color(1, 0));
  g.fillStyle = rg;
  g.beginPath();
  g.arc(cx, cy, orb * 1.6, 0, Math.PI * 2);
  g.fill();
  for (const q of parts) {
    g.fillStyle = color(q.c, Math.max(0, q.life));
    g.beginPath();
    g.arc(q.x, q.y, q.r * (0.5 + q.life * 0.7), 0, Math.PI * 2);
    g.fill();
  }
}

/* ---- aurora ribbons ---- */
function ribbon(p: DrawParams) {
  const { g, x, y, w, h, v, n, color, time, bass } = p;
  const cy = y + h / 2;
  const layers = 4;
  const seg = Math.max(1, Math.floor(n / layers));
  for (let L = 0; L < layers; L++) {
    let e = 0;
    for (let i = L * seg; i < Math.min(n, (L + 1) * seg); i++) e += v[i];
    e /= seg;
    const amp = (h / 2) * (0.18 + e * 0.8);
    const f = 1.6 + L * 0.7;
    const ph = time * (0.7 + L * 0.35) + L * 1.7;
    const pts = 70;
    g.beginPath();
    for (let j = 0; j <= pts; j++) {
      const t = j / pts;
      const env = Math.sin(t * Math.PI);
      const yy = cy + Math.sin(t * Math.PI * 2 * f + ph) * amp * env + Math.sin(t * 9 + ph * 1.7) * amp * 0.18 * env;
      if (j === 0) g.moveTo(x, yy);
      else g.lineTo(x + t * w, yy);
    }
    g.lineWidth = 2 + e * 5 + bass * 2;
    g.strokeStyle = color(L / (layers - 1), 0.9);
    g.stroke();
    g.lineTo(x + w, cy);
    g.lineTo(x, cy);
    g.closePath();
    g.fillStyle = color(L / (layers - 1), 0.1 + e * 0.12);
    g.fill();
  }
}

export const DRAWERS: Record<VizStyle, (p: DrawParams) => void> = {
  bars,
  mirror,
  led,
  circle,
  ringwave,
  wave,
  area,
  dots,
  rings,
  flower,
  peaks,
  particles,
  ribbon,
};

export const DEFAULT_VIZ: VizSettings = {
  style: "bars",
  palette: "neon",
  colorA: "#00f2fe",
  colorB: "#ff4fd8",
  count: 48,
  sensitivity: 1.1,
  smoothing: 0.7,
  glow: 14,
  thickness: 0.65,
  opacity: 1,
  rangeStart: 0,
  rangeEnd: 1,
  beatZoom: true,
  beatFlash: false,
  dim: 0.25,
  syncMs: 60,
  kenBurns: true,
  colorCycle: false,
  title: "",
  titlePos: "top",
  titleSize: 1,
  box: { cx: 0.5, cy: 0.5, w: 0.8, h: 0.3 },
};

export interface Preset {
  id: string;
  name: string;
  desc: string;
  patch: Partial<VizSettings>;
}

export const PRESETS: Preset[] = [
  {
    id: "club",
    name: "کلاب نئونی",
    desc: "میله‌ای · نئون",
    patch: { style: "bars", palette: "neon", count: 48, glow: 20, thickness: 0.65, sensitivity: 1.15, beatZoom: true, beatFlash: false, box: { cx: 0.5, cy: 0.78, w: 0.88, h: 0.26 } },
  },
  {
    id: "vinyl",
    name: "دایره شفقی",
    desc: "دایره · شفق",
    patch: { style: "circle", palette: "aurora", count: 56, glow: 18, thickness: 0.6, sensitivity: 1.1, beatZoom: true, box: { cx: 0.5, cy: 0.5, w: 0.7, h: 0.4 } },
  },
  {
    id: "sunset",
    name: "غروب سینمایی",
    desc: "کوهستانی · غروب",
    patch: { style: "area", palette: "sunset", count: 64, glow: 12, sensitivity: 1.0, beatZoom: false, dim: 0.3, box: { cx: 0.5, cy: 0.82, w: 1, h: 0.3 } },
  },
  {
    id: "lofi",
    name: "لوفای مینیمال",
    desc: "نقطه‌ای · سفید",
    patch: { style: "dots", palette: "mono", count: 28, glow: 6, thickness: 0.7, sensitivity: 1.0, beatZoom: false, dim: 0.35, box: { cx: 0.5, cy: 0.8, w: 0.7, h: 0.22 } },
  },
  {
    id: "fire",
    name: "راک آتشین",
    desc: "حلقه‌های پالس · آتش",
    patch: { style: "rings", palette: "fire", count: 40, glow: 24, thickness: 0.8, sensitivity: 1.3, beatZoom: true, beatFlash: true, box: { cx: 0.5, cy: 0.5, w: 0.75, h: 0.42 } },
  },
  {
    id: "wave",
    name: "موج یخی",
    desc: "موج · یخ",
    patch: { style: "wave", palette: "ice", count: 48, glow: 16, thickness: 0.5, sensitivity: 1.2, beatZoom: true, box: { cx: 0.5, cy: 0.5, w: 0.95, h: 0.22 } },
  },
  {
    id: "spark",
    name: "جرقه‌های رقصان",
    desc: "ذرات · رنگین‌کمان",
    patch: { style: "particles", palette: "rainbow", count: 40, glow: 20, sensitivity: 1.2, beatZoom: true, colorCycle: true, box: { cx: 0.5, cy: 0.5, w: 0.9, h: 0.5 } },
  },
  {
    id: "aurora",
    name: "شفق قطبی",
    desc: "روبان · شفق",
    patch: { style: "ribbon", palette: "aurora", count: 48, glow: 22, sensitivity: 1.1, beatZoom: false, colorCycle: true, box: { cx: 0.5, cy: 0.62, w: 1, h: 0.4 } },
  },
  {
    id: "studio",
    name: "استودیو حرفه‌ای",
    desc: "قله‌دار · نئون",
    patch: { style: "peaks", palette: "neon", count: 40, glow: 14, thickness: 0.6, sensitivity: 1.15, beatZoom: true, box: { cx: 0.5, cy: 0.74, w: 0.9, h: 0.36 } },
  },
];

/**
 * Fields every preset is allowed to change. A preset is applied on top of these defaults,
 * so choosing "fire" after "spark" no longer inherits colour-cycling, dimming or thickness
 * from the previous preset. User-specific fields (range, sync delay, title, Ken Burns,
 * smoothing, opacity, custom colours) are deliberately not part of it.
 */
export const PRESET_BASE: Partial<VizSettings> = {
  count: DEFAULT_VIZ.count,
  sensitivity: DEFAULT_VIZ.sensitivity,
  glow: DEFAULT_VIZ.glow,
  thickness: DEFAULT_VIZ.thickness,
  beatZoom: DEFAULT_VIZ.beatZoom,
  beatFlash: DEFAULT_VIZ.beatFlash,
  dim: DEFAULT_VIZ.dim,
  colorCycle: DEFAULT_VIZ.colorCycle,
};

export function presetPatch(pr: Preset): Partial<VizSettings> {
  return { ...PRESET_BASE, ...pr.patch };
}

const num = (v: unknown, fallback: number, min: number, max: number) =>
  typeof v === "number" && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : fallback;
const bool = (v: unknown, fallback: boolean) => (typeof v === "boolean" ? v : fallback);
const hex = (v: unknown, fallback: string) => (typeof v === "string" && /^#[0-9a-f]{6}$/i.test(v) ? v : fallback);

/** Merge untrusted (stored) settings into defaults; every field is validated and clamped. */
export function sanitizeViz(raw: unknown): VizSettings {
  const d = DEFAULT_VIZ;
  const j = (raw && typeof raw === "object" ? raw : {}) as Partial<Record<keyof VizSettings, unknown>>;
  const b = (j.box && typeof j.box === "object" ? j.box : {}) as Partial<Record<keyof VizBox, unknown>>;
  const style = typeof j.style === "string" && Object.prototype.hasOwnProperty.call(DRAWERS, j.style) ? (j.style as VizStyle) : d.style;
  const palette = typeof j.palette === "string" && Object.prototype.hasOwnProperty.call(PALETTES, j.palette) ? j.palette : d.palette;
  const rangeStart = num(j.rangeStart, d.rangeStart, 0, 0.95);
  const rangeEnd = Math.max(num(j.rangeEnd, d.rangeEnd, 0.05, 1), rangeStart + 0.03);
  return {
    style,
    palette,
    colorA: hex(j.colorA, d.colorA),
    colorB: hex(j.colorB, d.colorB),
    count: Math.round(num(j.count, d.count, 12, 96)),
    sensitivity: num(j.sensitivity, d.sensitivity, 0.4, 2.2),
    smoothing: num(j.smoothing, d.smoothing, 0, 1),
    glow: num(j.glow, d.glow, 0, 40),
    thickness: num(j.thickness, d.thickness, 0.1, 1),
    opacity: num(j.opacity, d.opacity, 0.1, 1),
    rangeStart,
    rangeEnd: Math.min(1, rangeEnd),
    beatZoom: bool(j.beatZoom, d.beatZoom),
    beatFlash: bool(j.beatFlash, d.beatFlash),
    dim: num(j.dim, d.dim, 0, 0.8),
    syncMs: num(j.syncMs, d.syncMs, 0, 400),
    kenBurns: bool(j.kenBurns, d.kenBurns),
    colorCycle: bool(j.colorCycle, d.colorCycle),
    title: typeof j.title === "string" ? j.title.slice(0, 80) : d.title,
    titlePos: j.titlePos === "center" || j.titlePos === "bottom" ? j.titlePos : "top",
    titleSize: num(j.titleSize, d.titleSize, 0.3, 3),
    box: {
      cx: num(b.cx, d.box.cx, 0, 1),
      cy: num(b.cy, d.box.cy, 0, 1),
      w: num(b.w, d.box.w, 0.1, 1.4),
      h: num(b.h, d.box.h, 0.06, 1.4),
    },
  };
}
