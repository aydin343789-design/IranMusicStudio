import { Capacitor } from "@capacitor/core";
import { Directory, Filesystem } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import { EXPORT_FOLDER } from "./brand";

export const isNative = Capacitor.isNativePlatform();

function blobToBase64(b: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const s = String(r.result);
      resolve(s.slice(s.indexOf(",") + 1));
    };
    r.onerror = () => reject(r.error);
    r.readAsDataURL(b);
  });
}

/**
 * Streams recorder chunks straight to a file on the device,
 * so a long render never has to keep the whole video in RAM.
 */
export class FileSink {
  private chain: Promise<void> = Promise.resolve();
  private started = false;
  private queued = 0;
  error: unknown = null;
  bytes = 0;

  constructor(public path: string) {}

  push(blob: Blob) {
    if (this.error || this.queued + blob.size > 12 * 1024 * 1024) return false;
    this.bytes += blob.size;
    this.queued += blob.size;
    this.chain = this.chain
      .then(async () => {
        if (this.error) return;
        const data = await blobToBase64(blob);
        if (!this.started) {
          this.started = true;
          await Filesystem.writeFile({ path: this.path, data, directory: Directory.Cache, recursive: true });
        } else {
          await Filesystem.appendFile({ path: this.path, data, directory: Directory.Cache });
        }
      })
      .catch((e) => {
        this.error = e;
      })
      .finally(() => {
        this.queued -= blob.size;
      });
    return true;
  }

  async finish(): Promise<{ uri: string; src: string }> {
    await this.chain;
    if (this.error) throw this.error;
    const { uri } = await Filesystem.getUri({ path: this.path, directory: Directory.Cache });
    return { uri, src: Capacitor.convertFileSrc(uri) };
  }

  async remove() {
    try {
      await this.chain;
      await Filesystem.deleteFile({ path: this.path, directory: Directory.Cache });
    } catch {
      /* ignore */
    }
  }
}

/** Try to copy the finished video into a public folder. Returns a human readable location or "". */
export async function saveToPublicFolder(cachePath: string, fileName: string): Promise<string> {
  try {
    try {
      await Filesystem.requestPermissions();
    } catch {
      /* not needed on new Android */
    }
    try {
      await Filesystem.mkdir({ path: EXPORT_FOLDER, directory: Directory.Documents, recursive: true });
    } catch {
      /* exists */
    }
    await Filesystem.copy({
      from: cachePath,
      directory: Directory.Cache,
      to: `${EXPORT_FOLDER}/${fileName}`,
      toDirectory: Directory.Documents,
    });
    return `Documents/${EXPORT_FOLDER}/${fileName}`;
  } catch {
    return "";
  }
}

export async function shareFile(uri: string, title: string) {
  try {
    await Share.share({ title, url: uri, dialogTitle: "ذخیره یا اشتراک‌گذاری ویدئو" });
  } catch {
    /* user cancelled */
  }
}
