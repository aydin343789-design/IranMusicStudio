import { DEFAULT_ASPECT, type Aspect, type MediaFit } from "./framing";
import type { AudioAnalysis } from "./engine";

export interface Project {
  aspect: Aspect;
  fit: MediaFit;
  musicVol: number;
  videoVol: number;
  videoMuted: boolean;
  loop: boolean;
  offset: number;
  locked: boolean;
  showBeats: boolean;
  muteWhileExport: boolean;
  bitrate: number;
  exportLong: number;
  transition: boolean;
}

export interface Media {
  audioName: string;
  audioDur: number;
  analysis: AudioAnalysis | null;
}

export type Tab = "media" | "studio" | "eq" | "export";

export interface ExportState {
  status: "idle" | "recording" | "done" | "error";
  phase?: "preparing" | "running" | "waiting" | "saving";
  progress: number;
  url?: string;
  ext?: string;
  size?: number;
  message?: string;
  uri?: string;
  savedTo?: string;
}

export const DEFAULT_PROJECT: Project = {
  aspect: DEFAULT_ASPECT,
  fit: "fit",
  musicVol: 0.9,
  videoVol: 0.8,
  videoMuted: true,
  loop: true,
  offset: 0,
  locked: false,
  showBeats: true,
  muteWhileExport: false,
  bitrate: 6,
  exportLong: 1280,
  transition: true,
};

export const EMPTY_MEDIA: Media = {
  audioName: "",
  audioDur: 0,
  analysis: null,
};
