const FA = "۰۱۲۳۴۵۶۷۸۹";

export function fa(v: string | number): string {
  return String(v).replace(/\d/g, (d) => FA[+d]);
}

export function fmtTime(sec: number, frames = false): string {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  let out = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  if (frames) out += `.${String(Math.floor((sec % 1) * 100)).padStart(2, "0")}`;
  return fa(out);
}
