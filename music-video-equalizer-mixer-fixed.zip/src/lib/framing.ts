export const FRAME_PRESETS = {
  "9:16": [9, 16],
  "16:9": [16, 9],
  "1:1": [1, 1],
  "4:5": [4, 5],
} as const;

export type Aspect = keyof typeof FRAME_PRESETS;
export type MediaFit = "fit" | "fill";
export const DEFAULT_ASPECT: Aspect = "9:16";
export const FRAME_MATTE = "#171e2a";

export function normalizeAspect(value: unknown): Aspect {
  return typeof value === "string" && Object.prototype.hasOwnProperty.call(FRAME_PRESETS, value)
    ? value as Aspect : DEFAULT_ASPECT;
}

export function frameRatio(aspect: Aspect) {
  const [width, height] = FRAME_PRESETS[aspect];
  return width / height;
}

export function canvasSize(aspect: Aspect, longEdge: number): [number, number] {
  const [width, height] = FRAME_PRESETS[aspect];
  const scale = longEdge / Math.max(width, height);
  const even = (value: number) => Math.max(2, Math.round(value / 2) * 2);
  return [even(width * scale), even(height * scale)];
}

export function mediaRect(width: number, height: number, sourceWidth: number, sourceHeight: number, fit: MediaFit, zoom = 1, pan = 0) {
  const scaleX = width / sourceWidth;
  const scaleY = height / sourceHeight;
  const scale = fit === "fit" ? Math.min(scaleX, scaleY) : Math.max(scaleX, scaleY) * zoom;
  const w = sourceWidth * scale;
  const h = sourceHeight * scale;
  return { w, h, x: (width - w) / 2 + (fit === "fill" ? pan * (w - width) * 0.25 : 0), y: (height - h) / 2 };
}