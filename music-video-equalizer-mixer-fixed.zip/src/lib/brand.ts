export const STUDIO_NAME = "استودیو پهلوی";
export const EXPORT_PREFIX = "pahlavi-studio";
export const EXPORT_FOLDER = "PahlaviStudio";