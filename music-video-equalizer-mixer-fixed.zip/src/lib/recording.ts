import { FileSink, isNative, saveToPublicFolder } from "./native";
import { EXPORT_PREFIX } from "./brand";
import type { ExportState } from "./types";

const WRITE_ERROR = "نوشتن خروجی روی حافظه کامل نشد. فضای خالی را بررسی کنید یا کیفیت رندر را کمتر کنید.";
const RECORD_ERROR = "ضبط تصویر کامل نشد. اندازه خروجی یا کیفیت را کمتر کنید و دوباره امتحان کنید.";

export function captureComposition(canvas: HTMLCanvasElement, audio: MediaStreamTrack, bitrate: number) {
  // Request each composed frame explicitly when the browser supports it.
  let stream = canvas.captureStream(0);
  let video = stream.getVideoTracks()[0] as CanvasCaptureMediaStreamTrack | undefined;
  if (video && typeof video.requestFrame !== "function") {
    video.stop();
    stream = canvas.captureStream(30);
    video = stream.getVideoTracks()[0] as CanvasCaptureMediaStreamTrack | undefined;
  }
  if (!video) throw new Error(RECORD_ERROR);
  stream.addTrack(audio.clone());
  const release = () => stream.getTracks().forEach((track) => track.stop());

  const formats = [
    "video/mp4;codecs=avc1.420028,mp4a.40.2",
    "video/mp4",
    "video/webm;codecs=vp8,opus",
    "video/webm;codecs=vp9,opus",
    "video/webm",
    "",
  ];
  let rec: MediaRecorder | undefined;
  for (const mimeType of formats) {
    if (mimeType && !MediaRecorder.isTypeSupported(mimeType)) continue;
    try {
      const candidate = new MediaRecorder(stream, { mimeType: mimeType || undefined, videoBitsPerSecond: bitrate * 1e6, audioBitsPerSecond: 160000 });
      candidate.start(750);
      rec = candidate;
      break;
    } catch {
      // Some Android encoders advertise a profile but cannot open it at this size.
    }
  }
  if (!rec) {
    release();
    throw new Error(RECORD_ERROR);
  }

  const recorder = rec;
  const prefix = `${EXPORT_PREFIX}-${Date.now()}`;
  const getType = () => (recorder.mimeType || "video/webm").split(";")[0];
  const chunks: Blob[] = [];
  let sink: FileSink | undefined;
  let stopped = false;
  let cancelled = false;
  let failure = "";
  let frames = 0;
  let resultFormat = "";
  let stopTimer: number | undefined;
  let failFinalize: (message: string) => void;
  const frame = () => {
    if (recorder.state !== "recording") return;
    frames++;
    video.requestFrame?.();
  };
  const stop = (reason?: string | null) => {
    cancelled ||= reason === null;
    if (reason) failure = reason;
    stopped = true;
    // Android can fail to emit stop after the encoder has already died.
    stopTimer ??= window.setTimeout(() => failFinalize(failure || "ضبط‌کننده پاسخ نداد. دوباره خروجی بگیرید."), 5000);
    try {
      if (recorder.state !== "inactive") recorder.stop();
    } catch {
      failFinalize(failure || RECORD_ERROR);
    }
  };

  const finished = new Promise<ExportState | null>((resolve, reject) => {
    let terminal = false;
    const clean = () => {
      if (terminal) return false;
      terminal = true;
      clearTimeout(stopTimer);
      recorder.onstop = recorder.onerror = recorder.ondataavailable = null;
      chunks.length = 0;
      release();
      return true;
    };
    failFinalize = (message) => {
      if (!clean()) return;
      void sink?.remove();
      if (cancelled && !failure) resolve(null);
      else reject(new Error(message));
    };
    recorder.onerror = () => stop(RECORD_ERROR);
    recorder.ondataavailable = ({ data }) => {
      if (!data.size || cancelled || failure) return;
      resultFormat ||= data.type.split(";")[0] || getType();
      if (isNative) {
        sink ??= new FileSink(`${prefix}.${resultFormat === "video/mp4" ? "mp4" : "webm"}`);
        if (!sink.push(data)) stop(WRITE_ERROR);
      } else chunks.push(data);
    };
    recorder.onstop = async () => {
      clearTimeout(stopTimer);
      stopTimer = undefined;
      release();
      try {
        if (failure) throw new Error(failure);
        if (cancelled) {
          if (clean()) {
            void sink?.remove();
            resolve(null);
          }
          return;
        }
        if (!stopped || !frames || (!sink && !chunks.length)) throw new Error(RECORD_ERROR);
        const type = resultFormat || getType();
        const ext = type === "video/mp4" ? "mp4" : "webm";
        if (sink) {
          stopTimer = window.setTimeout(() => failFinalize(WRITE_ERROR), 60000);
          const { uri, src } = await sink.finish();
          if (terminal) return;
          const savedTo = await saveToPublicFolder(sink.path, sink.path);
          if (clean()) resolve({ status: "done", progress: 1, url: src, uri, ext, size: sink.bytes, savedTo });
        } else {
          const blob = new Blob(chunks, { type });
          if (clean()) resolve({ status: "done", progress: 1, url: URL.createObjectURL(blob), ext, size: blob.size });
        }
      } catch (error) {
        failFinalize(sink && !failure ? WRITE_ERROR : error instanceof Error ? error.message : RECORD_ERROR);
      }
    };
  });

  return { recorder, frame, stop, finished };
}