import { ArrowLeft, ArrowRight, Copy, Film, ImageIcon, Loader2, Plus, Repeat2, Scissors, Trash2, Wand2, Music4 } from "lucide-react";
import type { Clip } from "../lib/engine";
import { fa, fmtTime } from "../lib/format";
import { cn } from "../utils/cn";
import { Card, Pill, SliderRow, Toggle } from "./ui";

const btn =
  "flex items-center justify-center gap-1.5 rounded-xl bg-white/[0.05] px-3 py-2 text-[12px] text-ink ring-1 ring-white/[0.06] transition hover:bg-white/10 active:scale-95 disabled:opacity-40";

const rowAction = "grid size-11 shrink-0 place-items-center rounded-lg text-mute/85 transition-colors hover:bg-white/8 hover:text-ink active:bg-white/12 disabled:opacity-40";

export function ClipList({
  clips,
  selId,
  busy,
  disabled,
  onSelect,
  onAdd,
  onReplace,
  onDelete,
}: {
  clips: Clip[];
  selId: string;
  busy: boolean;
  disabled: boolean;
  onSelect: (id: string) => void;
  onAdd: () => void;
  onReplace: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  const total = clips.reduce((a, c) => a + c.dur, 0);
  return (
    <div className="flex flex-col gap-2">
      {clips.length > 0 && (
        <ul aria-label="فهرست رسانه‌های پروژه" className="flex max-h-[344px] flex-col gap-1.5 overflow-y-auto">
          {clips.map((c, i) => (
            <li
              key={c.id}
              className={cn("flex min-w-0 items-center gap-0.5 rounded-xl border border-white/[0.07] bg-white/[0.035] p-1 transition-colors",
                selId === c.id && "border-cyan/40 bg-cyan/[0.075]")}
            >
              <button
                type="button"
                aria-label={`پیش‌نمایش ${c.name}`}
                aria-pressed={selId === c.id}
                disabled={disabled}
                onClick={() => onSelect(c.id)}
                className="flex min-w-0 flex-1 items-center gap-2 rounded-lg p-1 text-start hover:bg-white/[0.05] disabled:opacity-60"
              >
                <span className={cn("w-4 shrink-0 text-center font-mono text-[10px] text-mute", selId === c.id && "text-cyan")}>{fa(i + 1)}</span>
                <span className="grid size-10 shrink-0 place-items-center overflow-hidden rounded-md bg-high text-mute sm:size-11">
                  {c.thumb ? <img src={c.thumb} alt="" className="size-full object-cover" loading="lazy" /> : c.kind === "video" ? <Film size={16} /> : <ImageIcon size={16} />}
                </span>
                <span className="min-w-0 flex-1">
                  <bdi className="block truncate text-[12.5px] font-medium text-ink" title={c.name}>{c.name}</bdi>
                  <span className="mt-0.5 flex items-center gap-1.5 text-[10px] text-mute">
                    {c.kind === "video" ? "ویدئو" : "عکس"}
                    <span aria-hidden="true" className="size-0.5 rounded-full bg-mute/70" />
                    <span dir="ltr" className="font-mono">{fmtTime(c.dur, true)}</span>
                  </span>
                </span>
              </button>
              <div className="ms-0.5 flex shrink-0 items-center border-s border-white/[0.07] ps-0.5">
                <button type="button" aria-label={`تعویض ${c.name}`} title="تعویض فایل" className={rowAction} disabled={disabled} onClick={() => onReplace(c.id)}>
                  <Repeat2 size={17} aria-hidden="true" />
                </button>
                <button type="button" aria-label={`حذف ${c.name}`} title="حذف از پروژه" className={cn(rowAction, "text-rose/85 hover:bg-rose/12 hover:text-rose")} disabled={disabled} onClick={() => onDelete(c.id)}>
                  <Trash2 size={16} aria-hidden="true" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
      <button
        onClick={onAdd}
        disabled={disabled}
        className={cn("flex w-full items-center justify-center gap-2.5 rounded-xl border border-dashed border-white/15 bg-white/[0.02] px-3 py-3 text-mute transition-colors hover:border-cyan/60 hover:text-cyan disabled:opacity-45", !clips.length && "flex-col py-6")}
      >
        {busy ? <Loader2 size={18} className="animate-spin" /> : <Plus size={18} />}
        <span className="text-start">
          <span className="block text-[12.5px] font-medium">{busy ? "در حال خواندن فایل‌ها" : "افزودن ویدئو یا عکس"}</span>
          <span className="block text-[10.5px] opacity-80">
            {clips.length ? `${fa(clips.length)} کلیپ · ${fmtTime(total)}` : "می‌توانید چند فایل را با هم انتخاب کنید"}
          </span>
        </span>
      </button>
    </div>
  );
}

/** editor for the selected clip */
export function ClipEditor({
  clip,
  index,
  count,
  onChange,
  onMove,
  onDelete,
  onReplace,
  onDuplicate,
  onSplit,
}: {
  clip: Clip | undefined;
  index: number;
  count: number;
  onChange: (patch: Partial<Clip>) => void;
  onMove: (dir: -1 | 1) => void;
  onDelete: () => void;
  onReplace: () => void;
  onDuplicate: () => void;
  onSplit: () => void;
}) {
  if (!clip) {
    return (
      <Card title="ویرایش کلیپ" icon={<Scissors size={15} />}>
        <p className="text-[12px] leading-6 text-mute/80">یک کلیپ را از تایم‌لاین انتخاب کنید یا از تب «رسانه‌ها» کلیپ اضافه کنید.</p>
      </Card>
    );
  }
  const end = clip.trimStart + clip.dur;
  return (
    <Card
      title={`کلیپ ${fa(index + 1)} از ${fa(count)}`}
      icon={clip.kind === "video" ? <Film size={15} /> : <ImageIcon size={15} />}
      right={<Pill>{fmtTime(clip.dur, true)}</Pill>}
    >
      <div className="mb-3 flex items-center gap-2.5">
        <div className="h-12 w-12 shrink-0 rounded-lg bg-cover bg-center ring-1 ring-white/10" style={{ backgroundImage: clip.thumb ? `url(${clip.thumb})` : undefined }} />
        <bdi className="min-w-0 flex-1 truncate text-[12px]" title={clip.name}>{clip.name}</bdi>
        <button type="button" className={cn(btn, "min-h-10 shrink-0")} onClick={onReplace}>
          <Repeat2 size={15} aria-hidden="true" /> تعویض فایل
        </button>
      </div>

      {clip.kind === "image" ? (
        <SliderRow label="مدت نمایش عکس" value={clip.dur} min={1} max={30} step={0.1} onChange={(v) => onChange({ dur: v })} format={(v) => `${fa(v.toFixed(1))} ثانیه`} />
      ) : (
        <div className="flex flex-col gap-1.5">
          <SliderRow
            label="شروع (برش ابتدا)"
            value={clip.trimStart}
            min={0}
            max={Math.max(0.1, end - 0.5)}
            step={0.1}
            onChange={(v) => onChange({ trimStart: v, dur: Math.max(0.5, end - v) })}
            format={(v) => fmtTime(v, true)}
          />
          <SliderRow
            label="پایان (برش انتها)"
            value={end}
            min={Math.min(clip.srcDur, clip.trimStart + 0.5)}
            max={clip.srcDur}
            step={0.1}
            onChange={(v) => onChange({ dur: Math.max(0.5, v - clip.trimStart) })}
            format={(v) => fmtTime(v, true)}
          />
        </div>
      )}

      <div className="mt-3 grid grid-cols-5 gap-1.5">
        <button className={btn} onClick={() => onMove(1)} disabled={index >= count - 1} aria-label="جابه‌جایی به بعد">
          <ArrowLeft size={16} />
        </button>
        <button className={btn} onClick={() => onMove(-1)} disabled={index <= 0} aria-label="جابه‌جایی به قبل">
          <ArrowRight size={16} />
        </button>
        <button className={btn} onClick={onSplit} aria-label="برش در پلی‌هد">
          <Scissors size={16} />
        </button>
        <button className={btn} onClick={onDuplicate} aria-label="کپی کلیپ">
          <Copy size={16} />
        </button>
        <button className={cn(btn, "text-[#ffb4ab]")} onClick={onDelete} aria-label="حذف کلیپ">
          <Trash2 size={16} />
        </button>
      </div>
      <p className="mt-2 text-center text-[10px] text-mute/70">قبل · بعد · برش در پلی‌هد · کپی · حذف</p>
    </Card>
  );
}

/** tools that work on the whole sequence */
export function SequenceTools({
  hasAudio,
  bpm,
  hasImages,
  transition,
  onTransition,
  onFit,
  onBeats,
}: {
  hasAudio: boolean;
  bpm: number;
  hasImages: boolean;
  transition: boolean;
  onTransition: (v: boolean) => void;
  onFit: () => void;
  onBeats: (n: number) => void;
}) {
  return (
    <Card title="ابزار هوشمند ترتیب کلیپ‌ها" icon={<Wand2 size={15} />}>
      <div className="flex flex-col gap-2">
        <Toggle label="محو شدن بین کلیپ‌ها" hint="تغییر نرم و سینمایی بین هر دو کلیپ" on={transition} onChange={onTransition} />
        <button className={btn} onClick={onFit} disabled={!hasAudio || !hasImages}>
          <Music4 size={14} /> هم‌طول کردن عکس‌ها با موزیک
        </button>
        <div>
          <div className="mb-1 text-[11.5px] text-mute">برش عکس‌ها روی بیت موزیک {bpm > 0 ? `(${fa(bpm)} BPM)` : ""}</div>
          <div className="grid grid-cols-4 gap-1.5">
            {[1, 2, 4, 8].map((n) => (
              <button key={n} className={btn} onClick={() => onBeats(n)} disabled={bpm <= 0 || !hasImages}>
                {fa(n)} ضرب
              </button>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}
