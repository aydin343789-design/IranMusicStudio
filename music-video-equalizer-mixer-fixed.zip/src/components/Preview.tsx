import { memo, useLayoutEffect, useRef, useState, type CSSProperties, type RefObject } from "react";
import { CircleAlert, Frame, Loader2, Maximize2, Move, Eye, EyeOff, VolumeX, Volume2, Video, ImagePlus, Music2, Sparkles, RotateCcw, FileUp } from "lucide-react";
import type { PlaybackIssue } from "../lib/engine";
import type { VizBox } from "../lib/visualizers";
import { fa, fmtTime } from "../lib/format";
import { frameRatio, type Aspect } from "../lib/framing";
import { useTime } from "../lib/timeStore";
import { cn } from "../utils/cn";

export type MonitorStatus = "ready" | "pending" | "unavailable";

interface Props {
  canvasRef: RefObject<HTMLCanvasElement | null>;
  canvasVersion: number;
  mountVideo: (host: HTMLElement) => () => void;
  cw: number;
  ch: number;
  aspect: Aspect;
  box: VizBox;
  onBox: (b: VizBox) => void;
  playing: boolean;
  buffering: boolean;
  recovering: boolean;
  issue: PlaybackIssue | null;
  monitorStatus: MonitorStatus;
  importing: boolean;
  hasVisual: boolean;
  hasAudio: boolean;
  hasVideo: boolean;
  videoMuted: boolean;
  recording: boolean;
  styleLabel: string;
  onTogglePlay: () => void;
  onRetry: () => void;
  onReplaceIssue: () => void;
  onPick: (k: "clips" | "audio") => void;
  onDemo: () => void;
  onOpenFrame: () => void;
}

function TimeLabel() {
  const { time, duration } = useTime();
  return (
    <span dir="ltr" className="shrink-0 rounded-md bg-white/[0.06] px-2 py-1 font-mono text-[11px] text-ink">
      {fmtTime(time)} / {fmtTime(duration)}
    </span>
  );
}

function Preview({
  canvasRef,
  canvasVersion,
  mountVideo,
  cw,
  ch,
  aspect,
  box,
  onBox,
  playing,
  buffering,
  recovering,
  issue,
  monitorStatus,
  importing,
  hasVisual,
  hasAudio,
  hasVideo,
  videoMuted,
  recording,
  styleLabel,
  onTogglePlay,
  onRetry,
  onReplaceIssue,
  onPick,
  onDemo,
  onOpenFrame,
}: Props) {
  const stage = useRef<HTMLDivElement>(null);
  const videoHost = useRef<HTMLDivElement>(null);
  const [edit, setEdit] = useState(true);
  const drag = useRef<null | { mode: "move" | "size"; sx: number; sy: number; box: VizBox }>(null);

  useLayoutEffect(() => {
    if (videoHost.current) return mountVideo(videoHost.current);
  }, [mountVideo]);

  const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

  const onDown = (mode: "move" | "size") => (e: React.PointerEvent) => {
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { mode, sx: e.clientX, sy: e.clientY, box: { ...box } };
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const r = stage.current!.getBoundingClientRect();
    if (d.mode === "move") {
      onBox({
        ...d.box,
        cx: clamp(d.box.cx + (e.clientX - d.sx) / r.width, 0, 1),
        cy: clamp(d.box.cy + (e.clientY - d.sy) / r.height, 0, 1),
      });
    } else {
      const px = (e.clientX - r.left) / r.width;
      const py = (e.clientY - r.top) / r.height;
      onBox({
        ...d.box,
        w: clamp(Math.abs(px - d.box.cx) * 2, 0.1, 1.4),
        h: clamp(Math.abs(py - d.box.cy) * 2, 0.06, 1.4),
      });
    }
  };
  const onUp = () => {
    drag.current = null;
  };

  const goFull = () => {
    const el = stage.current;
    if (el?.requestFullscreen) void el.requestFullscreen().catch(() => {});
  };

  const showEdit = edit && !recording && !importing && !issue && monitorStatus === "ready" && (hasVisual || hasAudio);
  const monitorError = !issue && !importing && !buffering && monitorStatus === "unavailable";
  const status = importing ? "در حال وارد کردن رسانه" : recovering ? "در حال بازیابی پخش" : buffering ? "در حال آماده‌سازی پخش"
    : issue ? "" : monitorError ? "فریم هنوز آماده نیست. برای تلاش دوباره، دکمهٔ پخش را بزنید."
      : hasVisual && monitorStatus === "pending" ? "در حال آماده‌سازی فریم" : "";

  return (
    <div
      className={cn(
        "rounded-3xl p-[1.5px] shadow-2xl transition-shadow",
        playing
          ? "bg-gradient-to-br from-cyan/70 via-[#7c4dff]/60 to-[#ff4fd8]/70 shadow-[0_0_34px_rgba(124,77,255,0.28)]"
          : "bg-gradient-to-br from-white/15 to-white/[0.04]",
      )}
    >
      <div className="rounded-[22px] bg-lowest p-2.5">
        <div className="mb-2.5 flex items-center justify-between gap-2 px-0.5">
          <div className="flex min-w-0 items-center gap-2">
            <span className={cn("size-1.5 shrink-0 rounded-full bg-cyan/55", playing && "bg-cyan motion-safe:animate-pulse")} />
            <p className="truncate text-[12px] font-semibold">پیش‌نمایش پروژه</p>
            <span dir="ltr" className="hidden shrink-0 font-mono text-[10px] text-mute/85 sm:inline" title="ابعاد نمایش">{cw} × {ch}</span>
          </div>
          <TimeLabel />
        </div>

        <div className="flex w-full justify-center rounded-xl bg-[#10151f] py-1.5 sm:py-2">
          <div
            ref={stage}
            role="group"
            aria-label="قاب پیش‌نمایش"
            className="preview-stage relative overflow-hidden rounded-lg ring-1 ring-white/10"
            style={{ "--frame-ratio": frameRatio(aspect) } as CSSProperties}
            onClick={onTogglePlay}
          >
            <div ref={videoHost} aria-hidden="true" className="pointer-events-none absolute inset-0" />
            <canvas key={canvasVersion} ref={canvasRef} aria-label="تصویر پروژه" className="absolute inset-0 block size-full" />

            {status && (
              <span role="status" className={cn("fade-up pointer-events-none absolute inset-x-2 bottom-2 z-10 flex items-center gap-1.5 rounded-lg bg-lowest/90 px-2 py-1.5 text-[11px] leading-4 text-cyan", monitorError && "text-rose")}>
                {monitorError ? <CircleAlert size={13} className="shrink-0" /> : <Loader2 size={13} className="shrink-0 motion-safe:animate-spin" />}
                {status}
              </span>
            )}

            {!hasVisual && !importing && (
              <div
                className="absolute inset-0 flex flex-col items-center justify-end gap-3 bg-gradient-to-t from-black/70 via-transparent to-transparent p-4 pb-5"
                onClick={(e) => e.stopPropagation()}
              >
                <p className="text-center text-[12px] leading-5 text-ink/85">
                  {hasAudio ? "موزیک آماده است؛ یک عکس یا ویدئو به‌عنوان پس‌زمینه اضافه کنید" : "برای شروع، چند ویدئو/عکس و یک موزیک اضافه کنید"}
                </p>
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <button
                    onClick={() => onPick("clips")}
                    className="flex items-center gap-1.5 rounded-xl bg-cyan px-3 py-2 text-[12px] font-bold text-[#00464b] shadow-[0_0_16px_rgba(0,242,254,0.4)] active:scale-95"
                  >
                    <Video size={14} /> <ImagePlus size={14} /> ویدئو / عکس
                  </button>
                  {!hasAudio && (
                    <>
                      <button
                        onClick={() => onPick("audio")}
                        className="flex items-center gap-1.5 rounded-xl bg-white/15 px-3 py-2 text-[12px] font-semibold text-ink active:scale-95"
                      >
                        <Music2 size={14} /> موزیک
                      </button>
                      <button
                        onClick={onDemo}
                        className="flex items-center gap-1.5 rounded-xl bg-white/10 px-3 py-2 text-[12px] text-mute active:scale-95"
                      >
                        <Sparkles size={14} /> دمو
                      </button>
                    </>
                  )}
                </div>
              </div>
            )}

            {showEdit && (
              <div
                className="visualizer-controls absolute touch-none select-none"
                style={{
                  left: `${(box.cx - box.w / 2) * 100}%`,
                  top: `${(box.cy - box.h / 2) * 100}%`,
                  width: `${box.w * 100}%`,
                  height: `${box.h * 100}%`,
                }}
                onClick={(e) => e.stopPropagation()}
                onPointerDown={onDown("move")}
                onPointerMove={onMove}
                onPointerUp={onUp}
                onPointerCancel={onUp}
              >
                <div className="absolute inset-0 cursor-move rounded-md border border-dashed border-cyan/60 bg-cyan/[0.03]" />
                {(["-top-1.5 -start-1.5", "-top-1.5 -end-1.5", "-bottom-1.5 -start-1.5"] as const).map((pos) => (
                  <span key={pos} className={`absolute h-2.5 w-2.5 rounded-full bg-cyan shadow-[0_0_8px_rgba(0,242,254,0.9)] ${pos}`} />
                ))}
                <span
                  onPointerDown={onDown("size")}
                  onPointerMove={onMove}
                  onPointerUp={onUp}
                  className="absolute -bottom-3 -end-3 flex h-6 w-6 cursor-nwse-resize items-center justify-center"
                >
                  <span className="h-3 w-3 rounded-full bg-cyan shadow-[0_0_10px_rgba(0,242,254,1)]" />
                </span>
                <span className="pointer-events-none absolute -top-5 start-0 flex items-center gap-1 text-[10px] text-cyan">
                  <Move size={10} /> {styleLabel}
                </span>
              </div>
            )}
          </div>
        </div>

        {issue && !recording && (
          <div className="fade-up mt-2.5 rounded-xl border border-rose/25 bg-[#241923] px-3 py-2.5">
            <div role="alert" className="flex items-start gap-2">
              <CircleAlert size={16} className="mt-0.5 shrink-0 text-rose" aria-hidden="true" />
              <div className="min-w-0">
                <p className="text-[12px] font-semibold text-rose">پخش متوقف شد</p>
                <p className="mt-0.5 break-words text-[11px] leading-5 text-ink/90">{issue.message}</p>
              </div>
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              <button type="button" disabled={importing} onClick={onRetry} className="flex min-h-10 items-center gap-1.5 rounded-lg bg-cyan/12 px-2.5 text-[11px] font-semibold text-cyan transition-colors hover:bg-cyan/20 disabled:opacity-50">
                <RotateCcw size={14} aria-hidden="true" /> تلاش دوباره
              </button>
              {(issue.clipId || issue.target === "audio") && (
                <button type="button" disabled={importing} onClick={onReplaceIssue} className="flex min-h-10 items-center gap-1.5 rounded-lg bg-white/6 px-2.5 text-[11px] text-ink transition-colors hover:bg-white/12 disabled:opacity-50">
                  <FileUp size={14} aria-hidden="true" /> {issue.target === "audio" ? "تعویض موزیک" : "تعویض فایل"}
                </button>
              )}
            </div>
          </div>
        )}

        <div className="mt-2 flex items-center justify-between gap-2 px-0.5 text-mute">
          <button
            onClick={() => setEdit((v) => !v)}
            aria-pressed={edit}
            className="flex min-h-9 items-center gap-1.5 rounded-lg px-2 text-[11px] transition-colors hover:bg-white/[0.06] hover:text-cyan"
          >
            {edit ? <Eye size={13} /> : <EyeOff size={13} />}
            کادر ویرایش
          </button>
          <div className="flex shrink-0 items-center gap-1">
            {hasVideo && (
              <span title={videoMuted ? "صدای ویدئو خاموش" : "صدای ویدئو روشن"} className="grid size-8 place-items-center text-mute">
                {videoMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
              </span>
            )}
            <button onClick={onOpenFrame} disabled={recording} aria-label="تغییر قالب در استودیو"
              className="flex min-h-9 items-center gap-1.5 rounded-lg border border-white/[0.08] px-2 font-mono text-[11px] text-cyan transition-colors hover:bg-white/[0.06] disabled:opacity-50">
              <Frame size={14} /> <bdi dir="ltr">{fa(aspect)}</bdi>
            </button>
            <button onClick={goFull} aria-label="تمام‌صفحه"
              className="flex size-9 items-center justify-center rounded-lg text-mute transition-colors hover:bg-white/[0.06] hover:text-cyan">
              <Maximize2 size={15} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default memo(Preview);
