import { memo, useRef } from "react";
import { fmtTime } from "../lib/format";
import { useTime } from "../lib/timeStore";

function Scrubber({ onSeek, disabled }: { onSeek: (t: number) => void; disabled?: boolean }) {
  const { time, duration } = useTime();
  const ref = useRef<HTMLDivElement>(null);
  const down = useRef(false);
  const p = duration > 0 ? Math.min(1, time / duration) : 0;

  const seek = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect();
    onSeek(Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)) * duration);
  };

  return (
    <div dir="ltr" className="flex items-center gap-2.5 px-1">
      <span className="w-11 text-end font-mono text-[10px] text-mute">{fmtTime(time)}</span>
      <div
        ref={ref}
        className={`relative h-6 flex-1 touch-none ${disabled ? "opacity-40" : "cursor-pointer"}`}
        onPointerDown={(e) => {
          if (disabled) return;
          down.current = true;
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          seek(e);
        }}
        onPointerMove={(e) => down.current && seek(e)}
        onPointerUp={() => (down.current = false)}
        onPointerCancel={() => (down.current = false)}
      >
        <div className="absolute inset-x-0 top-1/2 h-1.5 -translate-y-1/2 overflow-hidden rounded-full bg-highest">
          <div className="h-full rounded-full bg-gradient-to-r from-cyan via-[#7c4dff] to-[#ff4fd8]" style={{ width: `${p * 100}%` }} />
        </div>
        <div
          className="absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white shadow-[0_0_12px_rgba(0,242,254,0.9)]"
          style={{ left: `${p * 100}%` }}
        />
      </div>
      <span className="w-11 font-mono text-[10px] text-mute">{fmtTime(duration)}</span>
    </div>
  );
}

export default memo(Scrubber);
