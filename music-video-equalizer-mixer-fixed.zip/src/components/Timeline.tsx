import { memo, useMemo, useRef } from "react";
import { Film, ImageIcon, Music2, AudioLines, Lock } from "lucide-react";
import { fa, fmtTime } from "../lib/format";
import type { AudioAnalysis, Clip } from "../lib/engine";
import { useTime } from "../lib/timeStore";

interface Props {
  clips: Clip[];
  selId: string;
  onSelect: (id: string) => void;
  duration: number;
  onSeek: (t: number) => void;
  hasAudio: boolean;
  analysis: AudioAnalysis | null;
  audioName: string;
  audioDur: number;
  offset: number;
  loop: boolean;
  locked: boolean;
  showBeats: boolean;
  onOffset: (o: number) => void;
  rangeStart: number;
  rangeEnd: number;
  videoMuted: boolean;
}

function Playhead({ total }: { total: number }) {
  const { time } = useTime();
  return (
    <div
      className="pointer-events-none absolute -top-2 bottom-0 z-30 w-0.5 bg-cyan-dim shadow-[0_0_10px_rgba(0,220,230,0.9)]"
      style={{ left: `${(Math.min(time, total) / total) * 100}%` }}
    >
      <div className="-ms-[5px] h-2.5 w-3 rounded-b bg-cyan-dim" />
    </div>
  );
}

function Timeline(p: Props) {
  const { duration: dur, clips } = p;
  const rulerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const drag = useRef<null | { x: number; off: number }>(null);
  const scrub = useRef(false);

  const total = Math.max(dur, 0.001);
  const pct = (t: number) => `${(t / total) * 100}%`;
  const hasClips = clips.length > 0;

  const seekFromEvent = (e: React.PointerEvent) => {
    const r = rulerRef.current!.getBoundingClientRect();
    p.onSeek(Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)) * total);
  };

  const step = total > 300 ? 60 : total > 120 ? 30 : total > 60 ? 15 : total > 30 ? 10 : total > 12 ? 5 : total > 5 ? 2 : 1;
  const ticks: number[] = [];
  for (let t = 0; t <= total + 0.001; t += step) ticks.push(t);

  // audio clips (repeat when looping)
  const aClips: number[] = [];
  if (p.hasAudio && p.audioDur > 0 && hasClips) {
    let s = p.offset;
    let guard = 0;
    while (s < total && guard++ < 40) {
      if (s + p.audioDur > 0) aClips.push(s);
      if (!p.loop) break;
      s += p.audioDur;
    }
  } else if (p.hasAudio) {
    aClips.push(0);
  }

  let beatPath = "";
  if (p.showBeats && p.analysis && p.analysis.bpm > 0 && p.hasAudio) {
    const per = 60 / p.analysis.bpm;
    for (let k = 0; k < 800; k++) {
      const bt = p.analysis.firstBeat + k * per;
      if (bt > p.audioDur) break;
      for (const c of aClips) {
        const x = c + bt;
        if (x >= 0 && x <= total) beatPath += `M${((x / total) * 1000).toFixed(1)} 0V1`;
      }
    }
  }

  const canDrag = !p.locked && hasClips && p.hasAudio;
  const onTrackDown = (e: React.PointerEvent) => {
    if (!canDrag) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { x: e.clientX, off: p.offset };
  };
  const onTrackMove = (e: React.PointerEvent) => {
    if (!drag.current) return;
    const w = trackRef.current!.getBoundingClientRect().width;
    const o = drag.current.off + ((e.clientX - drag.current.x) / w) * total;
    p.onOffset(Math.round(Math.min(total - 0.3, Math.max(-(p.audioDur - 0.3), o)) * 100) / 100);
  };
  const onTrackUp = () => {
    drag.current = null;
  };

  const peaks = p.analysis?.peaks ?? [];
  const wavePath = useMemo(() => {
    let d = "";
    peaks.forEach((v, i) => {
      const h = Math.max(1.5, v * 21);
      d += `M${i + 0.5} ${24 - h}V${24 + h}`;
    });
    return d;
  }, [peaks]);

  return (
    <div dir="ltr" className="select-none rounded-2xl border border-white/[0.06] bg-lowest p-2.5 shadow-xl">
      {/* ruler */}
      <div
        ref={rulerRef}
        className="relative mb-2 h-7 cursor-col-resize touch-none overflow-hidden rounded-lg bg-low"
        onPointerDown={(e) => {
          scrub.current = true;
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          seekFromEvent(e);
        }}
        onPointerMove={(e) => scrub.current && seekFromEvent(e)}
        onPointerUp={() => (scrub.current = false)}
      >
        {ticks.map((t) => (
          <div key={t} className="absolute top-0 h-full" style={{ left: pct(t) }}>
            <div className="h-2 w-px bg-line" />
            <span className="ms-1 font-mono text-[9px] text-[#849495]">{fmtTime(t)}</span>
          </div>
        ))}
      </div>

      <div className="relative flex flex-col gap-1.5">
        <Playhead total={total} />

        {/* clips */}
        <div className="rounded-xl bg-mid/80 p-1.5">
          <div className="mb-1 flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 text-[11px] text-ink">
              <Film size={14} className="shrink-0 text-cyan" />
              <span dir="rtl">کلیپ‌ها ({fa(clips.length)})</span>
            </span>
            <span className="font-mono text-[9px] text-mute">{videoMutedLabel(p.videoMuted)}</span>
          </div>
          <div className="relative flex h-14 gap-px overflow-hidden rounded-lg bg-high p-0.5">
            {hasClips ? (
              clips.map((c) => {
                const sel = c.id === p.selId;
                return (
                  <button
                    key={c.id}
                    aria-label={`پیش‌نمایش ${c.name}`}
                    aria-pressed={sel}
                    title={c.name}
                    onClick={() => p.onSelect(c.id)}
                    className={`relative h-full min-w-[3px] overflow-hidden rounded-md bg-cover bg-center transition ${sel ? "ring-2 ring-cyan" : "opacity-85 ring-1 ring-white/10"}`}
                    style={{ width: `${(c.dur / total) * 100}%`, backgroundImage: c.thumb ? `url(${c.thumb})` : undefined, backgroundSize: "auto 100%", backgroundRepeat: "repeat-x" }}
                  >
                    <span className="absolute bottom-0 start-0 flex items-center gap-0.5 rounded-te bg-black/60 px-1 text-[8px] text-white">
                      {c.kind === "video" ? <Film size={8} /> : <ImageIcon size={8} />}
                      {c.dur >= 3 ? fmtTime(c.dur) : ""}
                    </span>
                  </button>
                );
              })
            ) : (
              <div className="flex h-full w-full items-center justify-center text-[10px] text-mute/60" dir="rtl">
                کلیپی اضافه نشده؛ پس‌زمینه انیمیشنی استفاده می‌شود
              </div>
            )}
          </div>
        </div>

        {/* audio */}
        <div className="rounded-xl bg-mid/80 p-1.5">
          <div className="mb-1 flex items-center justify-between gap-2">
            <span className="flex min-w-0 items-center gap-1.5 text-[11px] text-ink">
              <Music2 size={14} className="shrink-0 text-cyan-dim" />
              <span className="truncate">{p.hasAudio ? p.audioName : "لایه موزیک (خالی)"}</span>
            </span>
            <span className="flex items-center gap-1 font-mono text-[9px] text-cyan">
              {p.locked && <Lock size={10} />}
              {p.analysis && p.analysis.bpm > 0 ? `${fa(p.analysis.bpm)} BPM` : "—"}
              {hasClips ? ` · ${p.offset >= 0 ? "+" : ""}${fa(p.offset.toFixed(2))}s` : ""}
            </span>
          </div>
          <div
            ref={trackRef}
            className={`relative h-14 overflow-hidden rounded-lg bg-high ${canDrag ? "cursor-grab active:cursor-grabbing" : ""} touch-none`}
            onPointerDown={onTrackDown}
            onPointerMove={onTrackMove}
            onPointerUp={onTrackUp}
            onPointerCancel={onTrackUp}
          >
            {aClips.map((c, i) => (
              <div
                key={i}
                className="absolute inset-y-1 overflow-hidden rounded bg-cyan/10 ring-1 ring-cyan/30"
                style={{ left: pct(c), width: pct(hasClips ? p.audioDur : total) }}
              >
                <svg viewBox={`0 0 ${peaks.length || 1} 48`} preserveAspectRatio="none" className="h-full w-full">
                  <defs>
                    <linearGradient id={`wg${i}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0" stopColor="#00f2fe" />
                      <stop offset="0.5" stopColor="#ffb3b5" />
                      <stop offset="1" stopColor="#00f2fe" />
                    </linearGradient>
                  </defs>
                  <path d={wavePath} stroke={`url(#wg${i})`} strokeWidth="0.7" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
                </svg>
              </div>
            ))}
            {beatPath && (
              <svg viewBox="0 0 1000 1" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 h-full w-full">
                <path d={beatPath} stroke="rgba(255,255,255,0.25)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
              </svg>
            )}
            {!p.hasAudio && (
              <div className="absolute inset-0 flex items-center justify-center text-[10px] text-mute/60" dir="rtl">
                موزیکی اضافه نشده
              </div>
            )}
            {canDrag && (
              <div className="pointer-events-none absolute bottom-0.5 start-1 rounded bg-black/50 px-1 text-[9px] text-mute" dir="rtl">
                بکشید تا موزیک جابه‌جا شود
              </div>
            )}
          </div>
        </div>

        {/* visualizer */}
        <div className="rounded-xl bg-mid/80 p-1.5">
          <div className="mb-1 flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-[11px] text-ink">
              <AudioLines size={14} className="text-pink" />
              <span dir="rtl">افکت اکولایزر</span>
            </span>
            <span className="font-mono text-[9px] text-pink">
              {fmtTime(p.rangeStart * total)} → {fmtTime(p.rangeEnd * total)}
            </span>
          </div>
          <div className="relative h-8 overflow-hidden rounded-lg bg-high">
            <div
              className="absolute inset-y-1 flex items-center justify-between rounded bg-gradient-to-r from-pink/20 via-pink/50 to-pink/20 px-1.5"
              style={{ left: `${p.rangeStart * 100}%`, width: `${(p.rangeEnd - p.rangeStart) * 100}%` }}
            >
              <span className="h-2 w-2 rotate-45 bg-pink shadow-[0_0_6px_rgba(255,171,243,0.9)]" />
              <span className="h-2 w-2 rotate-45 bg-pink shadow-[0_0_6px_rgba(255,171,243,0.9)]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function videoMutedLabel(m: boolean) {
  return m ? "VIDEO AUDIO: OFF" : "VIDEO AUDIO: ON";
}

export default memo(Timeline);
