import { Crop, Frame, Scan } from "lucide-react";
import { FRAME_PRESETS, type Aspect, type MediaFit } from "../lib/framing";
import { fa } from "../lib/format";
import { cn } from "../utils/cn";
import { Card } from "./ui";

const templates: { aspect: Aspect; name: string }[] = [
  { aspect: "9:16", name: "عمودی" },
  { aspect: "16:9", name: "افقی" },
  { aspect: "1:1", name: "مربعی" },
  { aspect: "4:5", name: "پست" },
];

export default function FrameSettings({ aspect, fit, onAspect, onFit, disabled }: {
  aspect: Aspect;
  fit: MediaFit;
  onAspect: (value: Aspect) => void;
  onFit: (value: MediaFit) => void;
  disabled?: boolean;
}) {
  return (
    <Card title="قاب پروژه" icon={<Frame size={15} />}>
      <div className="grid grid-cols-4 gap-2" role="group" aria-label="قالب تصویر">
        {templates.map(({ aspect: value, name }) => {
          const [w, h] = FRAME_PRESETS[value];
          const scale = 24 / Math.max(w, h);
          const chosen = aspect === value;
          return (
            <button
              key={value}
              type="button"
              disabled={disabled}
              aria-label={`${name} ${fa(value)}`}
              aria-pressed={chosen}
              onClick={() => onAspect(value)}
              className={cn(
                "flex min-w-0 flex-col items-center gap-1 rounded-xl border border-white/8 bg-white/[0.025] px-1 py-2.5 text-mute transition-colors hover:border-cyan/30 hover:text-ink disabled:opacity-50",
                chosen && "border-cyan/60 bg-cyan/[0.075] text-cyan",
              )}
            >
              <span className="grid h-7 w-7 place-items-center" aria-hidden="true">
                <span className="rounded-[3px] border-[1.5px] border-current" style={{ width: w * scale, height: h * scale }} />
              </span>
              <span className="text-[12px] font-semibold">{name}</span>
              <bdi dir="ltr" className="font-mono text-[10px] leading-tight opacity-80">{fa(value)}</bdi>
            </button>
          );
        })}
      </div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.07] pt-3">
        <span className="text-[11px] text-mute">چیدمان رسانه در قاب</span>
        <div role="group" aria-label="چیدمان رسانه" className="inline-flex gap-0.5 rounded-lg bg-lowest/70 p-0.5 text-[11px]">
          {([{ value: "fit", label: "نمایش کامل", Icon: Scan }, { value: "fill", label: "پر کردن قاب", Icon: Crop }] as const).map(({ value, label, Icon }) => (
            <button key={value} type="button" disabled={disabled} aria-pressed={fit === value} onClick={() => onFit(value)}
              className={cn("flex min-h-9 items-center gap-1.5 rounded-md px-2 text-mute transition-colors hover:text-ink disabled:opacity-50", fit === value && "bg-high text-cyan")}
            >
              <Icon size={13} aria-hidden="true" /> {label}
            </button>
          ))}
        </div>
      </div>
      <p className="mt-2 text-[11px] leading-5 text-mute/85">
        {fit === "fit" ? "عکس و ویدئو بدون برش در قاب ثابت نمایش داده می‌شوند." : "تصویر تمام قاب را می‌پوشاند؛ ممکن است بخشی از لبه‌ها بریده شود."}
      </p>
    </Card>
  );
}