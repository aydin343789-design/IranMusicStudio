import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";

export function Card({
  title,
  icon,
  right,
  children,
  className,
}: {
  title?: string;
  icon?: ReactNode;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-2xl border border-white/[0.06] bg-gradient-to-b from-white/[0.045] to-white/[0.015] p-3.5 shadow-lg", className)}>
      {title && (
        <header className="mb-3 flex items-center justify-between gap-2">
          <h3 className="flex items-center gap-2 text-[13px] font-semibold text-ink">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-cyan/10 text-cyan ring-1 ring-cyan/20">{icon}</span>
            {title}
          </h3>
          {right}
        </header>
      )}
      {children}
    </section>
  );
}

/**
 * Range slider that keeps its own draft value while the finger is down and pushes
 * changes to the parent at most once per animation frame. Without this, every raw
 * `input` event re-rendered the whole app (and, for clip sliders, reset the engine),
 * which is what made dragging feel slow and made values jump back.
 */
export function SliderRow({
  label,
  value,
  min,
  max,
  step = 0.01,
  onChange,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  format?: (v: number) => string;
}) {
  const [draft, setDraft] = useState<number | null>(null);
  const pending = useRef<number | null>(null);
  const raf = useRef(0);
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  const flush = useCallback(() => {
    raf.current = 0;
    if (pending.current === null) return;
    const v = pending.current;
    pending.current = null;
    onChangeRef.current(v);
  }, []);

  useEffect(() => () => {
    if (raf.current) cancelAnimationFrame(raf.current);
    flush();
  }, [flush]);

  const clamp = (v: number) => Math.min(max, Math.max(min, v));
  const shown = clamp(draft ?? (Number.isFinite(value) ? value : min));
  const range = max - min || 1;
  const p = ((shown - min) / range) * 100;

  const commit = () => {
    if (raf.current) cancelAnimationFrame(raf.current);
    flush();
    setDraft(null);
  };

  return (
    <label className="block">
      <div className="mb-0.5 flex items-center justify-between text-[12px]">
        <span className="text-mute">{label}</span>
        <span className="rounded-md bg-high px-1.5 py-0.5 font-mono text-[10px] text-cyan">
          {format ? format(shown) : shown}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={shown}
        style={{ ["--p" as string]: `${p}%` }}
        onChange={(e) => {
          const v = parseFloat(e.target.value);
          if (!Number.isFinite(v)) return;
          setDraft(v);
          pending.current = v;
          if (!raf.current) raf.current = requestAnimationFrame(flush);
        }}
        onPointerUp={commit}
        onPointerCancel={commit}
        onBlur={commit}
        onKeyUp={commit}
      />
    </label>
  );
}

export function Toggle({
  label,
  hint,
  on,
  onChange,
}: {
  label: string;
  hint?: string;
  on: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      className="flex w-full items-center justify-between gap-3 rounded-xl bg-white/[0.04] px-3 py-2.5 text-start ring-1 ring-white/[0.05] transition active:scale-[0.99]"
    >
      <span className="min-w-0">
        <span className="block text-[12.5px] text-ink">{label}</span>
        {hint && <span className="block text-[10.5px] text-mute/70">{hint}</span>}
      </span>
      <span
        className={cn(
          "relative h-5 w-9 shrink-0 rounded-full transition",
          on ? "bg-cyan-dim shadow-[0_0_10px_rgba(0,242,254,0.5)]" : "bg-highest",
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all",
            on ? "start-[18px]" : "start-0.5",
          )}
        />
      </span>
    </button>
  );
}

export function Pill({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("rounded-md bg-high px-1.5 py-0.5 font-mono text-[10px] text-cyan", className)}>
      {children}
    </span>
  );
}
